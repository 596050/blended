# SPDX-FileCopyrightText: 2022-2023 Blender Authors
#
# SPDX-License-Identifier: GPL-2.0-or-later

if(WIN32)
  set(EPOXY_LIB_TYPE shared)
else()
  set(EPOXY_LIB_TYPE static)
endif()

set(EPOXY_EXTRA_OPTIONS
  -Dtests=false
)

ExternalProject_Add(external_epoxy
  URL file://${PACKAGE_DIR}/${EPOXY_FILE}
  DOWNLOAD_DIR ${DOWNLOAD_DIR}
  URL_HASH ${EPOXY_HASH_TYPE}=${EPOXY_HASH}
  PREFIX ${BUILD_DIR}/epoxy

  PATCH_COMMAND ${PATCH_CMD} -p 1 -N -d
    ${BUILD_DIR}/epoxy/src/external_epoxy/ <
    ${PATCH_DIR}/epoxy.diff

  CONFIGURE_COMMAND ${CONFIGURE_ENV} &&
    ${MESON} setup
      --prefix ${LIBDIR}/epoxy
      --libdir lib
      --default-library ${EPOXY_LIB_TYPE}
      ${MESON_BUILD_TYPE}
      ${EPOXY_EXTRA_OPTIONS}
      ${BUILD_DIR}/epoxy/src/external_epoxy-build
      ${BUILD_DIR}/epoxy/src/external_epoxy

  BUILD_COMMAND ninja
  INSTALL_COMMAND ninja install
)

add_dependencies(
  external_epoxy
  # Needed for `MESON`.
  external_python_site_packages
)

if(WIN32)
  if(BUILD_MODE STREQUAL Release)
    ExternalProject_Add_Step(external_epoxy after_install
      COMMAND ${CMAKE_COMMAND} -E copy_directory
        ${LIBDIR}/epoxy/include
        ${HARVEST_TARGET}/epoxy/include
      COMMAND ${CMAKE_COMMAND} -E copy
        ${LIBDIR}/epoxy/bin/epoxy-0.dll
        ${HARVEST_TARGET}/epoxy/bin/epoxy-0.dll
      COMMAND ${CMAKE_COMMAND} -E copy
        ${LIBDIR}/epoxy/lib/epoxy.lib
        ${HARVEST_TARGET}/epoxy/lib/epoxy.lib
      DEPENDEES install
    )
  endif()
else()
  harvest(external_epoxy epoxy/include epoxy/include "*.h")
  harvest(external_epoxy epoxy/lib epoxy/lib "*.a")
endif()
