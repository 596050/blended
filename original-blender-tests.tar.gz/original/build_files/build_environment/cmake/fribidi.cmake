# SPDX-FileCopyrightText: 2022-2023 Blender Authors
#
# SPDX-License-Identifier: GPL-2.0-or-later

if(WIN32)
  set(FRIBIDI_CONFIGURE_ENV ${CONFIGURE_ENV_MSVC})
else()
  set(FRIBIDI_CONFIGURE_ENV ${CONFIGURE_ENV})
endif()

set(FRIBIDI_EXTRA_OPTIONS
  -Ddocs=false
)

ExternalProject_Add(external_fribidi
  URL file://${PACKAGE_DIR}/${FRIBIDI_FILE}
  URL_HASH ${FRIBIDI_HASH_TYPE}=${FRIBIDI_HASH}
  DOWNLOAD_DIR ${DOWNLOAD_DIR}
  PREFIX ${BUILD_DIR}/fribidi

  CONFIGURE_COMMAND ${FRIBIDI_CONFIGURE_ENV} &&
    ${MESON} setup
      --prefix ${LIBDIR}/fribidi
      --libdir lib
      --default-library static
      ${MESON_BUILD_TYPE}
      ${FRIBIDI_EXTRA_OPTIONS}
      ${BUILD_DIR}/fribidi/src/external_fribidi-build
      ${BUILD_DIR}/fribidi/src/external_fribidi

  BUILD_COMMAND ninja
  INSTALL_COMMAND ninja install
  INSTALL_DIR ${LIBDIR}/fribidi
)

add_dependencies(
  external_fribidi
  external_python
  # Needed for `MESON`.
  external_python_site_packages
)

if(WIN32)
  if(BUILD_MODE STREQUAL Release)
    ExternalProject_Add_Step(external_fribidi after_install
      COMMAND ${CMAKE_COMMAND} -E copy_directory
        ${LIBDIR}/fribidi/include
        ${HARVEST_TARGET}/fribidi/include
      COMMAND ${CMAKE_COMMAND} -E copy
        ${LIBDIR}/fribidi/lib/libfribidi.a
        ${HARVEST_TARGET}/fribidi/lib/libfribidi.lib

      DEPENDEES install
    )
  endif()
else()
  harvest(external_fribidi fribidi/include fribidi/include "*.h")
  harvest(external_fribidi fribidi/lib fribidi/lib "*.a")
endif()
