//! PLY loading (binary and ASCII). PLY is self-contained, so the byte API
//! takes only a mesh name; the filesystem companion-texture heuristic
//! (`stem_0.jpg` and friends) applies to the path loader only.
//!
//! Face-less files (scanner point clouds) load as a Points-topology mesh.
//! `red`/`green`/`blue` (+ optional `alpha`) vertex properties parse in
//! uchar and float forms; PLY colors are conventionally sRGB, so both
//! forms decode sRGB-to-linear at import, matching OBJ's extended-position
//! form so the same scan re-imports identically from either.

use std::io::Cursor;

use ply_rs_bw::ply::Property;

use crate::FormatsError;
use solarxy_core::geometry::srgb_to_linear;
use solarxy_core::{MeshTopology, RawMaterialData, RawMeshData, RawModelData};

fn ply_prop_to_f32(prop: &Property) -> f32 {
    match *prop {
        Property::Float(v) => v,
        Property::Double(v) => v as f32,
        Property::Int(v) => v as f32,
        Property::UInt(v) => v as f32,
        Property::Short(v) => f32::from(v),
        Property::UShort(v) => f32::from(v),
        Property::Char(v) => f32::from(v),
        Property::UChar(v) => f32::from(v),
        _ => 0.0,
    }
}

/// One color channel to normalized sRGB (0..1): uchar scales by 255,
/// float passes through; anything else reads as its f32 value clamped.
fn ply_prop_to_channel(prop: &Property) -> f32 {
    match *prop {
        Property::UChar(v) => f32::from(v) / 255.0,
        Property::UShort(v) => f32::from(v) / 65535.0,
        _ => ply_prop_to_f32(prop).clamp(0.0, 1.0),
    }
}

fn ply_prop_to_indices(prop: &Property) -> Vec<u32> {
    match prop {
        Property::ListInt(v) => v.iter().map(|&i| i as u32).collect(),
        Property::ListUInt(v) => v.clone(),
        Property::ListShort(v) => v.iter().map(|&i| i as u32).collect(),
        Property::ListUShort(v) => v.iter().map(|&i| u32::from(i)).collect(),
        Property::ListUChar(v) => v.iter().map(|&i| u32::from(i)).collect(),
        Property::ListChar(v) => v.iter().map(|&i| i as u32).collect(),
        _ => Vec::new(),
    }
}

#[cfg(feature = "std-fs")]
pub fn find_companion_texture(ply_path: &str) -> Option<std::path::PathBuf> {
    let path = std::path::Path::new(ply_path);
    let parent = path.parent()?;
    let stem = path.file_stem()?.to_str()?;
    let suffixes = ["_0", "", "_diffuse"];
    let extensions = ["jpg", "jpeg", "png", "bmp", "tga"];
    for suffix in &suffixes {
        for ext in &extensions {
            let candidate = parent.join(format!("{}{}.{}", stem, suffix, ext));
            if candidate.exists() {
                return Some(candidate);
            }
        }
    }
    None
}

/// Parse PLY bytes. `name` becomes the single mesh's name. No companion
/// texture lookup happens in byte mode.
pub fn load_ply_bytes(bytes: &[u8], name: &str) -> Result<RawModelData, FormatsError> {
    parse_ply(bytes, name, None)
}

/// Load a PLY from disk, with the historical companion-texture heuristic.
#[cfg(feature = "std-fs")]
pub fn load_ply(file_path: &str) -> Result<RawModelData, FormatsError> {
    let bytes = crate::read_file(file_path)?;
    let companion = find_companion_texture(file_path);
    parse_ply(&bytes, file_path, companion)
}

fn parse_ply(
    bytes: &[u8],
    name: &str,
    companion_tex: Option<std::path::PathBuf>,
) -> Result<RawModelData, FormatsError> {
    static NO_FACES: Vec<ply_rs_bw::ply::DefaultElement> = Vec::new();
    let mut reader = Cursor::new(bytes);
    let parser = ply_rs_bw::parser::Parser::<ply_rs_bw::ply::DefaultElement>::new();
    let ply = parser.read_ply(&mut reader).map_err(FormatsError::Ply)?;

    let ply_vertices = ply
        .payload
        .get("vertex")
        .ok_or_else(|| FormatsError::Invalid("PLY file has no 'vertex' element".to_string()))?;

    // A missing or empty face element is a point cloud (scanner exports),
    // not an error; only a file with no vertices at all has no geometry.
    let ply_faces = ply.payload.get("face").unwrap_or(&NO_FACES);
    let is_point_cloud = ply_faces.is_empty();

    if ply_vertices.is_empty() {
        return Err(FormatsError::Invalid(
            "PLY file contains no geometry".to_string(),
        ));
    }

    let (has_normals, has_uvs, uv_keys, has_colors, has_alpha) =
        if let Some(first) = ply_vertices.first() {
            let has_normals = first.get("nx").is_some();
            let uv_keys: Option<(&str, &str)> =
                if first.get("s").is_some() && first.get("t").is_some() {
                    Some(("s", "t"))
                } else if first.get("u").is_some() && first.get("v").is_some() {
                    Some(("u", "v"))
                } else if first.get("texture_u").is_some() && first.get("texture_v").is_some() {
                    Some(("texture_u", "texture_v"))
                } else {
                    None
                };
            let has_colors = first.get("red").is_some()
                && first.get("green").is_some()
                && first.get("blue").is_some();
            let has_alpha = has_colors && first.get("alpha").is_some();
            (
                has_normals,
                uv_keys.is_some(),
                uv_keys,
                has_colors,
                has_alpha,
            )
        } else {
            (false, false, None, false, false)
        };

    let multi_tex_verts = ply.payload.get("multi_texture_vertex");
    let multi_tex_faces = ply.payload.get("multi_texture_face");
    let has_multi_tex = multi_tex_verts.is_some_and(|v| !v.is_empty())
        && multi_tex_faces.is_some_and(|f| !f.is_empty());

    let multi_tex_uvs: Vec<[f32; 2]> = match multi_tex_verts.filter(|v| !v.is_empty()) {
        Some(verts) if has_multi_tex => verts
            .iter()
            .map(|elem| {
                [
                    elem.get("u").map_or(0.0, ply_prop_to_f32),
                    elem.get("v").map_or(0.0, ply_prop_to_f32),
                ]
            })
            .collect(),
        _ => Vec::new(),
    };

    let has_uvs = has_uvs || has_multi_tex;

    let mut positions: Vec<[f32; 3]> = Vec::with_capacity(ply_vertices.len());
    let mut normals_vec: Vec<[f32; 3]> = Vec::with_capacity(ply_vertices.len());
    let mut tex_coords_vec: Vec<[f32; 2]> = Vec::with_capacity(ply_vertices.len());
    let mut colors_vec: Vec<[f32; 4]> = Vec::with_capacity(ply_vertices.len());

    for elem in ply_vertices {
        let x = elem.get("x").map_or(0.0, ply_prop_to_f32);
        let y = elem.get("y").map_or(0.0, ply_prop_to_f32);
        let z = elem.get("z").map_or(0.0, ply_prop_to_f32);
        positions.push([x, y, z]);

        if has_normals {
            normals_vec.push([
                elem.get("nx").map_or(0.0, ply_prop_to_f32),
                elem.get("ny").map_or(0.0, ply_prop_to_f32),
                elem.get("nz").map_or(0.0, ply_prop_to_f32),
            ]);
        }

        if let Some((u_key, v_key)) = uv_keys {
            tex_coords_vec.push([
                elem.get(u_key).map_or(0.0, ply_prop_to_f32),
                elem.get(v_key).map_or(0.0, ply_prop_to_f32),
            ]);
        }

        if has_colors {
            let alpha = if has_alpha {
                elem.get("alpha").map_or(1.0, ply_prop_to_channel)
            } else {
                1.0
            };
            colors_vec.push([
                srgb_to_linear(elem.get("red").map_or(0.0, ply_prop_to_channel)),
                srgb_to_linear(elem.get("green").map_or(0.0, ply_prop_to_channel)),
                srgb_to_linear(elem.get("blue").map_or(0.0, ply_prop_to_channel)),
                alpha,
            ]);
        }
    }

    let polygon_count = ply_faces.len();

    let mut indices: Vec<u32> = Vec::new();
    if let Some(mt_faces) = multi_tex_faces.filter(|_| has_multi_tex) {
        let geo_faces: Vec<Vec<u32>> = ply_faces
            .iter()
            .map(|face| {
                face.get("vertex_indices")
                    .or_else(|| face.get("vertex_index"))
                    .map(ply_prop_to_indices)
                    .unwrap_or_default()
            })
            .collect();

        let mut vert_map: std::collections::HashMap<(u32, u32), u32> =
            std::collections::HashMap::new();
        let mut final_positions: Vec<[f32; 3]> = Vec::new();
        let mut final_normals: Vec<[f32; 3]> = Vec::new();
        let mut final_uvs: Vec<[f32; 2]> = Vec::new();
        let mut final_colors: Vec<[f32; 4]> = Vec::new();

        for (fi, mt_face) in mt_faces.iter().enumerate() {
            let vis = if fi < geo_faces.len() {
                &geo_faces[fi]
            } else {
                continue;
            };
            let tex_vis = mt_face
                .get("texture_vertex_indices")
                .or_else(|| mt_face.get("texture_vertex_index"))
                .map(ply_prop_to_indices)
                .unwrap_or_default();

            let mut resolved = Vec::with_capacity(vis.len());
            for (vi_idx, &pos_idx) in vis.iter().enumerate() {
                let uv_idx = tex_vis.get(vi_idx).copied().unwrap_or(0);
                let key = (pos_idx, uv_idx);
                let final_idx = *vert_map.entry(key).or_insert_with(|| {
                    let idx = final_positions.len() as u32;
                    final_positions.push(positions[pos_idx as usize]);
                    if has_normals {
                        final_normals.push(normals_vec[pos_idx as usize]);
                    }
                    if has_colors {
                        final_colors.push(colors_vec[pos_idx as usize]);
                    }
                    if let Some(uv) = multi_tex_uvs.get(uv_idx as usize) {
                        final_uvs.push(*uv);
                    } else {
                        final_uvs.push([0.0, 0.0]);
                    }
                    idx
                });
                resolved.push(final_idx);
            }

            for i in 1..resolved.len().saturating_sub(1) {
                indices.push(resolved[0]);
                indices.push(resolved[i]);
                indices.push(resolved[i + 1]);
            }
        }

        positions = final_positions;
        normals_vec = final_normals;
        tex_coords_vec = final_uvs;
        colors_vec = final_colors;
    } else {
        for face in ply_faces {
            let vis = face
                .get("vertex_indices")
                .or_else(|| face.get("vertex_index"))
                .map(ply_prop_to_indices)
                .unwrap_or_default();
            for i in 1..vis.len().saturating_sub(1) {
                indices.push(vis[0]);
                indices.push(vis[i]);
                indices.push(vis[i + 1]);
            }
        }
    }

    let normals = if has_normals && !normals_vec.is_empty() {
        Some(normals_vec)
    } else {
        None
    };

    let tex_coords = if has_uvs && !tex_coords_vec.is_empty() {
        Some(tex_coords_vec)
    } else {
        None
    };

    let colors = if has_colors && !colors_vec.is_empty() {
        Some(colors_vec)
    } else {
        None
    };

    let mut materials = Vec::new();
    let companion_tex = if has_uvs { companion_tex } else { None };
    let mat_name = if companion_tex.is_some() {
        "ply_textured"
    } else {
        "clay_default"
    };
    // Only the values that differ from the material default are named; the
    // rest were an exhaustive restatement of `Default`.
    materials.push(RawMaterialData {
        name: mat_name.to_string(),
        diffuse_texture_path: companion_tex,
        roughness_factor: 0.5,
        alpha_cutoff: 0.5,
        ..RawMaterialData::default()
    });

    Ok(RawModelData {
        meshes: vec![RawMeshData {
            name: name.to_string(),
            positions,
            indices,
            normals,
            tex_coords,
            material_index: Some(0),
            topology: if is_point_cloud {
                MeshTopology::Points
            } else {
                MeshTopology::Triangles
            },
            colors,
        }],
        materials,
        polygon_count,
    })
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn ply_prop_to_f32_float() {
        assert!((ply_prop_to_f32(&Property::Float(1.5)) - 1.5).abs() < f32::EPSILON);
    }

    #[test]
    fn ply_prop_to_f32_double() {
        assert!((ply_prop_to_f32(&Property::Double(2.5)) - 2.5).abs() < f32::EPSILON);
    }

    #[test]
    fn ply_prop_to_f32_int() {
        assert!((ply_prop_to_f32(&Property::Int(42)) - 42.0).abs() < f32::EPSILON);
    }

    #[test]
    fn ply_prop_to_f32_uchar() {
        assert!((ply_prop_to_f32(&Property::UChar(255)) - 255.0).abs() < f32::EPSILON);
    }

    #[test]
    fn ply_prop_to_f32_list_returns_zero() {
        let prop = Property::ListInt(vec![1, 2, 3]);
        assert!((ply_prop_to_f32(&prop)).abs() < f32::EPSILON);
    }

    #[test]
    fn ply_prop_to_indices_list_int() {
        let prop = Property::ListInt(vec![0, 1, 2]);
        assert_eq!(ply_prop_to_indices(&prop), vec![0u32, 1, 2]);
    }

    #[test]
    fn ply_prop_to_indices_list_uint() {
        let prop = Property::ListUInt(vec![3, 4, 5]);
        assert_eq!(ply_prop_to_indices(&prop), vec![3u32, 4, 5]);
    }

    #[test]
    fn ply_prop_to_indices_list_uchar() {
        let prop = Property::ListUChar(vec![0, 1]);
        assert_eq!(ply_prop_to_indices(&prop), vec![0u32, 1]);
    }

    #[test]
    fn ply_prop_to_indices_scalar_empty() {
        let prop = Property::Float(1.0);
        assert!(ply_prop_to_indices(&prop).is_empty());
    }

    #[test]
    fn ply_prop_to_indices_negative_int_wraps() {
        let prop = Property::ListInt(vec![-1]);
        let result = ply_prop_to_indices(&prop);
        assert_eq!(result, vec![u32::MAX]);
    }

    #[test]
    fn ply_prop_to_f32_short_and_ushort() {
        assert!((ply_prop_to_f32(&Property::Short(-100)) - (-100.0)).abs() < f32::EPSILON);
        assert!((ply_prop_to_f32(&Property::UShort(60000)) - 60000.0).abs() < f32::EPSILON);
    }
}
