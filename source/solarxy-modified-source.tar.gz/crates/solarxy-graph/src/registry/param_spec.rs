//! Declarative parameter schemas.
//!
//! `ParamSpec` is what the parameter panel interprets and what the
//! resolver enforces. Conventions frozen here: hard range = validity
//! (engine-clamped in the resolver), soft range = the slider/drag range
//! (UI only); every angle is degrees in the document and UI with the
//! resolver converting to radians (`Unit::Degrees` drives both the suffix
//! and the conversion); `group` is presentation metadata, storage stays
//! flat.

use crate::params::ParamValue;

/// One selectable variant of an [`ParamType::Enum`] param.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct EnumVariant {
    pub key: String,
    pub label: String,
}

impl EnumVariant {
    #[must_use]
    pub fn new(key: impl Into<String>, label: impl Into<String>) -> Self {
        Self {
            key: key.into(),
            label: label.into(),
        }
    }
}

/// The parameter-editor vocabulary. Adding a variant is a deliberate
/// frontend change (a new editor widget must exist); everything else about
/// a node is zero-frontend-change by construction.
#[derive(Debug, Clone, PartialEq)]
pub enum ParamType {
    Float,
    Int,
    Bool,
    Text,
    /// Free text over several lines, edited in a plain auto-growing text
    /// area rather than a single-line input. Stores plain
    /// [`crate::params::ParamValue::Text`] exactly as [`ParamType::Text`]
    /// does, so switching a param between the two is not a migration and
    /// needs no `type_version` bump: the variant declares only the widget.
    ///
    /// Distinct from [`ParamType::Snippet`], which is also multi-line but is
    /// a *program* -- it carries a line-number gutter, syntax highlighting
    /// and cook-error line marking, none of which prose wants.
    MultilineText,
    /// A free-text attribute name whose editor offers the lanes present
    /// on the node's default Geometry input as completions. Stores plain
    /// [`crate::params::ParamValue::Text`] (documents round-trip with no
    /// migration); the widget, not the storage, is what this variant
    /// declares.
    AttributeName,
    /// A multi-line program, edited in a code editor with line numbers and
    /// error-line highlighting. Stores plain
    /// [`crate::params::ParamValue::Text`] exactly as `AttributeName` does,
    /// so documents round-trip with no migration and the variant declares
    /// only the widget.
    ///
    /// The stored text is *not* an expression: it is parsed by the wrangle's
    /// statement layer ([`crate::expr::stmt`]), which is why this type does
    /// not accept an expression source. A snippet that fails to parse is a
    /// cook error naming line and column.
    Snippet,
    Vec2,
    Vec3,
    Vec4,
    Color,
    Enum {
        variants: Vec<EnumVariant>,
    },
    /// A staged-asset reference with an extension accept-list
    /// (e.g. `[".stl"]`).
    AssetRef {
        accept: Vec<String>,
    },
    /// A properties-pane action button: no stored value of
    /// consequence (an inert Bool rides the slot so the schema stays
    /// uniform). The frontend renders the param's label as a button and
    /// routes the press through the host's `invoke_action`.
    Action,
    /// A cross-context node reference: references cross contexts by path,
    /// never by wire. The picker is
    /// constrained by `accept`; the stored value is the target's stable
    /// [`crate::document::NodeId`] (`ParamValue::NodeRef`).
    NodePath {
        accept: NodePathAccept,
    },
}

impl ParamType {
    /// Whether this type may be driven by an expression.
    ///
    /// The numeric types only. There is no string type in the expression
    /// value lattice, so there is literally nothing an expression could
    /// produce for a Text, `MultilineText`, `AttributeName` or Enum param;
    /// `AssetRef` and
    /// `NodePath` are identities rather than values; an Action carries no
    /// value at all; and a Snippet is already a program, evaluated per
    /// element by the wrangle rather than once by the resolver. `SetParam`
    /// refuses the rest up front rather than storing something that could
    /// only ever badge at cook time.
    #[must_use]
    pub fn accepts_expression(&self) -> bool {
        matches!(
            self,
            ParamType::Float
                | ParamType::Int
                | ParamType::Bool
                | ParamType::Vec2
                | ParamType::Vec3
                | ParamType::Vec4
                | ParamType::Color
        )
    }

    /// How this type reads in an error message.
    ///
    /// Deliberately separate from the camelCase wire names in
    /// `engine::snapshot`: those are a serialized contract under a drift
    /// gate, these are prose.
    #[must_use]
    pub fn describe(&self) -> &'static str {
        match self {
            ParamType::Float => "float",
            ParamType::Int => "integer",
            ParamType::Bool => "checkbox",
            ParamType::Text => "text",
            ParamType::MultilineText => "multi-line text",
            ParamType::AttributeName => "attribute name",
            ParamType::Snippet => "code snippet",
            ParamType::Vec2 => "vec2",
            ParamType::Vec3 => "vec3",
            ParamType::Vec4 => "vec4",
            ParamType::Color => "colour",
            ParamType::Enum { .. } => "menu",
            ParamType::AssetRef { .. } => "file reference",
            ParamType::Action => "action button",
            ParamType::NodePath { .. } => "node reference",
        }
    }
}

/// What a [`ParamType::NodePath`] param may point at. Covers the ratified
/// consumers concretely (material networks, texture networks, cameras)
/// without speculative generality; a new target shape is a new variant.
#[derive(Debug, Clone, PartialEq)]
pub enum NodePathAccept {
    /// Container nodes whose descriptor opens a network of this kind
    /// (a material reference accepts `Opens(Mat)` containers).
    Opens(crate::document::ContextKind),
    /// Nodes of one exact type (the render node's camera picker is
    /// `TypeIs("camera")`).
    TypeIs(String),
}

/// Unit annotation: drives the UI suffix and the resolver conversion
/// (degrees to radians) from one declaration.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Default)]
pub enum Unit {
    #[default]
    None,
    Degrees,
    Meters,
    Normalized,
}

/// Hard = validity (resolver-clamped); soft = the slider range (UI only).
/// Typed values may exceed soft but never hard.
#[derive(Debug, Clone, Copy, PartialEq)]
pub struct ParamRange {
    pub hard: (f64, f64),
    pub soft: Option<(f64, f64)>,
}

/// Predicate grammar for conditional visibility. Deliberately tiny
/// (no OR, no expressions) until a node needs more.
#[derive(Debug, Clone, PartialEq)]
pub enum Pred {
    Truthy,
    Eq(ParamValue),
    Neq(ParamValue),
    In(Vec<ParamValue>),
}

/// One visibility condition; a spec's `show_if` list ANDs them.
#[derive(Debug, Clone, PartialEq)]
pub struct ShowIf {
    pub param: String,
    pub pred: Pred,
}

/// One parameter's declaration.
#[derive(Debug, Clone, PartialEq)]
pub struct ParamSpec {
    /// Storage key, unique across the whole node (groups do not scope
    /// keys).
    pub key: String,
    pub label: String,
    /// Two-level presentation grouping (general, geometry, transform, ...).
    pub group: String,
    /// An optional labelled division inside the group, rendered as a
    /// heading above the runs of params that share it.
    ///
    /// A group is a tab, and the tab strip is a single non-wrapping row, so
    /// a node with many related families cannot afford a tab each. The
    /// material node is the first to hit that: one tab per property family
    /// overflows the panel, while dropping every property into one flat
    /// list loses which scalar belongs to which effect. A subgroup keeps
    /// broad tabs and says where the families start.
    ///
    /// Presentation only, exactly like `group`: storage stays flat, keys
    /// stay unique across the whole node, and a param with no subgroup
    /// simply renders where it sits.
    pub subgroup: Option<String>,
    pub ty: ParamType,
    pub default: ParamValue,
    pub range: Option<ParamRange>,
    pub step: Option<f64>,
    pub unit: Unit,
    /// AND semantics; empty means always visible.
    pub show_if: Vec<ShowIf>,
    /// The input-port key whose connection neutralizes this param (the
    /// material node's map-overrides-factor semantics). Declarative so the
    /// parameter panel can dim the row generically, with zero per-node
    /// frontend code; validated against the node's input ports by the
    /// registry invariants.
    pub driven_by_port: Option<String>,
    /// Per-param documentation (hover popover; wiki reference).
    pub doc: String,
}

impl ParamSpec {
    /// A spec with the required fields; chain the builders for the rest.
    #[must_use]
    pub fn new(
        key: impl Into<String>,
        label: impl Into<String>,
        group: impl Into<String>,
        ty: ParamType,
        default: ParamValue,
    ) -> Self {
        Self {
            key: key.into(),
            label: label.into(),
            group: group.into(),
            subgroup: None,
            ty,
            default,
            range: None,
            step: None,
            unit: Unit::None,
            show_if: Vec::new(),
            driven_by_port: None,
            doc: String::new(),
        }
    }

    /// Sets the hard range (doubles as the slider range when no soft
    /// range is given, matching the catalog convention).
    #[must_use]
    pub fn hard(mut self, min: f64, max: f64) -> Self {
        self.range = Some(ParamRange {
            hard: (min, max),
            soft: self.range.and_then(|r| r.soft),
        });
        self
    }

    /// Sets the soft (slider) range; requires a hard range.
    #[must_use]
    pub fn soft(mut self, min: f64, max: f64) -> Self {
        if let Some(range) = &mut self.range {
            range.soft = Some((min, max));
        } else {
            debug_assert!(false, "soft range without a hard range on '{}'", self.key);
        }
        self
    }

    #[must_use]
    pub fn step(mut self, step: f64) -> Self {
        self.step = Some(step);
        self
    }

    #[must_use]
    pub fn unit(mut self, unit: Unit) -> Self {
        self.unit = unit;
        self
    }

    #[must_use]
    pub fn show_if(mut self, param: impl Into<String>, pred: Pred) -> Self {
        self.show_if.push(ShowIf {
            param: param.into(),
            pred,
        });
        self
    }

    /// Declares that a connected edge on the named input port drives this
    /// param's channel (the param is neutralized while connected).
    #[must_use]
    pub fn driven_by_port(mut self, port: impl Into<String>) -> Self {
        self.driven_by_port = Some(port.into());
        self
    }

    /// Puts this param under a labelled division inside its group. See
    /// [`ParamSpec::subgroup`] for why the level exists.
    #[must_use]
    pub fn subgroup(mut self, subgroup: impl Into<String>) -> Self {
        self.subgroup = Some(subgroup.into());
        self
    }

    #[must_use]
    pub fn doc(mut self, doc: impl Into<String>) -> Self {
        self.doc = doc.into();
        self
    }
}
