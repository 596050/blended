//! Shared node-descriptor building blocks: the implicit `general` group,
//! the geo container's `rendering` group, the default geometry output
//! port, and the silent-strip migrations. These factor out the
//! catalog conventions so each node file declares
//! only what is specific to it.

use solarxy_kernel::copy::CopyMode;
use solarxy_kernel::transform::RotateOrder;

use crate::cook::{CookCtx, CookError, CookOutcome, Inputs, Outputs};
use crate::params::ParamValue;
use crate::registry::coerce::DataType;
use crate::registry::param_spec::{EnumVariant, ParamSpec, ParamType};
use crate::registry::resolve::ResolvedParams;
use crate::registry::{MigrateError, PortSpec};

/// The cook for a node that produces no wire output: containers (`geo`),
/// annotations (`note`), and the light nodes (whose `LightDef` is resolved
/// by the scene builder from their params, not carried on a wire). Emits
/// empty outputs, so the cook driver records it as cooked-clean without
/// geometry.
#[allow(clippy::unnecessary_wraps)] // signature matches CookFn
pub fn passive_cook(
    _p: &ResolvedParams,
    _in: &Inputs,
    _cx: &mut CookCtx,
) -> Result<CookOutcome, CookError> {
    Ok(CookOutcome::Done(Outputs::empty()))
}

/// The implicit `general` group every node carries: `name` (shown as the
/// node title, defaulting to the display name) and `description`. Passed
/// the display name so `name`'s default matches.
#[must_use]
pub fn general_params(display_name: &str) -> Vec<ParamSpec> {
    vec![
        ParamSpec::new(
            "name",
            "Name",
            "general",
            ParamType::Text,
            ParamValue::Text(display_name.to_string()),
        )
        .doc("The node's title on the canvas."),
        // Multi-line since 0.8.1: a description is prose, and a
        // single-line input made anything past a few words unreadable
        // while you typed it. Storage is unchanged (`ParamValue::Text`),
        // so this is a widget change, not a migration.
        ParamSpec::new(
            "description",
            "Description",
            "general",
            ParamType::MultilineText,
            ParamValue::Text(String::new()),
        )
        .doc("Free-text notes shown as the node subtitle."),
    ]
}

/// The `rendering` group on the `geo` container only (root render flags,
/// both wired end to end): additive visibility and per-object
/// shadow participation. Subflow geometry nodes carry no copy: per-object
/// flags are geo-level concepts, and the display flag is graph-level.
/// `receive_shadow` was dropped in the same phase (no per-object channel
/// into the PBR shadow term exists; see the expansion doc's backlog note).
#[must_use]
pub fn rendering_params() -> Vec<ParamSpec> {
    vec![
        ParamSpec::new(
            "visible",
            "Visible",
            "rendering",
            ParamType::Bool,
            ParamValue::Bool(true),
        )
        .doc(
            "Whether this object is displayed. Hidden objects stay cooked, \
              so re-show is instant.",
        ),
        ParamSpec::new(
            "cast_shadow",
            "Cast Shadow",
            "rendering",
            ParamType::Bool,
            ParamValue::Bool(true),
        )
        .doc("Whether this object is drawn into the shadow map."),
    ]
}

/// Removes raw param keys before the registry-default migration sees them,
/// so a deliberate drop produces no load warning (the dropped params never
/// did anything; a toast about them would be noise).
pub(super) fn strip_keys(params: &mut serde_json::Map<String, serde_json::Value>, keys: &[&str]) {
    for key in keys {
        params.remove(*key);
    }
}

/// v1 -> v2 for the subflow geometry nodes: their whole `rendering` group
/// was dead by design (the display flag is graph-level; per-object flags
/// are geo-level) and is silently stripped.
#[allow(clippy::unnecessary_wraps)] // signature matches MigrateFn
pub fn migrate_strip_rendering_group(
    from: u32,
    params: &mut serde_json::Map<String, serde_json::Value>,
) -> Result<(), MigrateError> {
    if from == 1 {
        strip_keys(params, &["visible", "cast_shadow", "receive_shadow"]);
    }
    Ok(())
}

/// The six Euler orders. Shared by `transform` and `geo` so the two cannot
/// drift apart again: they had, with `geo` hardcoding ZYX in its world matrix
/// while `transform` defaulted to XYZ, so the same angles typed into each
/// produced two different orientations.
#[must_use]
pub fn rotate_order_variants() -> Vec<EnumVariant> {
    ["xyz", "xzy", "yxz", "yzx", "zxy", "zyx"]
        .into_iter()
        .map(|k| EnumVariant::new(k, k.to_uppercase()))
        .collect()
}

/// The `rotate_order` param, identical on every node that composes a rotation.
///
/// Documented here rather than at each call site, so `transform` and the
/// `geo` container cannot drift into describing the same control two ways.
#[must_use]
pub fn rotate_order_param() -> ParamSpec {
    ParamSpec::new(
        "rotate_order",
        "Rotate Order",
        "transform",
        ParamType::Enum {
            variants: rotate_order_variants(),
        },
        ParamValue::Enum("xyz".to_string()),
    )
    .doc(
        "The order the three Euler angles are applied in. Rotations do not \
         commute, so the same three numbers land the object differently \
         depending on this: XYZ rotates about X first, then Y, then Z.\n\n\
         Change it only when matching another package's convention, or when \
         an axis you are animating has ended up gimbal-locked against \
         another. If a rotation is behaving unintuitively, this is usually \
         the reason.",
    )
}

/// Maps the stored variant key onto the kernel's order. An unknown key falls
/// back to the default rather than failing a cook.
#[must_use]
pub fn rotate_order_from_key(key: &str) -> RotateOrder {
    match key {
        "xzy" => RotateOrder::Xzy,
        "yxz" => RotateOrder::Yxz,
        "yzx" => RotateOrder::Yzx,
        "zxy" => RotateOrder::Zxy,
        "zyx" => RotateOrder::Zyx,
        _ => RotateOrder::Xyz,
    }
}

/// The `geo` container's migrations.
///
/// v1 -> v2: `receive_shadow` is dropped (never wired; re-adding it is an
/// instance-flags backlog note), silently.
///
/// v2 -> v3: `geo` gains `rotate_order`, and its world matrix moves from a
/// hardcoded `T * Rz * Ry * Rx * S` onto the kernel's `compose_trs`, which
/// defaults to XYZ. Left alone, that would silently re-orient every existing
/// geo. So a v2 geo whose `rotate` has two or more nonzero lanes -- the only
/// case where the order is observable at all -- gets `zyx` stamped explicitly,
/// preserving its appearance exactly. A geo with one or zero nonzero lanes
/// rotates identically under either order, so it keeps the new default and the
/// document stays clean.
#[allow(clippy::unnecessary_wraps)] // signature matches MigrateFn
pub fn migrate_geo(
    from: u32,
    params: &mut serde_json::Map<String, serde_json::Value>,
) -> Result<(), MigrateError> {
    if from == 1 {
        strip_keys(params, &["receive_shadow"]);
    }
    if from == 2 && !params.contains_key("rotate_order") && geo_rotate_order_is_observable(params) {
        // The bare enum key, matching the raw stored shape. The wrapped
        // `ParamSource` form does not type on the way back in.
        params.insert(
            "rotate_order".to_string(),
            serde_json::Value::String("zyx".to_string()),
        );
    }
    Ok(())
}

/// Whether a stored `rotate` has two or more nonzero lanes, which is exactly
/// when the composition order changes the resulting orientation.
///
/// Reads the RAW stored shape: a migration runs before schema typing, so a
/// `Vec3` arrives as a bare three-element array and an expression as the
/// `$expr` object. Deserializing the typed `ParamSource` here instead never
/// matched anything a document actually holds, so this always answered no
/// and the migration above never ran once in production.
fn geo_rotate_order_is_observable(params: &serde_json::Map<String, serde_json::Value>) -> bool {
    let Some(raw) = params.get("rotate") else {
        return false;
    };
    let Some(lanes) = raw.as_array() else {
        // An expression, or something unreadable: leave it at the default
        // rather than guess. An expression cannot be evaluated here anyway.
        return false;
    };
    lanes
        .iter()
        .filter(|lane| lane.as_f64().is_some_and(|angle| angle != 0.0))
        .count()
        >= 2
}

/// The `copy_mode` param, identical on both copy operations.
///
/// Documented here rather than at each call site for the same reason
/// [`rotate_order_param`] is: `copy_to_points` and `array` offer the same
/// choice, and two copies of the explanation would drift into describing one
/// control two ways. Only the presentation group differs, so it is passed in.
///
/// The key is `copy_mode` rather than `mode` because `array` already carries a
/// `mode` holding Linear and Radial, and because it is what the kernel calls
/// the argument.
#[must_use]
pub fn copy_mode_param(group: &str) -> ParamSpec {
    ParamSpec::new(
        "copy_mode",
        "Copy Mode",
        group,
        ParamType::Enum {
            variants: vec![
                EnumVariant::new("instance", "Instance"),
                EnumVariant::new("bake", "Bake"),
            ],
        },
        ParamValue::Enum("instance".to_string()),
    )
    .doc(
        "Whether the copies are real geometry or placements of one \
         prototype.\n\n\
         Instance keeps the input once and carries a transform per copy. Ten \
         thousand copies of a five-thousand-triangle rock cost five thousand \
         triangles rather than fifty million, so the copy count stops being \
         the number you budget against.\n\n\
         What it costs is what the rest of the graph can see. Downstream \
         nodes are handed the prototype and the placements, never the \
         individual copies, so there is no per-copy attribute edit, no \
         boolean against one copy, and no deleting the third one from the \
         left: those copies do not exist as geometry. This is the difference \
         between copying and instancing rather than a fast path and a slow \
         one.\n\n\
         Bake makes every copy real, which is what you choose when the \
         copies have to be edited afterwards. It is no harder to author, and \
         it answers a different question rather than an outdated one.",
    )
}

/// Maps the stored variant key onto the kernel's mode. An unknown key falls
/// back to the default rather than failing a cook, matching
/// [`rotate_order_from_key`].
#[must_use]
pub fn copy_mode_from_key(key: &str) -> CopyMode {
    match key {
        "bake" => CopyMode::Bake,
        _ => CopyMode::Instance,
    }
}

/// v1 -> v2 for the two copy operations (`copy_to_points` and `array`): both
/// gain [`copy_mode_param`], whose default is Instance.
///
/// Every v1 node was authored against an engine that could only bake, so Bake
/// is not a preference those nodes expressed; it is the behavior their authors
/// saw and built the rest of the graph around. Left to inherit the new
/// default, a saved scene would open with its copies collapsed into one
/// prototype and every downstream node reading something different, with
/// nothing on screen to say why. So the value is written in explicitly.
///
/// A node that somehow already carries the key keeps it, so re-running the
/// step is a no-op rather than an overwrite.
///
/// The value written is the BARE enum key, because migrations run on the raw
/// stored JSON, which holds a plain value per param (the one object form is
/// `{"$expr": ...}`) rather than a serialized `ParamSource`. Writing the
/// wrapped form instead fails to type on the way back in.
#[allow(clippy::unnecessary_wraps)] // signature matches MigrateFn
pub fn migrate_pin_copy_mode_to_bake(
    from: u32,
    params: &mut serde_json::Map<String, serde_json::Value>,
) -> Result<(), MigrateError> {
    if from == 1 && !params.contains_key("copy_mode") {
        params.insert(
            "copy_mode".to_string(),
            serde_json::Value::String("bake".to_string()),
        );
    }
    Ok(())
}

/// v1 -> v2 for `rect_area_light`: the v1 soft point-light approximation
/// never read `rotate` / `scale` / `uniform_scale`; they return with a
/// real LTC area-light model (backlog note). Silently stripped.
///
/// v3 -> v4 additionally rescales the stored intensity, for the reason
/// [`migrate_scale_intensity`] gives.
pub fn migrate_strip_rect_area_transform(
    from: u32,
    params: &mut serde_json::Map<String, serde_json::Value>,
) -> Result<(), MigrateError> {
    if from == 1 {
        strip_keys(params, &["rotate", "scale", "uniform_scale"]);
    }
    if from == 3 {
        scale_stored_intensity(from, params)?;
    }
    Ok(())
}

/// v1 -> v2 for the point, directional and spot lights: the raster path
/// stopped multiplying every light's contribution by three, so a stored
/// intensity has to move by the same factor to mean what it did.
///
/// **Only the four lights that entered that loop migrate.** Ambient and
/// hemisphere fold into the hemisphere rows of the light uniform and never
/// reached the multiplier, so their stored values already meant what they
/// said and scaling them would be a three-fold brightening of every old
/// scene that used one. Rect-area is the fourth and migrates on its own
/// hook, because it was already at v3 for an unrelated reason.
pub fn migrate_scale_intensity(
    from: u32,
    params: &mut serde_json::Map<String, serde_json::Value>,
) -> Result<(), MigrateError> {
    if from == 1 {
        scale_stored_intensity(from, params)?;
    }
    Ok(())
}

/// The factor the raster path used to apply behind the user's back.
const INTENSITY_RESCALE: f64 = 3.0;

/// Multiply a stored `intensity` by [`INTENSITY_RESCALE`], in the raw
/// stored shape.
///
/// Three cases, and the third is the one worth having a rule for:
///
/// - **Absent.** Nothing to do. The param fills from the registry default,
///   which moved by the same factor, so the light keeps its brightness.
/// - **A number.** Multiplied.
/// - **An expression** (`{"$expr": ...}`, the only object form a stored
///   param takes). Left alone and reported. Rewriting the source text
///   would mean parsing and re-emitting a user's expression to inject a
///   factor, which is a transformation with no safe general form; leaving
///   it silently would make that one light three times dimmer than the
///   rest of the scene with nothing said. The migration loop turns the
///   error into a load warning naming the node, so it surfaces where the
///   user can act on it.
fn scale_stored_intensity(
    from: u32,
    params: &mut serde_json::Map<String, serde_json::Value>,
) -> Result<(), MigrateError> {
    let Some(stored) = params.get("intensity") else {
        return Ok(());
    };
    if let Some(n) = stored.as_f64() {
        if let Some(scaled) = serde_json::Number::from_f64(n * INTENSITY_RESCALE) {
            params.insert("intensity".to_string(), serde_json::Value::Number(scaled));
        }
        return Ok(());
    }
    Err(MigrateError {
        from,
        reason: format!(
            "this light's Intensity is an expression, and light intensity is now a plain \
             linear scale rather than one the renderer multiplied by {INTENSITY_RESCALE:.0} \
             behind it. The expression was left as written, so this light is now \
             {INTENSITY_RESCALE:.0} times dimmer than it was; multiply it by \
             {INTENSITY_RESCALE:.0} to restore it"
        ),
    })
}

/// Warns when a lane is written under a reserved attribute name with a
/// type other than its contractual one: the write succeeds (free-form
/// lanes are legal), but every consumer of the reserved name will ignore
/// it, which is surprising enough to say out loud. `written` is the
/// node's type enum key (`float`/`vec2`/`vec3`/`vec4`).
pub(super) fn warn_reserved_lane_mismatch(cx: &mut CookCtx, name: &str, written: &str) {
    use solarxy_kernel::reserved;
    let contractual = if name == reserved::COLOR {
        Some("vec4")
    } else if name == reserved::NORMAL {
        Some("vec3")
    } else if name == reserved::UV {
        Some("vec2")
    } else if name == reserved::PSCALE {
        Some("float")
    } else {
        None
    };
    if let Some(expected) = contractual
        && expected != written
    {
        cx.warn(format!(
            "the reserved attribute `{name}` carries {expected} by contract; \
             a {written} lane under that name is ignored by its consumers"
        ));
    }
}

/// Warns when the lane a node is about to write replaces (or shadows, for
/// the fixed `N`/`uv` buffers) an INPUT lane of a different type: the
/// write is legal, but downstream consumers keyed to the old type stop
/// matching, which deserves saying out loud. `written` is the node's type
/// enum key. Resolution is first-seen across meshes, the `attr_table`
/// convention.
pub(super) fn warn_input_lane_type_replaced(
    cx: &mut CookCtx,
    input: &solarxy_kernel::GeometrySet,
    name: &str,
    written: &str,
) {
    let existing = input
        .meshes
        .iter()
        .find_map(|m| crate::engine::attr_table::resolve_lane(m, name))
        .map(|l| l.ty());
    if let Some(existing) = existing
        && existing != written
    {
        cx.warn(format!(
            "`{name}` on the input is {existing}; this cook replaces it              with a {written} lane"
        ));
    }
}

/// The default geometry output port, key `geometry` (every geometry node's
/// single default output).
#[must_use]
pub fn geometry_output() -> PortSpec {
    PortSpec::single("geometry", "Geometry", DataType::Geometry, false)
        .default_port()
        .doc(
            "The cooked geometry. Being the default output, a drag from the \
             node's body wires from here, and a bypass passes the input \
             through it.",
        )
}

/// Assembles a node's full param list: `general`, then the node-specific
/// groups. (The `rendering` group is geo-container-only;
/// `geo_node` appends it explicitly.)
#[must_use]
pub fn params_with(display_name: &str, specific: Vec<ParamSpec>) -> Vec<ParamSpec> {
    let mut params = general_params(display_name);
    params.extend(specific);
    params
}
