struct Camera {
    view_pos: vec4<f32>,
    view_proj: mat4x4<f32>,
    view: mat4x4<f32>,
    proj: mat4x4<f32>,
    inv_proj: mat4x4<f32>,
    near: f32,
    far: f32,
    inspection_mode: u32,
    texel_density_target: f32,
    material_override: u32,
    depth_near: f32,
    depth_far: f32,
}
@group(0) @binding(0)
var<uniform> camera: Camera;

struct VertexInput {
    @location(0) position: vec3<f32>,
    @location(1) tex_coords: vec2<f32>,
    @location(2) normal: vec3<f32>,
    @location(3) tangent: vec3<f32>,
    @location(4) bitangent: vec3<f32>,
}

struct InstanceInput {
    @location(5) model_matrix_0: vec4<f32>,
    @location(6) model_matrix_1: vec4<f32>,
    @location(7) model_matrix_2: vec4<f32>,
    @location(8) model_matrix_3: vec4<f32>,
    @location(9) normal_matrix_0: vec3<f32>,
    @location(10) normal_matrix_1: vec3<f32>,
    @location(11) normal_matrix_2: vec3<f32>,
}

struct FillOutput {
    @builtin(position) clip_position: vec4<f32>,
    @location(0) tex_coords: vec2<f32>,
}

@vertex
fn vs_uv_fill(model: VertexInput, instance: InstanceInput) -> FillOutput {
    var out: FillOutput;
    let uv_pos = vec4(model.tex_coords.x, 1.0 - model.tex_coords.y, 0.0, 1.0);
    out.clip_position = camera.view_proj * uv_pos;
    out.tex_coords = model.tex_coords;
    return out;
}

@group(1) @binding(0) var tex_input: texture_2d<f32>;
@group(1) @binding(1) var tex_input_sampler: sampler;

@fragment
fn fs_uv_checker(in: FillOutput) -> @location(0) vec4<f32> {
    return textureSample(tex_input, tex_input_sampler, in.tex_coords);
}

@fragment
fn fs_uv_texture(in: FillOutput) -> @location(0) vec4<f32> {
    return textureSample(tex_input, tex_input_sampler, in.tex_coords);
}
