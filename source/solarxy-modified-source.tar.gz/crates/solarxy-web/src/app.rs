//! The `SolarxyApp` wasm-bindgen class: the browser host over the engine
//! and the full `solarxy-renderer` pipeline (the stopgap forward renderer
//! it started on is retired).
//!
//! The React frontend holds one instance: it dispatches `Command`s (in) and
//! receives `EventBatch`es (out), calls `frame` each rAF tick to cook under
//! a budget and render every pane, routes pointer gestures to the per-pane
//! cameras, and mirrors the host-owned view state (`ViewStateDto` returns +
//! `take_host_events`). Cooked geometry never crosses into JavaScript.
//!
//! Architecture: this file is the web port of the desktop shell's
//! `state/render.rs` + `state/update.rs` orchestration, minus egui. The
//! scene environment (lights, shadow, grid/floor) is a
//! [`SceneEnvironment`] rebuilt when the scene bounds move; geometry
//! arrives through `SceneObjects` deltas; pane geometry comes from the
//! shared `solarxy_renderer::panes` math, so the F1-F5 layouts are the
//! same rectangles the desktop produces.

use std::collections::BTreeMap;

use cgmath::{InnerSpace, Point3, Vector3};
use serde::{Deserialize, Serialize};
use solarxy_core::preferences::{
    BackgroundMode, IblMode, InspectionMode, PaneMode, ProjectionMode, ResolvedBackground, ToneMode,
};
use solarxy_core::raycast::{Ray, screen_to_world_ray};
use solarxy_core::scene::{SceneDelta, SceneObjectId, SceneOp};
use solarxy_core::validation::{
    ValidationConfig, ValidationResult, ValidationThresholds, validate_raw_model_with_config,
};
use solarxy_core::view_config::{
    DisplaySettings, PaneDisplaySettings, PaneEngine, PaneLook, ViewLayout,
};
use solarxy_core::geometry::compute_bounds;
use solarxy_core::AABB;
use solarxy_graph::assets::AssetTable;
use solarxy_graph::cook::{ImportOptions, JobId, JobRequest, JobResult, ParsedModel};
use solarxy_graph::document::{GraphContext, NodeId};
use solarxy_graph::engine::{EngineEvent, GizmoTarget, SceneSidecar};
use solarxy_graph::params::{ParamSource, ParamValue};
use solarxy_graph::{Command, Engine, EventBatch};
use solarxy_kernel::transfer;
use solarxy_renderer::manipulator::{self, ManipulatorState};

use solarxy_host::{HostViewState, RasterBackend};
use solarxy_host::attr_viz::{AttrColorMode, AttrVizState, ramp_color};
use solarxy_host::display_defaults::{self, DisplayDefaults};
use solarxy_core::gizmo::TransformParams;
use solarxy_host::gizmo::{self, GizmoPose, GizmoState, ToolMode};
use solarxy_renderer::camera::{turntable_up, Camera};
use solarxy_renderer::camera_state::CameraState;
use solarxy_renderer::composite::CompositeLook;
use solarxy_renderer::lut::LutSlot;
use solarxy_renderer::environment::SceneEnvironment;
use solarxy_renderer::backend::{FrameCtx, FrameOutcome, PaneContent, RenderBackend, UvSource};
use solarxy_renderer::pathtrace::backend::{PathBackend, TraceSettings};
use solarxy_renderer::pathtrace::denoise::DenoiseSettings;
use solarxy_renderer::capture::CaptureTarget;
use solarxy_renderer::frame::{Renderer, RendererInit};
use solarxy_renderer::geometry::build_normals_geometry;
use solarxy_renderer::model::{GizmoVertex, NormalsGeometry};
use solarxy_renderer::input::PointerButton;
use solarxy_renderer::light::LightsUniform;
use solarxy_renderer::panes::{self, PaneRect};
use solarxy_renderer::visualization::grid_plane_for;
use solarxy_renderer::scene::{create_light_bind_group, lights_from_camera, BackgroundModeExt};
use solarxy_renderer::scene_objects::SceneObjects;
use solarxy_renderer::visualization::VisualizationState;
use wasm_bindgen::prelude::*;
use wasm_bindgen::JsCast;

/// The synchronous cook budget per frame, in milliseconds (about half a
/// 60fps frame, leaving headroom for render + the browser).
const COOK_BUDGET_MS: f64 = 6.0;
const MSAA_SAMPLES: u32 = 4;
const SHADOW_MAP_SIZE: u32 = 2048;

/// The current host time in milliseconds (`performance.now`).
///
/// Monotonic and high-resolution, counting from page load. Right for
/// measuring how long a cook took; useless as a date, which is why node
/// timestamps use `web_epoch_ms` instead.
fn web_now() -> f64 {
    web_sys::window()
        .and_then(|w| w.performance())
        .map_or(0.0, |p| p.now())
}

/// The current wall time in Unix milliseconds (`Date.now`).
///
/// The counterpart to `web_now`: coarse and not monotonic (it moves when
/// the system clock is set), but it is an actual date, which is what a
/// node's created / modified stamp has to be.
fn web_epoch_ms() -> f64 {
    js_sys::Date::now()
}

/// The console policy, in one place: a clean boot of a shipped build is
/// SILENT, so the first message a user ever sees in the console means
/// something. Informational output therefore lives behind the off-by-default
/// `diagnostics` feature, gated at the call site as well, so a shipped
/// artifact carries neither the call nor its strings. Failures are the
/// opposite case: they go through [`error`], which is always present and
/// writes to `console.error`, where the crash reporter's interception sees
/// them. A panic stays legible through `console_error_panic_hook`, which is
/// untouched by any of this.
#[cfg(feature = "diagnostics")]
fn log(msg: &str) {
    web_sys::console::log_1(&JsValue::from_str(msg));
}

/// A failure, reported. Always compiled in: the `diagnostics` gate covers
/// chatter, never problems, so nothing can accidentally silence one. Writes
/// through `console.error` so the crash reporter's last-error capture
/// (`web/src/telemetry.ts`) can attach it to a report.
fn error(msg: &str) {
    web_sys::console::error_1(&JsValue::from_str(msg));
}

/// Placeholder scene bounds before anything cooks (frames the grid).
fn default_bounds() -> AABB {
    solarxy_renderer::environment::placeholder_bounds()
}

/// The pane display defaults every pane starts from (desktop parity:
/// shaded, gradient background, grid on).
fn default_pane_settings() -> PaneDisplaySettings {
    use solarxy_core::preferences::{
        LineWeight, MaterialOverride, NormalsMode, UvMapBackground, UvMode, ViewMode,
    };
    use solarxy_core::view_config::BoundsMode;
    PaneDisplaySettings {
        view_mode: ViewMode::Shaded,
        prev_non_ghosted_mode: ViewMode::Shaded,
        ghosted_wireframe: false,
        normals_mode: NormalsMode::Off,
        background_mode: BackgroundMode::GRADIENT,
        uv_mode: UvMode::Off,
        bounds_mode: BoundsMode::Off,
        // The enum's own default (Light), matching the desktop; the user's
        // persisted preference overwrites this at boot via
        // `set_display_defaults`.
        line_weight: LineWeight::default(),
        show_grid: true,
        show_axis_gizmo: false,
        show_local_axes: false,
        inspection_mode: InspectionMode::Shaded,
        material_override: MaterialOverride::None,
        texel_density_target: 1.0,
        pane_mode: PaneMode::Scene3D,
        uv_bg: UvMapBackground::Dark,
        uv_offset: [0.0, 0.0],
        uv_zoom: 1.0,
        show_uv_overlap: false,
        show_validation: false,
        // On: a light with no marker is invisible, and this is the shell that
        // can grab one.
        show_light_markers: true,
        turntable_active: false,
        pane_engine: PaneEngine::Raster,
    }
}

fn default_display_settings() -> DisplaySettings {
    DisplaySettings {
        turntable_active: false,
        turntable_rpm: 6.0,
        lights_locked: false,
        layout: ViewLayout::Single,
        split_ratio: DisplaySettings::DEFAULT_SPLIT_RATIO,
        roughness_scale: 1.0,
        metallic_scale: 1.0,
        hdri_rotation: 0.0,
        hdri_intensity: solarxy_core::view_config::DEFAULT_HDRI_INTENSITY,
        point_size: solarxy_core::view_config::DEFAULT_POINT_SIZE,
    }
}

/// The key a pane's look rides under inside `PaneJson::display`.
///
/// That field is declared opaque and round-tripped uninterpreted by the
/// scene file, which makes it the right place for pane state the schema
/// does not name: persisting here costs no `schema_version` bump and no
/// `min_reader` gate, and a scene written before this existed simply has
/// no such key.
const PANE_LOOK_KEY: &str = "look";

// This shell's view state is `solarxy_host::HostViewState` plus four fields
// held directly on `SolarxyApp`: `pane_looks`, `look_through`, `camera_locked`
// and `camera_editing`. Those four describe panes looking through `camera`
// nodes, and the desktop shell has no camera nodes until it gains an engine,
// so they stay here rather than sitting on the shared type as fields one
// consumer sets and the other never reads. Same judgement the shared crate
// makes about a renderer trait: one consumer is not yet something to share.

/// Async happenings the frontend drains once per frame.
///
/// `rename_all_fields` is load-bearing and was missing. `rename_all` on an
/// enum renames the VARIANTS and nothing else, so a multi-word field went out
/// in snake case while `web/src/engine/types.ts` declared it camel: the
/// frontend read `undefined` and said so in the interface. Every single-word
/// field hid it, and `renderProgress` was the first variant to carry one that
/// was not, which is why the still dialog's elapsed and remaining readouts
/// were blank. The engine's `Command` enum has carried both attributes from
/// the start; this one now matches it.
#[derive(Serialize)]
#[serde(
    tag = "type",
    rename_all = "camelCase",
    rename_all_fields = "camelCase"
)]
enum HostEvent {
    /// Pane rectangles changed (layout, split, or resize), in CSS pixels.
    PaneRects { rects: Vec<RectDto> },
    /// The hovered (active) pane changed via pointer routing.
    ActivePane { pane: usize },
    /// The UV overlap readback advanced: a fresh percentage, or a pending
    /// run (`pct` holds the stale value or `None` while computing).
    UvOverlap { pct: Option<f32>, pending: bool },
    /// Host-side pointer input mutated view state (UV pan/zoom); the
    /// frontend refreshes its view-state mirror.
    ViewChanged,
    /// The attribute-label sampling facts changed (cook, lane, toggle, cap
    /// edit): `capacity` labels drawn of `total` displayed points; the
    /// strip's sampling notice reads `capacity < total`. Total rides f64
    /// for the 53-bit JS number boundary.
    AttrPinStats { capacity: u32, total: f64 },
    /// A still render advanced: which tile of how many, and how many samples
    /// of how many within it. `done` is set on the frame the last tile lands,
    /// which is what closes a modal's progress out.
    RenderProgress {
        tile: u32,
        tiles: u32,
        sample: u32,
        samples: u32,
        done: bool,
        /// How long the render has taken, and how much longer it will take.
        ///
        /// `remaining_ms` is absent while there is not enough to say, which is
        /// the first chunks of a render and the moment after the last one. A
        /// confident wrong number is worse than an honest blank, so the shape
        /// says so rather than sending a zero the dialog would have to guess
        /// about.
        elapsed_ms: f64,
        remaining_ms: Option<f64>,
    },
    /// The renderer left something out of the scene it just ingested.
    ///
    /// Pushed once when a traced render starts rather than when it finishes,
    /// because the useful moment to learn that your curves will not be in the
    /// picture is before you wait for the picture.
    RenderNotice { message: String },
    /// A traced pane's accumulation advanced: how many samples its mean
    /// averages, of the preview's target. The counter that marks a
    /// converging image as converging. Pushed on change, not per frame.
    PaneSamples {
        pane: usize,
        samples: u32,
        target: u32,
    },
    /// What the current selection can be manipulated with: the tools that
    /// apply to it, and the parameters its transform is made of.
    ///
    /// One answer to two questions, deliberately. The tool column greys out
    /// what is missing and the context menu resets exactly these params, and
    /// deriving the second from the first somewhere in the frontend would put
    /// a second opinion about what a light is where there should be none.
    ///
    /// Pushed on change rather than polled: a selection changes far less often
    /// than a frame ticks.
    SelectionCapability {
        tools: Vec<&'static str>,
        transform_params: Vec<&'static str>,
    },
    /// The device reported an uncaptured graphics fault. The frontend
    /// writes the full message to `console.error`, which the crash
    /// reporter attaches to its next report as context, and toasts a
    /// short pointer at it. `count` collapses identical consecutive
    /// errors, since a fault in a per-frame path fires at frame rate.
    GpuFault {
        kind: &'static str,
        message: String,
        count: u32,
    },
}

#[derive(Serialize, Clone, Copy, PartialEq)]
struct RectDto {
    x: f32,
    y: f32,
    width: f32,
    height: f32,
}

/// A detailed pick result (the review anchor source); canvas coordinates in,
/// mesh/face/barycentric/world out.
#[derive(Serialize)]
#[serde(rename_all = "camelCase")]
struct PickDetailDto {
    node: f64,
    mesh: u32,
    face: u32,
    barycentric: [f32; 3],
    world_pos: [f32; 3],
    distance: f32,
    pane: usize,
}

/// One marker pin's screen position (canvas CSS px) in one pane. Deliberately
/// minimal: category/resolved/stale ride the structure channel
/// (`review_annotations`), which refreshes on `reviewChanged`.
#[derive(Serialize)]
#[serde(rename_all = "camelCase")]
struct MarkerScreenDto {
    id: f64,
    pane: usize,
    x: f32,
    y: f32,
}

/// What a `render` node says, as the frontend displays it.
///
/// Produced by the engine rather than assembled by the frontend, which is the
/// point: the browser and a headless command resolve the same document through
/// one rule instead of two that agree until they do not. It travels out for the
/// dialog to show and never travels back in, because a render is asked for by
/// naming the node.
#[derive(Serialize)]
#[serde(rename_all = "camelCase")]
// A mirror of the node's own parameters, and the node has four independent
// switches. Grouping them into a sub-struct to satisfy the count would put a
// shape on the boundary that the document does not have.
#[allow(clippy::struct_excessive_bools)]
struct RenderSettingsDto {
    width: u32,
    height: u32,
    samples: u32,
    engine: String,
    bounces: u32,
    transmissive_bounces: u32,
    denoise: bool,
    /// The `camera` node to shoot through, or `null` to shoot the active
    /// pane's current view.
    ///
    /// The still never moves a pane. A shot is a property of the scene and the
    /// viewport is where someone happens to be looking, so the job builds its
    /// own camera from this and leaves every pane where it was.
    camera: Option<f64>,
    /// The auxiliary passes the run writes beside the image.
    ///
    /// The production half of the pass model: what a render *makes*. Which of
    /// them a window *shows* is a separate control that lives in the window,
    /// because wanting to watch the normal pass to understand what the denoiser
    /// is steering by is a different intention from wanting the albedo written
    /// because a compositor asked for it.
    aov_albedo: bool,
    aov_normal: bool,
    aov_depth: bool,
    /// Whether the render carries a matte. The window reads it for two
    /// things a picture cannot say about itself: showing the checker only
    /// behind a render that actually has transparency, and routing the
    /// eight-bit save through the engine's own encoder, whose straight alpha
    /// a canvas round trip would corrupt.
    transparent_background: bool,
}

impl From<solarxy_graph::nodes::RenderSettings> for RenderSettingsDto {
    fn from(s: solarxy_graph::nodes::RenderSettings) -> Self {
        Self {
            width: s.width,
            height: s.height,
            samples: s.samples,
            engine: match s.engine {
                solarxy_graph::nodes::RenderEngine::PathTraced => "pathTraced",
                solarxy_graph::nodes::RenderEngine::Raster => "raster",
            }
            .to_string(),
            bounces: s.bounces,
            transmissive_bounces: s.transmissive_bounces,
            denoise: s.denoise,
            #[allow(clippy::cast_precision_loss)]
            camera: s.camera.map(|n| n.0 as f64),
            aov_albedo: s.aov_albedo,
            aov_normal: s.aov_normal,
            aov_depth: s.aov_depth,
            transparent_background: s.transparent_background,
        }
    }
}

/// A screenshot request: capture resolution (physical pixels) plus the
/// GPU-side overlay toggles (DOM layers like markers never appear in a GPU
/// capture; compositing them is a JS concern).
#[derive(Deserialize, Clone, Copy)]
#[serde(rename_all = "camelCase")]
struct ScreenshotOptsDto {
    width: u32,
    height: u32,
    overlays: ScreenshotOverlaysDto,
}

#[derive(Deserialize, Clone, Copy)]
#[serde(rename_all = "camelCase")]
struct ScreenshotOverlaysDto {
    grid: bool,
    axes: bool,
    validation: bool,
}

/// The Solarxy browser application: one WebGPU surface, the full renderer,
/// the multi-object scene, the scene environment, per-pane cameras, and
/// the headless engine.
#[wasm_bindgen]
// Four bools, and clippy is right to ask. They stay separate because they
// share nothing: `uv_use_preview` is a UV-pane source choice, `player_mode`
// is a session mode, and the two `*_dirty` flags are per-frame recompute
// latches. A sub-struct would put one name over four unrelated things and
// make every read longer without making any of them clearer.
#[allow(clippy::struct_excessive_bools)]
pub struct SolarxyApp {
    /// Kept for the asset-preview pane: a second surface (its own canvas)
    /// must come from the same instance as the device.
    instance: wgpu::Instance,
    surface: wgpu::Surface<'static>,
    device: wgpu::Device,
    queue: wgpu::Queue,
    config: wgpu::SurfaceConfiguration,
    /// The asset-preview pane's isolated render state, when open.
    preview: Option<PreviewState>,
    /// The (sRGB) format render pipelines target; the surface view is
    /// created with this format each frame (Chrome offers only non-sRGB
    /// surface formats, so it rides `view_formats`).
    render_format: wgpu::TextureFormat,
    renderer: Renderer,
    raster: solarxy_host::RasterBackend,
    env: SceneEnvironment,
    /// Makes `SceneOp::SetEnvironment` idempotent. The engine re-emits the
    /// whole environment on every rebuild and installing one convolves an
    /// irradiance cubemap, so this remembers what is already on the GPU.
    /// Invalidated by `set_environment_prepared` and `clear_environment`,
    /// which move the IBL behind the scene contract's back.
    environment: solarxy_renderer::environment::EnvironmentTracker,
    /// The bounds `env` was last built for (grid/floor/shadow fit).
    env_bounds: AABB,
    view: HostViewState,
    /// Each pane's own rendering intent, used when the pane is a free view. A
    /// pane looking through a camera composites with that camera's look
    /// instead; see `SolarxyApp::pane_look`.
    pane_looks: [PaneLook; 4],
    /// Which `camera` node each pane looks through (`None` = free view).
    look_through: [Option<NodeId>; 4],
    /// Whether a look-through pane is locked so navigation reframes the camera
    /// node. Only meaningful when the same slot's `look_through` is `Some`.
    camera_locked: [bool; 4],
    /// Transient: a locked look-through pane is mid-navigation, so the
    /// node-to-pane follow is suppressed until the gesture commits (it would
    /// otherwise fight live navigation). Not persisted.
    camera_editing: [bool; 4],
    engine: Engine,
    host_events: Vec<HostEvent>,
    /// The uncaptured-error queue the shared device hook fills; drained
    /// into `host_events` when the frontend takes them each frame.
    gpu_faults: solarxy_renderer::faults::GpuFaults,
    last_pane_rects: Vec<RectDto>,
    /// Device pixel ratio: JS pointer coordinates arrive in CSS px and are
    /// scaled into physical canvas px for pane hit-testing and picking.
    dpr: f32,
    pointer_buttons_down: u32,
    /// The viewport tool, plus any hover highlight and drag in flight. The drag
    /// loop runs entirely host-side; JS only ever calls `set_tool`.
    gizmo: GizmoState,
    /// Where the in-flight drag's result is addressed.
    ///
    /// Parallel to `gizmo.drag` rather than inside it. The drag solver lives in
    /// `solarxy-host`, which deliberately knows nothing about documents, so it
    /// solves a *pose* and this shell remembers which node the answer belongs
    /// to. The two are only ever ended together, through `take_gizmo_drag`, so
    /// they cannot drift apart into a drag that commits to nowhere.
    gizmo_addr: Option<GizmoAddr>,
    /// The live drag's delta text, rebuilt each pointer move and polled once per
    /// frame by the shell. `None` whenever nothing is being dragged.
    gizmo_readout: Option<String>,
    /// The last capability pushed to the frontend, so the event fires on
    /// change rather than every frame. `None` means nothing manipulable is
    /// selected, which is a distinct answer from an empty tool list.
    last_capability: Option<(Vec<&'static str>, Vec<&'static str>)>,
    /// The scene object tinted as selected in the viewports,
    /// or `None`.
    selected_object: Option<SceneObjectId>,
    /// Validate jobs drained from the engine but not yet handed to the
    /// worker: the geometry is packed to a transfer blob at drain time so
    /// `take_validate_jobs` moves plain bytes.
    pending_validate: Vec<PendingValidateJob>,
    pending_image: Vec<PendingImageJob>,
    pending_hdri: Vec<PendingHdriJob>,
    /// The graph context the node canvas currently shows (React mirrors it
    /// via `set_current_context`); the UV pane's selected-node source
    /// resolves against it.
    current_ctx: GraphContext,
    /// The UV pane's selected-node preview: a one-object scene holding the
    /// selected node's cooked geometry, uploaded on demand and deduped by
    /// attribute-`Arc` identity like the main scene.
    uv_scene: SceneObjects,
    /// Whether the UV pane draws the selected-node preview (a subflow
    /// selection with committed geometry) or falls back to the selected /
    /// first scene object.
    uv_use_preview: bool,
    /// Identity of the last UV source (node id + geometry Arc address);
    /// a change invalidates the overlap statistic.
    last_uv_source: Option<(u64, usize)>,
    /// The last (pct, pending) pushed as a `UvOverlap` host event.
    last_overlap: (Option<f32>, bool),
    /// Last physical-pixel pointer position (UV pan deltas).
    last_pointer: (f32, f32),
    /// The loaded HDRI environment's staged-asset identity (content hash +
    /// original name), for the `.slxy` environment section. `None` when the
    /// procedural sky is active.
    hdri: Option<HdriMeta>,
    /// Player mode: the host runs a published scene rather than an editing
    /// session. Suppresses the manipulator, picking and review markers, and
    /// locks the layout to one pane.
    ///
    /// A flag on the editor host rather than a second wasm target: a lean
    /// player crate would mean a second boot path and a second
    /// payload gate that could drift from this one, for a saving nobody has
    /// measured. The follow-up is recorded with an instruction to measure
    /// first.
    player_mode: bool,
    /// A screenshot request captured this frame (rendered at frame end).
    screenshot_request: Option<ScreenshotOptsDto>,
    /// A turntable-export frame request: (pane, absolute azimuth in degrees,
    /// opts). Rendered offscreen at frame end from a rotated clone of the
    /// pane's render-through camera, through the same capture slot as the
    /// screenshot. The frontend drives one frame at a time.
    turntable_request: Option<(usize, f32, ScreenshotOptsDto)>,
    /// The in-flight screenshot readback (one at a time).
    pending_screenshot: Option<solarxy_renderer::capture::PendingCapture>,
    /// The camera the running still shoots through, owned by the job rather
    /// than borrowed from a pane, so rendering never moves the view.
    still_camera: Option<solarxy_renderer::camera_state::CameraState>,
    /// The look that camera carries, resolved once when the job starts.
    ///
    /// The camera owns the look as of 0.8.2, so a still through camera X gets
    /// X's exposure, tone map and grade rather than whichever pane happened to
    /// be active. Resolved at start rather than per tile because a look that
    /// changed mid-render would band the picture at a tile boundary.
    still_look: CompositeLook,
    /// The running still render, if any.
    ///
    /// While this is `Some` the frame loop renders the job instead of the
    /// panes: the shared targets are sized to the tile for the job's duration,
    /// and a viewport rendering at layout size in the same frame would resize
    /// them back twice a frame for the length of the render.
    still: Option<solarxy_host::StillRenderJob>,
    /// The tracer, built the first time a traced still is asked for. A session
    /// that never renders one never pays for the pipelines.
    tracer: Option<solarxy_renderer::pathtrace::backend::PathBackend>,
    /// Whether the tracer's environment is behind the scene's.
    ///
    /// Set where the image behind the IBL actually changes, not where the
    /// environment op arrives: the engine re-emits that op on every rebuild,
    /// and installing on every one would upload the distribution once a cook.
    /// Read lazily when a traced render starts, so a session that never traces
    /// pays nothing for the tables.
    traced_env_dirty: bool,
    /// Finished tiles waiting for the frontend to take them.
    still_tiles: std::collections::VecDeque<solarxy_host::still::StillTile>,
    /// The picture so far, waiting for the frontend to take it. Separate from
    /// the tiles because a preview is painted and never saved.
    still_previews: std::collections::VecDeque<solarxy_host::still::StillPreview>,
    /// When the running still began, on the page's own timer. The elapsed a
    /// reader sees is measured from here rather than from the first tile, so it
    /// includes the setup a person also waited through.
    still_started_ms: f64,
    /// The auxiliary planes being assembled, when any were asked for.
    still_passes: Option<StillPasses>,
    /// What the render was *asked* for, as albedo, normal, depth.
    ///
    /// Kept beside the planes because the spec's two flags cannot answer it:
    /// albedo and normal share one store, so a spec that says `aux` does not
    /// say which of the two a person wanted, and a selector offering a pass
    /// nobody asked for would be offering something the file will not contain.
    still_pass_request: [bool; 3],
    /// Whether the engine drawing this still writes auxiliary passes at all.
    ///
    /// Capability rather than identity, resolved once when the render starts.
    /// A window asks this rather than which backend is running, which is the
    /// rule the backend contract states and the same one the terminal's
    /// selector follows.
    still_writes_aovs: bool,
    /// The floating-point image being assembled, when the running still is a
    /// float one. `None` for the ordinary eight-bit still, which is assembled
    /// on a canvas the browser owns and never needs a copy here.
    still_float: Option<solarxy_host::still::FloatImage>,
    /// Whether the traced preview runs its edge-aware filter.
    ///
    /// A preference rather than a per-pane setting, matching the two effects
    /// it sits beside in the panel: it describes how the preview is built,
    /// not what any one pane is showing.
    preview_denoise: bool,
    /// Per-pane camera identity the traced preview last accumulated under.
    /// A mismatch on encode resets that pane's accumulation, which is what
    /// makes the preview converge only while the pane is quiescent.
    traced_cam_keys: [Option<[f32; 13]>; 4],
    /// The environment scalars the tracer last integrated against; a
    /// change resets every traced pane, since the mean was of another sky.
    traced_env_params: (f32, f32),
    /// The last per-pane sample counts pushed to the frontend, so the
    /// counter event fires on change rather than every frame.
    last_pane_samples: [Option<(u32, u32)>; 4],
    /// Whether the normals/bounds visualization aggregate is stale
    /// (geometry changed, env rebuilt, or an overlay mode just turned on).
    viz_dirty: bool,
    /// Host-owned attribute visualization (session-only, scene-wide; never
    /// saved into `.slxy`, never in undo). The strip's toggles and the
    /// picked lane name.
    attr_viz: AttrVizState,
    /// Theme label colors (text, chip, dot) as last pushed by the frontend.
    /// Cached because the style is assembled from two independent halves
    /// (see `push_label_style`), and a size change must not blank the
    /// palette any more than a theme change must reset the size.
    label_colors: [[f32; 3]; 3],
    /// Whether the attribute-vector line buffer is stale (mirrors the
    /// `viz_dirty` sites, plus any `set_attr_viz`).
    attr_dirty: bool,
    /// The preference-backed display defaults (wireframe weight,
    /// background), pushed from the TS prefs store. Pane seeds, never a
    /// force-override: a loaded scene's saved per-pane settings win.
    display_defaults: DisplayDefaults,
}

/// Where a gizmo drag's result is written: the engine half of a drag, which
/// the pose-only solver in `solarxy-host` does not carry.
#[derive(Clone, Copy)]
struct GizmoAddr {
    ctx: GraphContext,
    node: NodeId,
}

/// The solver's view of an engine gizmo target: the pose, without the
/// addressing or the append bookkeeping.
/// Everything one pane's encode and composite read that is derived from
/// the host rather than handed in by the frame loop.
struct PaneInputs {
    background: ResolvedBackground,
    bounds: AABB,
    look: CompositeLook,
    scene_present: bool,
    outline: bool,
    grid_plane: Option<u32>,
    /// Whether this pane's 3D content goes to the tracer instead of the
    /// rasterizer this frame. Decided (and its housekeeping run) before
    /// the pane content is built, because the content can borrow the UV
    /// preview scene while the housekeeping needs the whole host.
    traced: bool,
}

/// What the traced preview converges to. High enough that a resting pane
/// keeps improving for minutes at one sample per frame, low enough that
/// the counter's target still means something.
const PREVIEW_TARGET_SAMPLES: u32 = 4096;

/// The largest floating-point still the browser will assemble, in pixels.
///
/// Not the eight-bit limit, which stays at the job's own 8192 edge. A float
/// save holds three `f32` a pixel in this module's heap while the render runs
/// and then encodes from them, so the peak is roughly forty bytes a pixel
/// against the canvas path's four, inside a thirty-two-bit address space that
/// is also holding the document, the tracer's buffers and the page. Sixteen
/// megapixels puts the peak near 290 MB, which a tab can be asked for. A
/// transparent render keeps its fourth channel and holds sixteen bytes a
/// pixel instead of twelve, which moves that peak to roughly 350 MB at the
/// same ceiling; the ceiling deliberately does not move for it, because a
/// limit that shifted with a checkbox would be two limits wearing one name.
///
/// The same shape as the screenshot path's four-megapixel ceiling, and for the
/// same reason: a limit with a stated number beats an allocation failure,
/// which on wasm takes the whole tab rather than the operation.
const MAX_FLOAT_STILL_PIXELS: u64 = 16_000_000;

/// The most memory the auxiliary planes may take, for one render.
///
/// Stated in bytes rather than pixels because that is what the limit is about:
/// the auxiliary store is sixteen bytes a pixel and the depth four, so twenty
/// together, and a ceiling written as a pixel count would have to be rewritten
/// the moment a fourth pass existed. At this budget a 4096 by 2304 still, which
/// is the largest this release measures, fits with room over.
///
/// The planes are held whole rather than per tile because they have to be:
/// the depth display normalizes over the range of the whole picture, so a plane
/// mapped tile by tile would band at every seam.
const MAX_PASS_PLANE_BYTES: u64 = 192 * 1024 * 1024;

/// Pixels as megapixels, for a message a person reads.
#[allow(clippy::cast_precision_loss)]
fn megapixels(pixels: u64) -> f64 {
    pixels as f64 / 1_000_000.0
}

/// The auxiliary planes a still is keeping, when any were asked for.
///
/// Held as the bytes the job hands back rather than as typed floats, because
/// that is what the shared display mappings read and what the extraction
/// helpers read on the way to a file. One conversion, at the point that needs
/// one, rather than a conversion on every tile.
struct StillPasses {
    width: u32,
    height: u32,
    /// `width * height * 16`: albedo in the first three lanes of every four,
    /// the packed normal in the fourth. One store, because the kernel writes
    /// one and asking for either pass fetches both.
    aux: Option<Vec<u8>>,
    /// `width * height * 4`.
    depth: Option<Vec<u8>>,
}

impl StillPasses {
    /// The planes this run will keep, or `None` when it asked for none.
    fn new(spec: &solarxy_host::still::StillSpec) -> Option<Self> {
        if !spec.aux && !spec.depth {
            return None;
        }
        let pixels = (spec.width as usize) * (spec.height as usize);
        Some(Self {
            width: spec.width,
            height: spec.height,
            aux: spec.aux.then(|| vec![0u8; pixels * 16]),
            depth: spec.depth.then(|| vec![0u8; pixels * 4]),
        })
    }

    /// What the planes will cost, for the refusal that happens before the
    /// render rather than during it.
    fn cost(spec: &solarxy_host::still::StillSpec) -> u64 {
        let pixels = u64::from(spec.width) * u64::from(spec.height);
        let per_pixel = u64::from(spec.aux) * 16 + u64::from(spec.depth) * 4;
        pixels * per_pixel
    }

    fn place(&mut self, tile: &solarxy_host::still::StillTile) {
        if let (Some(dst), Some(src)) = (self.aux.as_mut(), tile.aux.as_ref()) {
            place_plane(dst, self.width, self.height, tile.rect, src, 16);
        }
        if let (Some(dst), Some(src)) = (self.depth.as_mut(), tile.depth.as_ref()) {
            place_plane(dst, self.width, self.height, tile.rect, src, 4);
        }
    }
}

/// Copies one tile's plane into its place in the whole one.
///
/// Row by row rather than pixel by pixel: a plane is contiguous within a row
/// and the stride is the only thing that differs between the two.
fn place_plane(
    dst: &mut [u8],
    width: u32,
    height: u32,
    rect: solarxy_host::still::TileRect,
    src: &[u8],
    bytes_per_pixel: usize,
) {
    let row_bytes = rect.width as usize * bytes_per_pixel;
    for row in 0..rect.height {
        let y = rect.y + row;
        if y >= height || rect.x >= width {
            continue;
        }
        let dst_at = (y as usize * width as usize + rect.x as usize) * bytes_per_pixel;
        let src_at = row as usize * row_bytes;
        if let (Some(slot), Some(bytes)) = (
            dst.get_mut(dst_at..dst_at + row_bytes),
            src.get(src_at..src_at + row_bytes),
        ) {
            slot.copy_from_slice(bytes);
        }
    }
}

/// The traced preview's settings: one sample per animation frame (the
/// pacing that keeps the page responsive), half resolution, and the
/// edge-aware filter, which defaults on because a one-sample frame is
/// unusable without it. Asserted before every preview encode rather than
/// held, since the still job authors its own settings on the same backend.
///
/// The filter is the one value a person can turn off, and the reason to is
/// judging what the tracer actually produced rather than what the filter
/// made of it, which matters most at the sample counts where the filter is
/// doing the most work.
fn preview_trace_settings(denoise: bool) -> TraceSettings {
    TraceSettings {
        samples: PREVIEW_TARGET_SAMPLES,
        chunk: 1,
        denoise,
        resolution_scale: 0.5,
        ..TraceSettings::default()
    }
}

/// The fields of a camera a traced accumulation is valid under. Aspect
/// included, because a resize reshapes every ray; the projection kind
/// rides as a discriminant.
fn camera_key(c: &Camera) -> [f32; 13] {
    [
        c.eye.x,
        c.eye.y,
        c.eye.z,
        c.target.x,
        c.target.y,
        c.target.z,
        c.up.x,
        c.up.y,
        c.up.z,
        c.fovy,
        c.aspect,
        c.ortho_scale,
        match c.projection {
            solarxy_core::preferences::ProjectionMode::Perspective => 0.0,
            solarxy_core::preferences::ProjectionMode::Orthographic => 1.0,
        },
    ]
}

fn gizmo_pose(t: &GizmoTarget) -> GizmoPose {
    GizmoPose {
        translate: t.translate,
        rotate: t.rotate,
        rotate_order: t.rotate_order,
        scale: t.scale,
        uniform_scale: t.uniform_scale,
        extent: t.extent,
        aim: t.aim,
        params: t.params,
        anchor: t.anchor,
        aim_anchor: t.aim_anchor,
        basis: t.basis,
        parent_basis: t.parent_basis,
        parent: t.parent,
    }
}

/// The parameter writes one solved drag value makes on one target: each key
/// the target declares for that drag, paired with the value for it.
///
/// Lives here rather than on `DragValue` because `ParamSource` is an engine
/// type and the solver's crate has no engine dependency. Pairing happens in
/// one place so preview, commit and rollback cannot disagree about which key
/// gets which number; the two sides are positional, and
/// `the_keys_and_the_values_of_a_drag_are_always_the_same_length` in the
/// solver keeps them the same length.
fn drag_writes(
    value: gizmo::DragValue,
    params: &TransformParams,
) -> Vec<(&'static str, ParamSource)> {
    let Some(keys) = value.param().keys(params) else {
        return Vec::new();
    };
    keys.iter()
        .zip(value.values().into_iter().flatten())
        .map(|(key, v)| {
            let value = match v {
                gizmo::DragScalarOrVec3::Vec3(v) => {
                    ParamValue::Vec3([f64::from(v[0]), f64::from(v[1]), f64::from(v[2])])
                }
                gizmo::DragScalarOrVec3::Scalar(f) => ParamValue::Float(f64::from(f)),
            };
            (key, ParamSource::Literal(value))
        })
        .collect()
}

/// Identity of the loaded HDRI (its bytes live in the engine asset table).
#[derive(Clone)]
struct HdriMeta {
    hash: String,
    name: String,
}

/// The scene-object id reserved for the UV pane's selected-node preview
/// (far outside the engine's node-derived id space).
const UV_PREVIEW_ID: SceneObjectId = SceneObjectId(u64::MAX);

/// One stashed `ValidateGeometry` job awaiting worker dispatch.
struct PendingValidateJob {
    ctx: GraphContext,
    job_id: u64,
    blob: Vec<u8>,
    config_json: String,
    budget: Option<u32>,
}

/// A drained `DecodeImage` job awaiting [`SolarxyApp::take_image_jobs`]:
/// the frontend pulls the encoded bytes by hash (like the parse pump) and
/// decodes them in the import worker via `createImageBitmap`.
struct PendingImageJob {
    ctx: GraphContext,
    job_id: u64,
    hash: String,
    name: String,
}

/// A drained `DecodeHdrImage` job awaiting [`SolarxyApp::take_hdri_jobs`].
/// Same shape as an image job; it exists separately because the frontend
/// routes it to a different worker entry point (no browser codec reads
/// Radiance or `OpenEXR`, so the Rust decoder runs in the worker).
struct PendingHdriJob {
    ctx: GraphContext,
    job_id: u64,
    hash: String,
    name: String,
}

#[wasm_bindgen]
impl SolarxyApp {
    /// Boots over a canvas: WebGPU surface/device/queue, the full renderer
    /// (`uv_checker_png` is the checker texture asset the shell ships), the
    /// scene environment, and the engine with the host clock installed.
    #[allow(clippy::too_many_lines)] // linear boot sequence; splitting obscures it
    pub async fn create(
        canvas: web_sys::HtmlCanvasElement,
        uv_checker_png: Vec<u8>,
    ) -> Result<SolarxyApp, JsError> {
        let window = web_sys::window().ok_or_else(|| JsError::new("no window"))?;
        let dpr = window.device_pixel_ratio();
        let css_w = f64::from(canvas.client_width().max(1));
        let css_h = f64::from(canvas.client_height().max(1));
        let width = (css_w * dpr) as u32;
        let height = (css_h * dpr) as u32;
        canvas.set_width(width);
        canvas.set_height(height);

        let instance = wgpu::Instance::new(&wgpu::InstanceDescriptor {
            backends: wgpu::Backends::BROWSER_WEBGPU,
            ..Default::default()
        });
        let surface = instance
            .create_surface(wgpu::SurfaceTarget::Canvas(canvas))
            .map_err(|e| JsError::new(&format!("create_surface: {e}")))?;
        let adapter = instance
            .request_adapter(&wgpu::RequestAdapterOptions {
                power_preference: wgpu::PowerPreference::HighPerformance,
                compatible_surface: Some(&surface),
                force_fallback_adapter: false,
            })
            .await
            .map_err(|e| JsError::new(&format!("request_adapter: {e}")))?;
        let (device, queue) = adapter
            .request_device(&wgpu::DeviceDescriptor {
                label: Some("solarxy-web device"),
                required_features: wgpu::Features::empty(),
                experimental_features: wgpu::ExperimentalFeatures::disabled(),
                required_limits: solarxy_renderer::limits::required_limits(&adapter.limits()),
                memory_hints: wgpu::MemoryHints::default(),
                trace: wgpu::Trace::Off,
            })
            .await
            .map_err(|e| JsError::new(&format!("request_device: {e}")))?;

        // Before anything uses the device. The browser's own default for
        // an uncaptured error is a console line nobody reads; this routes
        // it through the host event stream so the frontend can toast it
        // and the crash reporter can attach it.
        let gpu_faults = solarxy_renderer::faults::install(&device);

        // Chrome exposes only non-sRGB surface formats; render into an
        // sRGB view of the surface texture so the tone-mapped composite
        // output is gamma-encoded correctly.
        let caps = surface.get_capabilities(&adapter);
        let base_format = caps
            .formats
            .iter()
            .find(|f| f.is_srgb())
            .copied()
            .unwrap_or(caps.formats[0]);
        let render_format = base_format.add_srgb_suffix();
        let view_formats = if render_format == base_format {
            vec![]
        } else {
            vec![render_format]
        };
        let config = wgpu::SurfaceConfiguration {
            usage: wgpu::TextureUsages::RENDER_ATTACHMENT,
            format: base_format,
            width,
            height,
            present_mode: caps.present_modes[0],
            alpha_mode: caps.alpha_modes[0],
            view_formats,
            desired_maximum_frame_latency: 2,
        };
        surface.configure(&device, &config);

        // The renderer builds its pipelines against the sRGB view format.
        let render_config = wgpu::SurfaceConfiguration {
            format: render_format,
            view_formats: vec![],
            ..config.clone()
        };
        let background = BackgroundMode::GRADIENT.resolve(&[]);
        let (sky_top, sky_bottom) = background.sky_colors();
        let init = RendererInit {
            msaa_sample_count: MSAA_SAMPLES,
            gradient_top: [0.35, 0.41, 0.47, 1.0],
            gradient_bottom: [0.66, 0.70, 0.72, 1.0],
            sky_top,
            sky_bottom,
            wireframe_color: background.wireframe_color(),
            // Only the seed for the renderer's first frame: every pane's real
            // weight arrives through `PaneDisplaySettings::line_weight` (see
            // the per-pane `width_px()` reads below). Taken from the shared
            // default rather than naming a variant, because this hardcoded
            // `Medium` silently disagreed with the desktop's persisted
            // `Light` default, so the same scene drew different wireframes in
            // the two shells out of the box.
            wireframe_line_width: solarxy_core::preferences::LineWeight::default().width_px(),
            // Match the desktop's shipped defaults. Both stayed hard false
            // for six releases, which left the AO Preview mode a white
            // screen and bloom inert in every browser; the preference
            // toggles arrive through `set_display_defaults` below.
            bloom_enabled: true,
            ssao_enabled: true,
            tone_mode: ToneMode::AcesFilmic,
            exposure: 1.0,
            ibl_mode: IblMode::Full,
            uv_checker_png: &uv_checker_png,
        };
        let renderer = Renderer::new(&device, &queue, &render_config, &init)
            .map_err(|e| JsError::new(&format!("Renderer::new: {e}")))?;
        // Built before the renderer moves into the host: the backend keeps its
        // own handle on the layouts so it can upload without being handed the
        // renderer back.
        let raster = solarxy_host::RasterBackend::new(std::sync::Arc::clone(&renderer.layouts));

        let bounds = default_bounds();
        let vis = VisualizationState::new_from_parts(
            &device,
            &renderer.layouts,
            &bounds,
            &[],
            None,
            background.grid_color(),
        );
        let mut env = SceneEnvironment::new(
            &device,
            &queue,
            &renderer.layouts,
            &bounds,
            width as f32 / height.max(1) as f32,
            &renderer.ibl_res.brdf_lut,
            &renderer.ibl_res.ltc,
            SHADOW_MAP_SIZE,
            vis,
        );
        env.light_bind_group = create_light_bind_group(
            &device,
            &renderer.layouts,
            &env.light_buffer,
            &renderer.ibl_res.ibl,
            &renderer.ibl_res.brdf_lut,
            &renderer.ibl_res.ltc,
        );

        let mut engine = Engine::new().map_err(|e| JsError::new(&format!("engine: {e}")))?;
        engine.set_clock(web_now);
        engine.set_epoch_clock(web_epoch_ms);
        // Imports run off the main thread: cooks yield a ParseModel job the
        // frontend pumps to the import worker (`take_import_jobs` ->
        // `submit_parsed_model`), rather than parsing inline.
        engine.set_async_jobs(true);

        #[cfg(feature = "diagnostics")]
        log(&format!(
            "solarxy-web: booted ({width}x{height}, {} node types, full renderer)",
            engine.registry().len()
        ));

        Ok(SolarxyApp {
            instance,
            surface,
            device,
            queue,
            config,
            render_format,
            renderer,
            preview: None,
            raster,
            env,
            environment: solarxy_renderer::environment::EnvironmentTracker::default(),
            env_bounds: bounds,
            view: HostViewState {
                pane_settings: [default_pane_settings(); 4],
                display: default_display_settings(),
                cameras: [None, None, None, None],
                active_pane: 0,
                cameras_linked: false,
            },
            pane_looks: [PaneLook::default(); 4],
            look_through: [None; 4],
            camera_locked: [false; 4],
            camera_editing: [false; 4],
            engine,
            host_events: Vec::new(),
            gpu_faults,
            player_mode: false,
            last_pane_rects: Vec::new(),
            dpr: dpr as f32,
            pointer_buttons_down: 0,
            selected_object: None,
            pending_validate: Vec::new(),
            pending_image: Vec::new(),
            pending_hdri: Vec::new(),
            current_ctx: GraphContext::Root,
            uv_scene: SceneObjects::new(),
            uv_use_preview: false,
            last_uv_source: None,
            last_overlap: (None, false),
            last_pointer: (0.0, 0.0),
            hdri: None,
            screenshot_request: None,
            turntable_request: None,
            pending_screenshot: None,
            still: None,
            still_camera: None,
            still_look: CompositeLook::default(),
            tracer: None,
            traced_env_dirty: true,
            still_tiles: std::collections::VecDeque::new(),
            still_previews: std::collections::VecDeque::new(),
            still_started_ms: 0.0,
            still_passes: None,
            still_pass_request: [false; 3],
            still_writes_aovs: false,
            still_float: None,
            // On, matching the shipped behaviour, until a preference push
            // says otherwise; boot pushes one before the first traced frame.
            preview_denoise: true,
            traced_cam_keys: [None; 4],
            traced_env_params: (0.0, 0.0),
            last_pane_samples: [None; 4],
            viz_dirty: true,
            attr_viz: AttrVizState::default(),
            label_colors: {
                let d = solarxy_renderer::labels::LabelStyle::new_default();
                [d.text, d.chip, d.dot]
            },
            attr_dirty: false,
            display_defaults: DisplayDefaults::default(),
            gizmo: GizmoState::default(),
            gizmo_addr: None,
            gizmo_readout: None,
            last_capability: None,
        })
    }

    /// Applies one command, returning the `EventBatch` for the mirror.
    pub fn dispatch(&mut self, cmd: JsValue) -> Result<JsValue, JsError> {
        let command: Command = serde_wasm_bindgen::from_value(cmd)
            .map_err(|e| JsError::new(&format!("bad command: {e}")))?;
        let batch = self
            .engine
            .apply(command)
            .map_err(|e| JsError::new(&format!("{e}")))?;
        to_js(&batch)
    }

    /// A transient param preview during a drag: no event, no undo, but it
    /// dirties the node so the next `frame` previews it. `ctx`/`value` are
    /// the same serde shapes as inside a `Command`.
    pub fn preview_param(
        &mut self,
        ctx: JsValue,
        node: f64,
        key: &str,
        value: JsValue,
    ) -> Result<(), JsError> {
        let ctx = serde_wasm_bindgen::from_value(ctx)
            .map_err(|e| JsError::new(&format!("bad ctx: {e}")))?;
        let value = serde_wasm_bindgen::from_value(value)
            .map_err(|e| JsError::new(&format!("bad value: {e}")))?;
        self.engine.preview_param(
            ctx,
            solarxy_graph::document::NodeId(node as u64),
            key,
            value,
        );
        Ok(())
    }

    /// Cooks under a frame budget, applies the scene delta, renders every
    /// pane, and returns the cook `EventBatch` (status + stats).
    pub fn frame(&mut self, dt_ms: f64) -> Result<JsValue, JsError> {
        // The clock advances BEFORE the cook, so this frame's geometry is
        // this frame's time. Fixed step (one tick is one frame), so a heavy
        // scene plays slowly rather than skipping and `$T` stays exactly
        // `frame / fps`. A stopped clock returns immediately.
        let mut events = self.engine.tick().events;

        // Cook the dirty set under a wall-clock budget.
        let deadline = web_now() + COOK_BUDGET_MS;
        events.extend(self.engine.cook(&mut || web_now() < deadline));

        // Apply the fresh scene delta to the multi-object scene.
        let delta = self.engine.take_scene_delta();
        if !delta.ops.is_empty() {
            self.viz_dirty = true;
            self.attr_dirty = true;
            self.raster.apply(&self.device, &self.queue, &delta);
            // The backend collects upload failures rather than logging them:
            // it has no logging facility and this host is the layer that knows
            // where a message belongs.
            //
            // A console line alone was not enough. A mesh the device cannot
            // hold is refused here, and the whole symptom that reported it
            // was a viewport that stopped drawing with nothing in the
            // interface saying why, so the refusal rides the same notice
            // channel the renderer's other omissions use and reaches the
            // user as a toast.
            for e in self.raster.take_errors() {
                error(&format!("scene delta apply failed: {e}"));
                self.host_events.push(HostEvent::RenderNotice {
                    message: e.to_string(),
                });
            }
            self.apply_scene_environment(&delta);
        }
        self.feed_traced_preview(&delta);

        self.sync_gizmo();

        self.sync_env_bounds();
        self.sync_visualization();
        self.sync_attr_channels();
        self.sync_uv_preview();
        self.ensure_pane_cameras();
        self.follow_look_through_cameras();
        // `f64::clamp` RETURNS NaN for a NaN input (every comparison with NaN is
        // false), so the clamp alone is not a guard. A non-finite delta reaching
        // a camera transition integrates straight into eye/target, and the next
        // projection panics inside cgmath with a NaN far plane. Callers are
        // supposed to pass a real frame delta; treat anything else as one frame.
        let dt_ms = if dt_ms.is_finite() { dt_ms } else { 16.0 };
        let dt = (dt_ms / 1000.0).clamp(0.0, 0.1) as f32;
        // Live turntable spin: a constant angular velocity on each pane
        // whose toggle is on. rpm is the global display setting; the spin is
        // session-temporary (reset on load) and drives the pane's scratch camera.
        let rpm = self.view.display.turntable_rpm;
        if rpm.abs() > 1e-6 {
            let yaw = rpm * std::f32::consts::TAU / 60.0 * dt;
            for i in 0..self.view.cameras.len() {
                if self.view.pane_settings[i].turntable_active
                    && let Some(cam) = self.view.cameras[i].as_mut()
                {
                    cam.inject_orbit_yaw(yaw);
                }
            }
        }
        for cam in self.view.cameras.iter_mut().flatten() {
            cam.update(&self.queue, dt);
        }
        self.update_lights();
        self.sync_render_target_dims();

        // Render every pane into the surface.
        let output = match self.surface.get_current_texture() {
            Ok(frame) => frame,
            Err(wgpu::SurfaceError::Outdated | wgpu::SurfaceError::Lost) => {
                self.surface.configure(&self.device, &self.config);
                return to_js(&EventBatch {
                    revision: self.engine.revision(),
                    events,
                });
            }
            Err(e) => return Err(JsError::new(&format!("acquire: {e}"))),
        };
        let surface_view = output.texture.create_view(&wgpu::TextureViewDescriptor {
            format: Some(self.render_format),
            ..Default::default()
        });

        let pane_rects = self.compute_panes();
        if self.still.is_some() {
            // The job owns the frame. The surface is acquired and presented
            // anyway so the browser does not treat the canvas as stalled, and
            // it keeps whatever the last ordinary frame left on it.
            self.pump_still_render();
        } else {
            let is_split = pane_rects.len() > 1;
            for (i, pane) in pane_rects.iter().enumerate() {
                self.render_pane(i, *pane, &surface_view, is_split);
            }
        }
        output.present();

        // Pump the overlap readback and mirror its progress to React.
        self.renderer.uv_overlap.poll_readback(&self.device);
        let overlap = (
            self.renderer.uv_overlap.overlap_pct,
            self.renderer.uv_overlap.readback_pending,
        );
        if overlap != self.last_overlap {
            self.last_overlap = overlap;
            self.host_events.push(HostEvent::UvOverlap {
                pct: overlap.0,
                pending: overlap.1,
            });
        }

        self.push_pane_rects_if_changed(&pane_rects);

        // A requested screenshot renders offscreen at capture resolution
        // after the on-screen frame (the next frame's target sync restores
        // the layout dimensions).
        if let Some(opts) = self.screenshot_request.take() {
            self.render_screenshot(&opts);
        }
        if let Some((pane, azimuth, opts)) = self.turntable_request.take() {
            self.render_turntable_frame(pane, azimuth, &opts);
        }

        to_js(&EventBatch {
            revision: self.engine.revision(),
            events,
        })
    }

    /// Resizes the surface and render targets. `dpr` is the LIVE device pixel
    /// ratio: it is not constant for the session (browser zoom and a move to a
    /// different-density monitor both change it), and every pointer coordinate,
    /// pane rect, and marker projection is scaled by it, so the shell re-reads
    /// it on each resize and pushes it through here.
    pub fn resize(&mut self, width: u32, height: u32, dpr: f32) {
        if width == 0 || height == 0 {
            return;
        }
        if dpr > 0.0 {
            self.dpr = dpr;
            // Label px metrics scale by dpr; keep them honest across
            // browser-zoom and monitor-density changes.
            self.renderer.write_label_dpr(&self.queue, dpr);
        }
        self.config.width = width;
        self.config.height = height;
        self.surface.configure(&self.device, &self.config);
        self.sync_render_target_dims();
        let aspect = self.renderer.target_width as f32 / self.renderer.target_height.max(1) as f32;
        for cam in self.view.cameras.iter_mut().flatten() {
            cam.resize(aspect);
        }
    }

    // ---- pointer routing (CSS px in; pane-aware) ----

    /// Selects the active viewport tool ("select" | "move" | "rotate" | "scale").
    /// The only JS surface the gizmo needs: the drag itself never crosses the
    /// boundary.
    pub fn set_tool(&mut self, tool: &str) -> Result<JsValue, JsError> {
        let next = ToolMode::parse(tool);
        if next == self.gizmo.tool {
            return Ok(JsValue::NULL);
        }
        // Switching tools mid-drag abandons the drag. Rolling it back rather
        // than dropping it is what keeps the preview lane from stranding a value
        // the document never agreed to.
        let rollback = match self.take_gizmo_drag() {
            Some((drag, addr)) => self.rollback_gizmo_drag(&drag, addr)?,
            None => JsValue::NULL,
        };
        self.gizmo.tool = next;
        self.gizmo.hovered = None;
        self.gizmo_readout = None;
        Ok(rollback)
    }

    /// The gizmo's drag ergonomics, pushed from the TS prefs store.
    ///
    /// Pushed rather than polled because the drag loop never crosses back into
    /// JS: it would have to ask once per pointer move, which is exactly the
    /// traffic this design exists to avoid.
    pub fn set_gizmo_settings(
        &mut self,
        orientation: &str,
        snap_translate: f32,
        snap_rotate: f32,
        snap_scale: f32,
    ) {
        self.gizmo.settings = gizmo::GizmoSettings {
            orientation: gizmo::Orientation::parse(orientation),
            snap_translate: snap_translate.max(0.0),
            snap_rotate: snap_rotate.max(0.0),
            snap_scale: snap_scale.max(0.0),
        };
    }

    /// Enters (or leaves) player mode.
    ///
    /// Locks the layout to a single pane and clears any lingering editing
    /// affordance. The clock is NOT started here: whether a published scene
    /// autoplays is the document's `autoplay` setting, read by the player
    /// shell, so the same flag means the same thing whether the scene was
    /// exported or opened in the editor.
    pub fn set_player_mode(&mut self, on: bool) {
        self.player_mode = on;
        if on {
            self.view.display.layout = ViewLayout::Single;
            self.view.active_pane = 0;
            self.selected_object = None;
            self.gizmo_readout = None;
            self.renderer.set_manipulator(None);
            self.host_events.push(HostEvent::ViewChanged);
        }
    }

    /// The clock's current frame, polled by the player's transport readout.
    ///
    /// Polled rather than pushed for the same reason the gizmo readout is:
    /// under a playing clock a pushed value would cross the wasm boundary
    /// once per frame to update a number nobody is reading that closely.
    #[must_use]
    pub fn clock_frame(&self) -> f64 {
        self.engine.clock().frame as f64
    }

    /// Whether the clock is running right now.
    ///
    /// Polled beside [`SolarxyApp::clock_frame`] rather than tracked by the
    /// caller: a `once` range CLEARS `playing` when it reaches the end, so a
    /// shell holding its own boolean shows "Pause" over a clock that stopped
    /// by itself.
    #[must_use]
    pub fn clock_playing(&self) -> bool {
        self.engine.clock().playing
    }

    /// Whether a published scene should start playing, from the document's
    /// own runtime settings. The player shell reads this after load rather
    /// than the editor acting on it: autoplay in an authoring tool is a
    /// surprise, and in a viewer it is the point.
    #[must_use]
    pub fn autoplay(&self) -> bool {
        self.engine.clock().autoplay
    }

    /// The display defaults, pushed from the TS prefs store (the
    /// gizmo-settings pattern). The turntable rpm and the point size apply
    /// immediately: both are live session state that never serializes into
    /// `.slxy`. Wireframe weight and background are stored as the pane seed
    /// and, per `apply_*` flag, written into every pane: the boot push sets
    /// both flags; a mid-session preference save sets only the flags for
    /// fields that actually changed, so per-pane Display-menu overrides
    /// survive unrelated preference edits.
    ///
    /// The boundary mirrors the TypeScript preference bundle field for
    /// field, which is why the argument list is long and bool-heavy: a
    /// struct here would drag serde through the wasm boundary for a plain
    /// setter.
    #[allow(clippy::too_many_arguments, clippy::fn_params_excessive_bools)]
    pub fn set_display_defaults(
        &mut self,
        wireframe_weight: &str,
        background: &str,
        turntable_rpm: f32,
        point_size: f32,
        ssao_enabled: bool,
        bloom_enabled: bool,
        bloom_strength: f32,
        bloom_threshold: f32,
        ssao_strength: f32,
        preview_denoise: bool,
        apply_wireframe: bool,
        apply_background: bool,
    ) {
        self.display_defaults = DisplayDefaults {
            line_weight: display_defaults::parse_line_weight(wireframe_weight),
            background: display_defaults::parse_background(background),
        };
        // Renderer-global post effects, applied on every push: the write is
        // idempotent and the next frame picks it up, so a preference toggle
        // needs no reload and no host event.
        self.renderer.post.ssao_enabled = ssao_enabled;
        self.renderer.post.bloom_enabled = bloom_enabled;
        // Clamped by the setter, so a hand-edited stored preference cannot
        // push the composite somewhere the sliders cannot reach.
        self.renderer
            .post
            .set_strengths(solarxy_core::view_config::PostStrengths {
                bloom_strength,
                bloom_threshold,
                ssao_strength,
            });
        // The preview's filter. Held here rather than baked into
        // `preview_trace_settings`, which asserts it on every encode.
        self.preview_denoise = preview_denoise;
        self.view.display.turntable_rpm = if turntable_rpm.is_finite() {
            turntable_rpm.clamp(1.0, 60.0)
        } else {
            6.0
        };
        self.view.display.point_size = if point_size.is_finite() {
            point_size.clamp(
                solarxy_core::view_config::MIN_POINT_SIZE,
                solarxy_core::view_config::MAX_POINT_SIZE,
            )
        } else {
            solarxy_core::view_config::DEFAULT_POINT_SIZE
        };
        let mut changed = false;
        for pds in &mut self.view.pane_settings {
            if apply_wireframe && pds.line_weight != self.display_defaults.line_weight {
                pds.line_weight = self.display_defaults.line_weight;
                changed = true;
            }
            if apply_background && pds.background_mode != self.display_defaults.background {
                pds.background_mode = self.display_defaults.background;
                changed = true;
            }
        }
        if changed {
            self.host_events.push(HostEvent::ViewChanged);
        }
    }

    /// The live drag readout ("X +1.250 m"), or `null` when nothing is dragging.
    ///
    /// POLLED once per frame, not pushed: `pointer_move` stays void so the hot
    /// path keeps costing zero boundary crossings, and the frame loop is already
    /// crossing anyway for the cook.
    #[must_use]
    pub fn gizmo_readout(&self) -> Option<String> {
        self.gizmo_readout.clone()
    }

    /// Pointer button down. `button`: 0 left, 1 middle, 2 right.
    ///
    /// Returns an `EventBatch` when the press STARTED a gizmo drag that mutated
    /// the document (the append path mints a transform node), else `null`.
    pub fn pointer_down(&mut self, x: f32, y: f32, button: u32) -> Result<JsValue, JsError> {
        let p = (x * self.dpr, y * self.dpr);
        if self.pointer_buttons_down == 0 {
            self.set_hovered_pane(panes::hit_test_pane(&self.compute_panes(), p));
        }
        self.pointer_buttons_down |= 1 << button;

        // The gizmo gets first refusal on a LEFT press, and only on a left press:
        // middle and right always reach the camera, so orbit and pan can never be
        // stolen by a tool. In Select mode this whole branch is skipped and the
        // behaviour is bit-for-bit what it was.
        if button == 0
            && self.gizmo.tool.is_transform_tool()
            && let Some(batch) = self.begin_gizmo_drag(p)?
        {
            return Ok(batch);
        }

        let active = self.view.active_pane;
        if let Some(cam) = self.view.cameras[active].as_mut() {
            cam.handle_mouse_move(p.0, p.1);
            if let Some(btn) = map_button(button) {
                cam.handle_mouse_button(btn, true);
            }
        }
        // On a locked look-through pane, this drag reframes the bound camera, so
        // suppress the node-to-pane follow for the duration of the gesture.
        if self.is_locked_look_through(active) {
            self.camera_editing[active] = true;
        }
        Ok(JsValue::NULL)
    }

    /// Pointer move; updates the hovered (active) pane while no drag is in
    /// flight, and feeds the active pane's camera controller.
    ///
    /// Deliberately returns nothing: this is the hot path, and a live gizmo drag
    /// streams straight into the engine's preview lane without crossing into JS
    /// at all.
    pub fn pointer_move(&mut self, x: f32, y: f32, mods: u8) {
        let p = (x * self.dpr, y * self.dpr);
        let last = std::mem::replace(&mut self.last_pointer, p);
        if self.pointer_buttons_down == 0 {
            self.set_hovered_pane(panes::hit_test_pane(&self.compute_panes(), p));
        }

        // A live drag owns the pointer entirely.
        if self.gizmo.drag.is_some() {
            self.update_gizmo_drag(p, mods);
            return;
        }
        // Otherwise, with a tool armed, keep the hover highlight fresh.
        if self.gizmo.tool.is_transform_tool() && self.pointer_buttons_down == 0 {
            self.update_gizmo_hover(p);
        }

        let active = self.view.active_pane;
        if self.view.pane_settings[active].pane_mode == PaneMode::UvMap {
            // Drag pans the UV view (screen px scaled by the visible UV
            // span; the camera half-height is 0.6 / zoom).
            if self.pointer_buttons_down != 0 {
                let rects = self.compute_panes();
                let height = rects.get(active).map_or(1.0, |r| r.height.max(1.0));
                let pds = &mut self.view.pane_settings[active];
                let uv_per_px = (1.2 / pds.uv_zoom) / height;
                pds.uv_offset[0] -= (p.0 - last.0) * uv_per_px;
                pds.uv_offset[1] -= (p.1 - last.1) * uv_per_px;
                self.host_events.push(HostEvent::ViewChanged);
            }
            return;
        }
        if let Some(cam) = self.view.cameras[active].as_mut() {
            cam.handle_mouse_move(p.0, p.1);
        }
    }

    /// Updates the pointer-hovered active pane, mirroring the change to
    /// the frontend as a host event (the keyboard context reads the
    /// mirror, so it must track pointer routing).
    fn set_hovered_pane(&mut self, pane: usize) {
        if pane != self.view.active_pane {
            self.view.active_pane = pane;
            self.host_events.push(HostEvent::ActivePane { pane });
        }
    }

    /// Pointer button up. Returns the commit `EventBatch` when it ended a gizmo
    /// drag, else `null`.
    pub fn pointer_up(&mut self, button: u32) -> Result<JsValue, JsError> {
        self.pointer_buttons_down &= !(1 << button);

        if button == 0 && self.gizmo.drag.is_some() {
            return self.commit_gizmo_drag();
        }

        let active = self.view.active_pane;
        if let Some(cam) = self.view.cameras[active].as_mut()
            && let Some(btn) = map_button(button)
        {
            cam.handle_mouse_button(btn, false);
        }
        // A locked look-through reframe ends when the last button lifts: commit
        // the new camera pose to the node (one undo step) and let the follow
        // resume. The batch flows back so the parameter panel reflects the pose.
        if self.pointer_buttons_down == 0 && self.camera_editing[active] {
            self.camera_editing[active] = false;
            if let Some(batch) = self.commit_pane_camera_to_node(active) {
                return to_js(&batch);
            }
        }
        Ok(JsValue::NULL)
    }

    /// Escape during a drag: the document returns to where the drag started and
    /// the object snaps back. Returns the rollback `EventBatch`, or `null` when
    /// no drag was in flight.
    pub fn cancel_gizmo_drag(&mut self) -> Result<JsValue, JsError> {
        let Some((drag, addr)) = self.take_gizmo_drag() else {
            return Ok(JsValue::NULL);
        };
        self.rollback_gizmo_drag(&drag, addr)
    }

    /// Wheel zoom on the active pane; positive zooms in.
    pub fn wheel(&mut self, delta: f32) {
        let active = self.view.active_pane;
        if self.view.pane_settings[active].pane_mode == PaneMode::UvMap {
            let pds = &mut self.view.pane_settings[active];
            pds.uv_zoom = (pds.uv_zoom * (1.0 + delta * 0.1)).clamp(0.1, 50.0);
            self.host_events.push(HostEvent::ViewChanged);
            return;
        }
        if let Some(cam) = self.view.cameras[active].as_mut() {
            cam.handle_scroll(delta);
        }
        // A dolly on a locked look-through pane reframes the bound camera. Wheel
        // has no return channel; committing bumps the revision, and the frame
        // loop's next batch carries it so the mirror self-heals (resnapshot on
        // the gap), keeping the node params in step with the pose.
        if self.is_locked_look_through(active) {
            let _ = self.commit_pane_camera_to_node(active);
        }
    }

    /// Picks the node under a canvas CSS pixel, pane-aware: the ray is
    /// built from the pane under the cursor with that pane's camera.
    /// Returns the node id as a number, or `undefined` on a miss.
    ///
    /// A light's marker is tested before the geometry, and only where the pane
    /// actually draws markers, so a pane with them turned off picks exactly
    /// what it did before.
    pub fn pick(&self, x: f32, y: f32) -> Option<f64> {
        if self.player_mode {
            return None;
        }
        let p = (x * self.dpr, y * self.dpr);
        let rects = self.compute_panes();
        let pane_idx = panes::hit_test_pane(&rects, p);
        let pane = rects.get(pane_idx)?;
        let mut cam = self.view.cameras[pane_idx].as_ref()?.camera;
        cam.aspect = pane.width / pane.height.max(1.0);
        let view_proj = cam.build_view_projection_matrix();
        let ray = screen_to_world_ray(
            (p.0 - pane.x, p.1 - pane.y),
            (pane.width, pane.height),
            view_proj,
        );
        let origin = [ray.origin.x, ray.origin.y, ray.origin.z];
        let dir = [ray.direction.x, ray.direction.y, ray.direction.z];
        let markers = self.view.pane_settings[pane_idx]
            .show_light_markers
            .then(|| solarxy_graph::engine::MarkerPick {
                view_proj: view_proj.into(),
                // Physical pixels on both, matching the ray above. The radius
                // is a CSS size, so it scales with the device ratio or a
                // marker would be half as clickable on a retina display as it
                // looks -- the same trap the gizmo hit.
                viewport_px: [pane.width, pane.height],
                cursor_px: [p.0 - pane.x, p.1 - pane.y],
                radius_px: manipulator::MARKER_PX * self.dpr,
            });
        self.engine.pick(origin, dir, markers).map(|n| n.0 as f64)
    }

    /// [`SolarxyApp::pick`] with the full hit detail (mesh, face,
    /// barycentric, world point, pane): the anchor source for creating and
    /// re-placing review annotations. `undefined` on a miss.
    pub fn pick_detailed(&self, x: f32, y: f32) -> Result<JsValue, JsError> {
        let p = (x * self.dpr, y * self.dpr);
        let rects = self.compute_panes();
        let pane_idx = panes::hit_test_pane(&rects, p);
        let detail = rects.get(pane_idx).and_then(|pane| {
            let mut cam = self.view.cameras[pane_idx].as_ref()?.camera;
            cam.aspect = pane.width / pane.height.max(1.0);
            let ray = screen_to_world_ray(
                (p.0 - pane.x, p.1 - pane.y),
                (pane.width, pane.height),
                cam.build_view_projection_matrix(),
            );
            let origin = [ray.origin.x, ray.origin.y, ray.origin.z];
            let dir = [ray.direction.x, ray.direction.y, ray.direction.z];
            self.engine
                .pick_detailed(origin, dir)
                .map(|d| PickDetailDto {
                    node: d.node.0 as f64,
                    mesh: d.mesh,
                    face: d.face,
                    barycentric: d.barycentric,
                    world_pos: d.world_pos,
                    distance: d.distance,
                    pane: pane_idx,
                })
        });
        to_js(&detail)
    }

    /// The annotation set with runtime staleness (the review store's
    /// structure channel): re-read by the frontend on every `reviewChanged`
    /// event. Positions are the separate per-frame channel
    /// ([`SolarxyApp::review_markers`]).
    pub fn review_annotations(&self) -> Result<JsValue, JsError> {
        let annotations: Vec<solarxy_graph::engine::AnnotationSnapshot> = self
            .engine
            .document()
            .review()
            .iter()
            .map(|a| solarxy_graph::engine::AnnotationSnapshot {
                needs_reanchor: self.engine.annotation_stale(a.id),
                annotation: a.clone(),
            })
            .collect();
        to_js(&annotations)
    }

    /// The lane inventory of a node's cooked geometry (names, types,
    /// counts, both domains), or `null` while nothing is committed. Feeds
    /// the attribute-name pickers and the Attributes pane header; values
    /// page separately through [`SolarxyApp::attribute_table`].
    pub fn attribute_summary(&self, node: f64) -> Result<JsValue, JsError> {
        to_js(&self.engine.attribute_summary(NodeId(node as u64)))
    }

    /// The last completed cook's warnings for one node (a plain string
    /// array; empty when the cook was quiet). Pull-read by the node info
    /// card when it opens or the node's cook status changes.
    pub fn cook_warnings(&self, node: f64) -> Result<JsValue, JsError> {
        to_js(&self.engine.cook_warnings(NodeId(node as u64)))
    }

    /// Bounds, cook accounting, placeholder reason and timestamps for one
    /// node, or `null` when the node is gone.
    ///
    /// Pull-read for the same reason `resolved_param` below is: every field
    /// moves on each cook of a time-dependent node, so as events these
    /// would be one message per node per frame under playback.
    pub fn node_report(&self, ctx: JsValue, node: f64) -> Result<JsValue, JsError> {
        let ctx: GraphContext = serde_wasm_bindgen::from_value(ctx)
            .map_err(|e| JsError::new(&format!("bad ctx: {e}")))?;
        #[allow(clippy::cast_possible_truncation, clippy::cast_sign_loss)]
        let report = self.engine.node_report(ctx, NodeId(node as u64));
        to_js(&report)
    }

    /// One param's current value as the panel should display it, or the
    /// message explaining why it has none.
    ///
    /// Pull-read per row rather than pushed: under playback a per-cook
    /// resolved value would be one event per expression per frame across
    /// this boundary.
    pub fn resolved_param(&self, ctx: JsValue, node: f64, key: String) -> Result<JsValue, JsError> {
        let ctx: GraphContext = serde_wasm_bindgen::from_value(ctx)
            .map_err(|e| JsError::new(&format!("bad ctx: {e}")))?;
        match self.engine.resolved_param(ctx, NodeId(node as u64), &key) {
            Ok(value) => to_js(&ResolvedParamDto {
                ok: true,
                value: Some(value),
                error: None,
            }),
            Err(error) => to_js(&ResolvedParamDto {
                ok: false,
                value: None,
                error: Some(error),
            }),
        }
    }

    /// One window of a node's cooked attribute values
    /// (`domain` is `"point"` or `"primitive"`). Only the requested page
    /// crosses the boundary; the geometry stays in wasm.
    pub fn attribute_table(
        &self,
        node: f64,
        domain: String,
        offset: u32,
        limit: u32,
    ) -> Result<JsValue, JsError> {
        let domain = match domain.as_str() {
            "primitive" => solarxy_kernel::AttributeDomain::Primitive,
            _ => solarxy_kernel::AttributeDomain::Point,
        };
        to_js(
            &self
                .engine
                .attribute_page(NodeId(node as u64), domain, offset, limit),
        )
    }

    /// Replaces the host-owned attribute-visualization state (the right
    /// strip's toggles and picked lane). Session-only: never saved, never
    /// in undo. Returns the full view state, the mutator convention.
    pub fn set_attr_viz(&mut self, state: JsValue) -> Result<JsValue, JsError> {
        let next: AttrVizState = serde_wasm_bindgen::from_value(state)
            .map_err(|e| JsError::new(&format!("attrViz: {e}")))?;
        if next != self.attr_viz {
            // Size, background and opacity live in the GPU uniform, not in
            // the label set, so they need a style push as well as the
            // rebuild. Decimals go the other way (they change the text), and
            // `attr_dirty` covers those.
            self.attr_viz = next;
            self.attr_dirty = true;
            self.push_label_style();
        }
        to_js(&self.view_state_dto())
    }

    /// Marker pin positions in PANE-RELATIVE CSS pixels (the DOM overlay
    /// clips one absolutely-positioned box per pane, so pins offset from
    /// their pane's origin), one entry per visible (marker x 3D pane) pair,
    /// resolved through each pane's camera (the desktop projection: clip ->
    /// NDC -> pane pixel, small NDC slack). Called once per animation frame
    /// by the host loop and applied to the DOM imperatively; markers absent
    /// from the list are hidden. UV panes carry no markers.
    pub fn review_markers(&self) -> Result<JsValue, JsError> {
        let mut out: Vec<MarkerScreenDto> = Vec::new();
        if self.player_mode {
            // Review notes are an authoring conversation, not part of the
            // published scene.
            return to_js(&out);
        }
        let markers = self.engine.review_markers_world();
        if markers.is_empty() {
            return to_js(&out);
        }
        let rects = self.compute_panes();
        for (i, pane) in rects.iter().enumerate() {
            if self.view.pane_settings[i].pane_mode == PaneMode::UvMap || pane.height <= 0.0 {
                continue;
            }
            let Some(cam_state) = self.view.cameras[i].as_ref() else {
                continue;
            };
            let mut cam = cam_state.camera;
            cam.aspect = pane.width / pane.height.max(1.0);
            let vp = cam.build_view_projection_matrix();
            for m in &markers {
                let Some(world) = m.world else { continue };
                let clip = vp * cgmath::Vector4::new(world[0], world[1], world[2], 1.0);
                if clip.w <= 0.0 {
                    continue;
                }
                let ndc = (clip.x / clip.w, clip.y / clip.w, clip.z / clip.w);
                // Same culls as the attribute pins; the z range is what
                // rejects behind-camera markers under orthographic
                // projection (clip.w is a constant 1 there).
                if ndc.0.abs() > NDC_XY_SLACK
                    || ndc.1.abs() > NDC_XY_SLACK
                    || !(NDC_Z_MIN..=NDC_Z_MAX).contains(&ndc.2)
                {
                    continue;
                }
                out.push(MarkerScreenDto {
                    id: m.id.0 as f64,
                    pane: i,
                    x: f32::midpoint(ndc.0, 1.0) * pane.width / self.dpr,
                    y: (1.0 - ndc.1) * 0.5 * pane.height / self.dpr,
                });
            }
        }
        to_js(&out)
    }

    /// Starts a still render: `{ width, height, samples, engine, denoise }`.
    ///
    /// `engine` is `"raster"` or `"pathTraced"`. Rejects while one is already
    /// running, because both would want the shared targets at their own tile
    /// size in the same frame.
    ///
    /// The job then advances one chunk per `frame()`, reports itself through
    /// the `renderProgress` host event, and hands finished tiles over through
    /// `take_still_tile`.
    /// What a `render` node is asking for, for the dialog to show before
    /// anything is rendered.
    ///
    /// A pull-read of the same resolver `startStillRender` runs, so the numbers
    /// on the confirmation screen are the numbers the job will use rather than
    /// a second opinion about the same node.
    #[wasm_bindgen(js_name = renderSettings)]
    pub fn render_settings(&self, ctx: JsValue, node: f64) -> Result<JsValue, JsError> {
        let ctx: GraphContext = serde_wasm_bindgen::from_value(ctx)
            .map_err(|e| JsError::new(&format!("bad ctx: {e}")))?;
        let settings = self
            .engine
            .render_settings(ctx, NodeId(node as u64))
            .map_err(|e| JsError::new(&e))?;
        to_js(&RenderSettingsDto::from(settings))
    }

    #[wasm_bindgen(js_name = startStillRender)]
    #[allow(clippy::too_many_lines)] // linear job-start sequence; splitting obscures it
    pub fn start_still_render(
        &mut self,
        ctx: JsValue,
        node: f64,
        format: &str,
        space: &str,
    ) -> Result<(), JsError> {
        use solarxy_host::still::{StillEngine, StillRenderJob};

        if self.still.is_some() {
            return Err(JsError::new("a still render is already running"));
        }
        // Started before the tracer is snapshotted and the camera is built,
        // because a person pressing Render is already waiting through those and
        // an elapsed that began at the first tile would be a number that
        // disagreed with the clock on their wall.
        self.still_started_ms = web_now();
        let readback = solarxy_host::still::readback_for(format, space);
        // Resolved here rather than accepted from the caller, and re-resolved
        // rather than carried over from the dialog's read: what runs is what
        // the node says at the moment Render is pressed.
        let ctx: GraphContext = serde_wasm_bindgen::from_value(ctx)
            .map_err(|e| JsError::new(&format!("bad ctx: {e}")))?;
        let opts = self
            .engine
            .render_settings(ctx, NodeId(node as u64))
            .map_err(|e| JsError::new(&e))?;
        let engine = match opts.engine {
            solarxy_graph::nodes::RenderEngine::PathTraced => StillEngine::PathTraced,
            solarxy_graph::nodes::RenderEngine::Raster => StillEngine::Raster,
        };
        if engine == StillEngine::PathTraced {
            if self.tracer.is_none() {
                self.tracer = Some(solarxy_renderer::pathtrace::backend::PathBackend::new(
                    &self.device,
                    &self.queue,
                ));
                // A tracer built after the environment was installed has
                // missed it, and the snapshot below cannot carry it: the
                // scene cache drops that op by design.
                self.traced_env_dirty = true;
            }
            // The document as it stands now, on every start rather than only
            // at construction: the per-frame delta feed goes to the raster
            // backend alone, so a tracer kept from a previous still has seen
            // nothing since, and a construction-only snapshot rendered every
            // later still against the first scene. A full snapshot rather
            // than a delta because deltas since boot are long gone, and cheap
            // to re-apply: unchanged geometry stays a hierarchy-cache hit,
            // and the snapshot-aware apply drops what the document no longer
            // holds.
            let delta = self.engine.scene_snapshot();
            if let Some(t) = self.tracer.as_mut() {
                t.apply_snapshot(&self.device, &self.queue, &delta);
            }
            if let Some(message) = self
                .tracer
                .as_ref()
                .and_then(solarxy_renderer::backend::RenderBackend::skipped_primitives_warning)
            {
                self.host_events.push(HostEvent::RenderNotice { message });
            }
            self.install_still_environment();
            // The pane path owes an install from the moment the still takes
            // the shared backend, or a traced pane resuming afterwards keeps
            // the still's sky. Set here rather than where the job finishes so
            // that a cancelled or failed render restores the panes too.
            self.traced_env_dirty = true;
        }
        if let Some(t) = self.tracer.as_mut() {
            let current = t.settings();
            t.set_settings(crate::trace_settings::trace_settings_for(&opts, current));
            t.set_denoise_settings(crate::trace_settings::denoise_settings_for(&opts));
            t.invalidate();
        }
        // After the settings, which reset the lens to the pinhole default.
        // Resolved before the job's camera is built below so a still and the
        // pane it was launched from cannot disagree about the aperture.
        let lens = self.still_lens(opts.camera);
        if let Some(t) = self.tracer.as_mut() {
            t.set_lens(lens);
        }
        let spec = self.still_spec(&opts, engine, readback);
        // Refused here rather than at save, because the buffer this needs is
        // allocated as the render runs and a refusal after minutes of work is
        // no kindness. The eight-bit path is unaffected and keeps its full
        // range: it holds four bytes a pixel on a canvas the browser owns,
        // while a float save holds twelve in this module's own heap and then
        // encodes from them.
        if readback != solarxy_host::still::StillReadback::Display8 {
            let pixels = u64::from(spec.width) * u64::from(spec.height);
            if pixels > MAX_FLOAT_STILL_PIXELS {
                return Err(JsError::new(&format!(
                    "a floating-point still is limited to {} megapixels and this one is {:.1}; \
                     render it smaller, or take it from the command line, which writes the same \
                     image with no such limit",
                    MAX_FLOAT_STILL_PIXELS / 1_000_000,
                    megapixels(pixels)
                )));
            }
        }
        // The same argument, for the same reason, about a different buffer: the
        // auxiliary planes are held whole because the depth display normalizes
        // over the whole picture's range, so they are allocated up front and a
        // size that cannot hold them has to be refused before the work starts.
        let plane_cost = StillPasses::cost(&spec);
        if plane_cost > MAX_PASS_PLANE_BYTES {
            let fits = MAX_PASS_PLANE_BYTES * u64::from(spec.width) * u64::from(spec.height)
                / plane_cost.max(1);
            return Err(JsError::new(&format!(
                "the auxiliary passes for a still this size need {} MB and the browser keeps at \
                 most {}; render about {:.1} megapixels or fewer with these passes, ask for fewer \
                 of them, or take it from the command line, which writes the same passes with no \
                 such limit",
                plane_cost / (1024 * 1024),
                MAX_PASS_PLANE_BYTES / (1024 * 1024),
                megapixels(fits)
            )));
        }
        self.still_passes = StillPasses::new(&spec);
        self.still_pass_request = [opts.aov_albedo, opts.aov_normal, opts.aov_depth];
        // Read from the constant rather than from a live backend, which is what
        // lets a window know what a render can produce without a device.
        self.still_writes_aovs = match engine {
            StillEngine::PathTraced => PathBackend::CAPS.writes_aovs,
            StillEngine::Raster => solarxy_host::RasterBackend::CAPS.writes_aovs,
        };
        self.still_float = solarxy_host::still::FloatImage::new(
            readback,
            spec.width,
            spec.height,
            spec.transparent,
        );
        // The job's own camera. Built from the named `camera` node when there
        // is one, and otherwise from the active pane's current view copied by
        // value: either way the panes are untouched, which is what makes
        // pressing Render Still not move what you are looking at.
        let mut camera = self.view.cameras[self.view.active_pane]
            .as_ref()
            .map_or_else(
                || {
                    solarxy_renderer::camera::camera_from_bounds(
                        &self.scene_bounds(),
                        #[allow(clippy::cast_precision_loss)]
                        {
                            opts.width as f32 / opts.height.max(1) as f32
                        },
                    )
                },
                |c| c.camera,
            );
        if let Some(node) = opts.camera {
            let id = SceneObjectId(node.0);
            if let Some(def) = self
                .raster
                .scene()
                .cameras()
                .and_then(|cams| cams.iter().find(|c| c.id == id).cloned())
            {
                solarxy_host::cameras::apply_camera_def(&mut camera, &def);
            }
        }
        // The image's aspect, not a pane's: the render's width and height fix
        // the composition, which is what the node's help says they do.
        #[allow(clippy::cast_precision_loss)]
        {
            camera.aspect = opts.width as f32 / opts.height.max(1) as f32;
        }
        if engine == StillEngine::PathTraced {
            self.light_traced_still(&camera);
        }
        self.still_camera = Some(solarxy_renderer::camera_state::CameraState::from_camera(
            &self.device,
            &self.renderer.layouts.camera,
            camera,
        ));
        self.prepare_still_look(opts.camera);

        self.still_tiles.clear();
        self.still_previews.clear();
        self.still = Some(StillRenderJob::new(spec));
        Ok(())
    }

    /// Cancels the running still render, dropping the job and everything it
    /// allocated. Safe to call when nothing is running.
    #[wasm_bindgen(js_name = cancelStillRender)]
    pub fn cancel_still_render(&mut self) {
        self.still = None;
        self.still_camera = None;
        self.still_tiles.clear();
        // Any outstanding preview goes with the job that armed it, which frees
        // its buffer; anything already queued is a look at a render nobody
        // asked to keep.
        self.still_previews.clear();
        // Half-filled planes for the same reason the half-filled image goes:
        // nothing should be able to save an unfinished pass, and they are the
        // largest thing this render allocated.
        self.still_passes = None;
        self.still_pass_request = [false; 3];
        // Dropped with the job: a cancelled render has a half-filled image and
        // nothing should be able to save it, quite apart from the tens of
        // megabytes it would otherwise sit on until the next render.
        self.still_float = None;
        // The next frame renders the panes again, and the frame after that
        // resizes the targets back to the layout.
    }

    /// A finished tile as `{ x, y, width, height, pixels }` (RGBA8), or
    /// `undefined` when none is waiting.
    ///
    /// Tiles cross one at a time and are assembled on the JavaScript side,
    /// which is what keeps a sixty-seven megapixel image out of the wasm heap
    /// and gives the modal its live preview for nothing.
    #[wasm_bindgen(js_name = takeStillTile)]
    pub fn take_still_tile(&mut self) -> JsValue {
        let Some(tile) = self.still_tiles.pop_front() else {
            return JsValue::UNDEFINED;
        };
        // A float tile lands in the image being assembled here and reaches the
        // dialog as eight bits, which is the whole arrangement: the canvas
        // cannot show sixteen bytes a pixel, and the floats have no business
        // crossing the boundary except as the encoded file they end up in.
        // The auxiliary planes land in their own stores, whole, because the
        // depth display normalizes over the whole picture and a plane mapped
        // tile by tile would band at every seam.
        if let Some(p) = self.still_passes.as_mut() {
            p.place(&tile);
        }
        let rgba8 = if let Some(f) = self.still_float.as_mut() {
            f.place(tile.rect, &tile.pixels);
            std::borrow::Cow::Owned(solarxy_host::still::float_to_rgba8(&tile.pixels))
        } else {
            std::borrow::Cow::Borrowed(tile.pixels.as_slice())
        };
        let obj = js_sys::Object::new();
        let set = |k: &str, v: &JsValue| {
            let _ = js_sys::Reflect::set(&obj, &JsValue::from_str(k), v);
        };
        set("x", &JsValue::from_f64(f64::from(tile.rect.x)));
        set("y", &JsValue::from_f64(f64::from(tile.rect.y)));
        set("width", &JsValue::from_f64(f64::from(tile.rect.width)));
        set("height", &JsValue::from_f64(f64::from(tile.rect.height)));
        set(
            "pixels",
            &JsValue::from(js_sys::Uint8Array::from(rgba8.as_ref())),
        );
        obj.into()
    }

    /// The picture so far as `{ x, y, width, height, pixels }` (RGBA8), or
    /// `undefined` when none is waiting.
    ///
    /// The same shape a finished tile crosses in, so the modal paints both
    /// through one path and needs no second branch. It is deliberately *not*
    /// placed into the float image being assembled: a preview is an unfinished
    /// look at a tile, and the file must only ever contain tiles that finished.
    #[wasm_bindgen(js_name = takeStillPreview)]
    pub fn take_still_preview(&mut self) -> JsValue {
        let Some(preview) = self.still_previews.pop_front() else {
            return JsValue::UNDEFINED;
        };
        let obj = js_sys::Object::new();
        let set = |k: &str, v: &JsValue| {
            let _ = js_sys::Reflect::set(&obj, &JsValue::from_str(k), v);
        };
        set("x", &JsValue::from_f64(f64::from(preview.rect.x)));
        set("y", &JsValue::from_f64(f64::from(preview.rect.y)));
        set("width", &JsValue::from_f64(f64::from(preview.rect.width)));
        set("height", &JsValue::from_f64(f64::from(preview.rect.height)));
        set(
            "pixels",
            &JsValue::from(js_sys::Uint8Array::from(preview.pixels.as_slice())),
        );
        obj.into()
    }

    /// Which passes the running render produces, and whether its engine could
    /// produce any at all.
    ///
    /// Two separate answers because a selector says two different things with
    /// them. A pass the render did not ask for is offered and disabled, naming
    /// what would produce it; a render whose engine writes none shows the
    /// beauty alone, because there is no checkbox anywhere that would have
    /// helped. The second is a capability rather than an identity, so the
    /// window never asks which backend is running.
    #[wasm_bindgen(js_name = stillPasses)]
    pub fn still_passes(&self) -> Result<JsValue, JsError> {
        #[derive(Serialize)]
        #[serde(rename_all = "camelCase")]
        // Three passes and one capability. They are four answers to four
        // questions, not a flag set with a shape worth extracting.
        #[allow(clippy::struct_excessive_bools)]
        struct PassesDto {
            albedo: bool,
            normal: bool,
            depth: bool,
            engine_writes_aovs: bool,
        }
        to_js(&PassesDto {
            albedo: self.still_pass_request[0],
            normal: self.still_pass_request[1],
            depth: self.still_pass_request[2],
            engine_writes_aovs: self.still_writes_aovs,
        })
    }

    /// One pass as display pixels for the window, RGBA8 over the whole image.
    ///
    /// Mapped here rather than on the other side of the boundary, through the
    /// same functions the terminal's watch window draws with, so the two
    /// surfaces cannot come to look different. Computed on demand rather than
    /// kept: a person looks at one pass at a time, and holding a display copy
    /// of each beside the float planes would double what a render costs to
    /// show something nobody is looking at.
    ///
    /// `undefined` when the render did not produce that pass, which is what a
    /// selector should already have prevented.
    #[wasm_bindgen(js_name = stillPassDisplay)]
    pub fn still_pass_display(&self, pass: &str) -> JsValue {
        let Some(p) = self.still_passes.as_ref() else {
            return JsValue::UNDEFINED;
        };
        let bytes = match pass {
            "albedo" => p
                .aux
                .as_ref()
                .map(|a| solarxy_host::passes::albedo_rgba8(a)),
            "normal" => p
                .aux
                .as_ref()
                .map(|a| solarxy_host::passes::normal_rgba8(a)),
            "depth" => p
                .depth
                .as_ref()
                .map(|d| solarxy_host::passes::depth_rgba8(d)),
            _ => None,
        };
        bytes.map_or(JsValue::UNDEFINED, |b| {
            JsValue::from(js_sys::Uint8Array::from(b.as_slice()))
        })
    }

    /// One pass as the file it is saved as.
    ///
    /// Always a floating-point image, whatever the beauty is: an eight-bit
    /// albedo is a picture of an albedo and an eight-bit normal is useless, so
    /// the command line writes every pass as float and this writes the same
    /// bytes through the same encoders.
    ///
    /// # Errors
    /// The pass not being one this render produced, or the encode failing.
    #[wasm_bindgen(js_name = stillPassFile)]
    pub fn still_pass_file(&self, pass: &str) -> Result<js_sys::Uint8Array, JsError> {
        let Some(p) = self.still_passes.as_ref() else {
            return Err(JsError::new("this render produced no auxiliary passes"));
        };
        let bytes = match pass {
            "albedo" | "normal" => {
                let aux = p
                    .aux
                    .as_ref()
                    .ok_or_else(|| JsError::new("this render produced no auxiliary plane"))?;
                let floats = solarxy_host::passes::floats_of(aux);
                let plane = if pass == "albedo" {
                    solarxy_host::passes::albedo_from_auxiliary(&floats)
                } else {
                    solarxy_host::passes::normal_from_auxiliary(&floats)
                };
                solarxy_formats::export::encode_exr_rgb_bytes(
                    &solarxy_core::geometry::RawImageHdr::new(plane, p.width, p.height),
                )
                .map_err(|e| JsError::new(&format!("encoding the {pass} pass failed: {e}")))?
            }
            "depth" => {
                let depth = p
                    .depth
                    .as_ref()
                    .ok_or_else(|| JsError::new("this render produced no depth pass"))?;
                let floats = solarxy_host::passes::floats_of(depth);
                solarxy_formats::export::encode_exr_depth_bytes(&floats, p.width, p.height)
                    .map_err(|e| JsError::new(&format!("encoding the depth pass failed: {e}")))?
            }
            other => return Err(JsError::new(&format!("{other} is not a pass"))),
        };
        Ok(js_sys::Uint8Array::from(bytes.as_slice()))
    }

    /// Encodes the finished floating-point still and hands back the file.
    ///
    /// The bytes of a real EXR, written by the same encoder the headless
    /// command uses, so there is one implementation of the format and a file
    /// saved here opens identically to one rendered on the command line. The
    /// download itself is the frontend's: this module has no business knowing
    /// about anchors and object URLs.
    ///
    /// Errors rather than returning nothing when there is no float image,
    /// because reaching this without one means the dialog offered a save it
    /// could not honour.
    #[wasm_bindgen(js_name = saveStillExr)]
    pub fn save_still_exr(&self) -> Result<js_sys::Uint8Array, JsError> {
        let Some(f) = self.still_float.as_ref() else {
            return Err(JsError::new(
                "this still was not rendered as a floating-point image",
            ));
        };
        // A matte still goes through the four-channel writer, which
        // premultiplies on the way out; an opaque one keeps its three
        // channels and its reasoning.
        let bytes = if f.has_matte() {
            solarxy_formats::export::encode_exr_rgba_bytes(f.rgba(), f.width(), f.height())
        } else {
            let img =
                solarxy_core::geometry::RawImageHdr::new(f.rgb().to_vec(), f.width(), f.height());
            solarxy_formats::export::encode_exr_rgb_bytes(&img)
        }
        .map_err(|e| JsError::new(&format!("the image could not be encoded: {e}")))?;
        Ok(js_sys::Uint8Array::from(bytes.as_slice()))
    }

    /// PNG-encodes an assembled RGBA8 still through the same encoder the
    /// command line writes with.
    ///
    /// Exists for the transparent render: a canvas stores its backing
    /// premultiplied, so `toBlob` on one round-trips straight alpha through a
    /// multiply and a divide and corrupts every partially covered pixel's
    /// colour. The window keeps a pristine copy of the finished tiles beside
    /// the canvas and hands it here, so the browser's file and the command
    /// line's carry the same values for the same scene. Stateless on purpose:
    /// the bytes cross once, at save time, and nothing is retained.
    #[wasm_bindgen(js_name = encodeStillPng)]
    pub fn encode_still_png(
        &self,
        pixels: &[u8],
        width: u32,
        height: u32,
    ) -> Result<js_sys::Uint8Array, JsError> {
        if pixels.len() != (width as usize) * (height as usize) * 4 {
            return Err(JsError::new("the buffer does not match the stated size"));
        }
        let bytes = solarxy_formats::export::encode_png_bytes(&solarxy_core::RawImageData::new(
            pixels.to_vec(),
            width,
            height,
        ))
        .map_err(|e| JsError::new(&format!("the image could not be encoded: {e}")))?;
        Ok(js_sys::Uint8Array::from(bytes.as_slice()))
    }

    /// Whether the running or finished still can be saved as a float image,
    /// and in which space, so the dialog labels its own buttons from the
    /// render rather than from what it asked for.
    #[wasm_bindgen(js_name = stillFloatSpace)]
    #[must_use]
    pub fn still_float_space(&self) -> Option<String> {
        self.still_float.as_ref().map(|f| {
            if f.is_scene_linear() {
                "sceneLinear".to_string()
            } else {
                "display".to_string()
            }
        })
    }

    /// Advances the running job by one chunk and reports where it got to.
    fn pump_still_render(&mut self) {
        use solarxy_host::still::{StillEngine, StillStep};

        let Some(mut job) = self.still.take() else {
            return;
        };
        let Some(tile) = job.current() else {
            self.still = None;
            return;
        };
        // The shell's half of the arrangement: the job renders into the shared
        // targets and does not resize them, because the two shells resize with
        // different policy around the same body.
        self.set_target_dims(tile.render.width, tile.render.height);

        // A delivered still is a photograph of the scene rather than a
        // screenshot of the pane it was launched from, so it is drawn with the
        // still view rather than with whatever the pane happens to be showing.
        // Before this, a rasterized still carried the pane's grid and gizmo
        // into the saved image, and a terminal render had no pane to inherit
        // from and so could not have matched it anyway.
        //
        // The background is the exception and rides along from the pane: a
        // scene shot against an authored sky should keep it.
        let pds = solarxy_core::view_config::PaneDisplaySettings::for_still(
            self.view.pane_settings[self.view.active_pane].background_mode,
        );
        let display = self.view.display;
        let background = self.resolve_background(&pds);
        let bounds = self.scene_bounds();
        let look = self.still_look;
        let scene_present = self.raster.scene().draw_objects().next().is_some();
        let engine = job.spec().engine;
        let format = self.render_format;

        let step = {
            let Some(camera) = self.still_camera.as_mut() else {
                self.still = None;
                return;
            };
            let mut ctx = solarxy_host::StillCtx {
                device: &self.device,
                queue: &self.queue,
                renderer: &mut self.renderer,
                camera,
                env: &self.env,
                pds: &pds,
                display: &display,
                background,
                bounds: Some(&bounds),
                look,
                format,
                scene_present,
                // The page's own timer, which is the only clock this shell has
                // and the same one the cook budget is measured against.
                now_ms: web_now() as u64,
            };
            match engine {
                StillEngine::Raster => job.advance(&mut ctx, &mut self.raster),
                StillEngine::PathTraced => match self.tracer.as_mut() {
                    Some(t) => job.advance(&mut ctx, t),
                    None => StillStep::Failed,
                },
            }
        };

        if step == StillStep::Tile {
            while let Some(t) = job.take_tile() {
                self.still_tiles.push_back(t);
            }
        }
        // Drained whichever step came back: the job clears anything it holds
        // when the tile it described finishes, so what is here is always newer
        // than the last thing painted and never survives the tile it belongs to.
        if let Some(p) = job.take_preview() {
            self.still_previews.push_back(p);
        }
        let progress = job.progress();
        let done =
            matches!(step, StillStep::Done | StillStep::Failed) || progress.tile >= progress.tiles;
        let elapsed_ms = (web_now() - self.still_started_ms).max(0.0);
        // The same estimator the terminal reads, over the same area-weighted
        // counts, so the two surfaces cannot answer this differently. Nothing
        // is reported once the sampling is over: the job is still assembling,
        // and a zero would say it was finished.
        let remaining_ms = if done {
            None
        } else {
            solarxy_host::still::estimate_remaining_ms(
                progress.drawn,
                progress.total,
                elapsed_ms as u64,
            )
            .map(|ms| ms as f64)
        };
        self.host_events.push(HostEvent::RenderProgress {
            tile: progress.tile,
            tiles: progress.tiles,
            sample: progress.sample,
            samples: progress.samples,
            done,
            elapsed_ms,
            remaining_ms,
        });
        if done {
            self.still = None;
            self.still_camera = None;
        } else {
            self.still = Some(job);
        }
    }

    /// Requests a screenshot of the active pane, rendered offscreen at the
    /// given resolution at the end of the current frame. One capture at a
    /// time; poll with [`SolarxyApp::poll_screenshot`].
    pub fn request_screenshot(&mut self, opts: JsValue) -> Result<(), JsError> {
        // The capture resizes the shared MSAA HDR chain to capture
        // resolution for one frame, so VRAM cost is ~4x the pixel count.
        // Empirically (Chrome/Apple GPU) captures in the 7-8M px range
        // lose the device NONDETERMINISTICALLY, and web wgpu has no
        // device-loss recovery yet, so the budget stays far below the
        // failure zone: a modest supersample of typical panes. True
        // hi-res needs tiled off-axis capture (logged follow-up); the
        // result reports the effective size either way.
        const MAX_CAPTURE_PIXELS: u64 = 4_000_000;
        if self.screenshot_request.is_some() || self.pending_screenshot.is_some() {
            return Err(JsError::new("a screenshot is already in flight"));
        }
        let mut opts: ScreenshotOptsDto = serde_wasm_bindgen::from_value(opts)
            .map_err(|e| JsError::new(&format!("bad opts: {e}")))?;
        let max = self.device.limits().max_texture_dimension_2d;
        opts.width = opts.width.clamp(16, max);
        opts.height = opts.height.clamp(16, max);
        let pixels = u64::from(opts.width) * u64::from(opts.height);
        if pixels > MAX_CAPTURE_PIXELS {
            #[allow(clippy::cast_precision_loss)]
            let scale = ((MAX_CAPTURE_PIXELS as f64) / (pixels as f64)).sqrt();
            #[allow(clippy::cast_possible_truncation, clippy::cast_sign_loss)]
            {
                opts.width = ((f64::from(opts.width) * scale) as u32).max(16);
                opts.height = ((f64::from(opts.height) * scale) as u32).max(16);
            }
        }
        self.screenshot_request = Some(opts);
        Ok(())
    }

    /// Requests one turntable-export frame: pane `pane` rendered offscreen from
    /// its render-through camera rotated by `azimuth_deg`, at the given opts.
    /// Uses the same single capture slot as the screenshot; the frontend drives
    /// one azimuth at a time (poll with `poll_screenshot`). Deterministic: it
    /// renders a rotated clone, never disturbing the live view.
    pub fn request_turntable_frame(
        &mut self,
        pane: usize,
        azimuth_deg: f32,
        opts: JsValue,
    ) -> Result<(), JsError> {
        const MAX_CAPTURE_PIXELS: u64 = 4_000_000;
        if self.screenshot_request.is_some()
            || self.turntable_request.is_some()
            || self.pending_screenshot.is_some()
        {
            return Err(JsError::new("a capture is already in flight"));
        }
        let mut opts: ScreenshotOptsDto = serde_wasm_bindgen::from_value(opts)
            .map_err(|e| JsError::new(&format!("bad opts: {e}")))?;
        let max = self.device.limits().max_texture_dimension_2d;
        opts.width = opts.width.clamp(16, max);
        opts.height = opts.height.clamp(16, max);
        let pixels = u64::from(opts.width) * u64::from(opts.height);
        if pixels > MAX_CAPTURE_PIXELS {
            #[allow(clippy::cast_precision_loss)]
            let scale = ((MAX_CAPTURE_PIXELS as f64) / (pixels as f64)).sqrt();
            #[allow(clippy::cast_possible_truncation, clippy::cast_sign_loss)]
            {
                opts.width = ((f64::from(opts.width) * scale) as u32).max(16);
                opts.height = ((f64::from(opts.height) * scale) as u32).max(16);
            }
        }
        self.turntable_request = Some((pane.min(3), azimuth_deg, opts));
        Ok(())
    }

    /// Polls the in-flight capture. `undefined` while pending (or when no
    /// capture is in flight); on completion returns
    /// `{ width, height, pixels: Uint8Array }` (tightly-packed RGBA8).
    pub fn poll_screenshot(&mut self) -> Result<JsValue, JsError> {
        use solarxy_renderer::capture::CapturePoll;
        let Some(pending) = &self.pending_screenshot else {
            return Ok(JsValue::UNDEFINED);
        };
        match pending.poll(&self.device, self.render_format) {
            CapturePoll::Pending => Ok(JsValue::UNDEFINED),
            CapturePoll::Failed => {
                self.pending_screenshot = None;
                Err(JsError::new("screenshot readback failed"))
            }
            CapturePoll::Ready(pixels) => {
                let (width, height) = (pending.width, pending.height);
                self.pending_screenshot = None;
                let obj = js_sys::Object::new();
                let set = |k: &str, v: &JsValue| {
                    let _ = js_sys::Reflect::set(&obj, &JsValue::from_str(k), v);
                };
                set("width", &JsValue::from_f64(f64::from(width)));
                set("height", &JsValue::from_f64(f64::from(height)));
                set(
                    "pixels",
                    &JsValue::from(js_sys::Uint8Array::from(pixels.as_slice())),
                );
                Ok(obj.into())
            }
        }
    }

    /// The displayed image of a texture network, for the
    /// texture viewer pane: `{ width, height, pixels }` (RGBA8) or
    /// `undefined` when the network publishes nothing. The pixel copy is
    /// display-only and pull-based, so cooked images still never ride the
    /// event stream; the viewer fetches on cook changes.
    pub fn texture_preview(&self, owner: f64) -> JsValue {
        let Some(img) = self
            .engine
            .display_image(solarxy_graph::document::NodeId(owner as u64))
        else {
            return JsValue::UNDEFINED;
        };
        let obj = js_sys::Object::new();
        let set = |k: &str, v: &JsValue| {
            let _ = js_sys::Reflect::set(&obj, &JsValue::from_str(k), v);
        };
        set("width", &JsValue::from_f64(f64::from(img.width)));
        set("height", &JsValue::from_f64(f64::from(img.height)));
        set(
            "pixels",
            &JsValue::from(js_sys::Uint8ClampedArray::from(img.pixels.as_slice())),
        );
        obj.into()
    }

    /// Executes an export node's Action param: the engine
    /// encodes the committed output, and the returned
    /// `{ filename, mime, bytes }` goes to the frontend's save path (the
    /// File System Access flow `.slxy` already uses).
    pub fn invoke_action(&self, ctx: JsValue, node: f64, key: String) -> Result<JsValue, JsError> {
        let ctx: GraphContext = serde_wasm_bindgen::from_value(ctx)
            .map_err(|e| JsError::new(&format!("bad ctx: {e}")))?;
        let result = self
            .engine
            .invoke_action(ctx, NodeId(node as u64), &key)
            .map_err(|e| JsError::new(&e.to_string()))?;
        let obj = js_sys::Object::new();
        let set = |k: &str, v: &JsValue| {
            let _ = js_sys::Reflect::set(&obj, &JsValue::from_str(k), v);
        };
        set("filename", &JsValue::from_str(&result.filename));
        set("mime", &JsValue::from_str(&result.mime));
        set(
            "bytes",
            &JsValue::from(js_sys::Uint8Array::from(result.bytes.as_slice())),
        );
        Ok(obj.into())
    }

    /// Renders the active pane offscreen at capture resolution and encodes
    /// the readback copy. The pane's display settings are copied with the
    /// requested overlay toggles applied; the composite always clears (a
    /// fresh texture has no prior pane to load).
    fn render_screenshot(&mut self, opts: &ScreenshotOptsDto) {
        let target = CaptureTarget::new(&self.device, self.render_format, opts.width, opts.height);
        let (w, h, full) = (target.width, target.height, target.rect);
        self.set_target_dims(w, h);
        let pane_idx = self.view.active_pane;
        let mut pds = self.view.pane_settings[pane_idx];
        if !opts.overlays.grid {
            pds.show_grid = false;
        }
        if !opts.overlays.axes {
            pds.show_axis_gizmo = false;
            pds.show_local_axes = false;
        }
        if !opts.overlays.validation {
            pds.show_validation = false;
        }
        // Markers stay out of a saved image. They are an aiming aid rather
        // than something the picture is of, and the person saving a frame is
        // framing a shot.
        pds.show_light_markers = false;
        // So does the manipulator, which is transient tool state rather than
        // anything the viewport was configured to show, and which would come
        // out at the previous pane's scale besides. The camera and light
        // helpers deliberately stay: those are switched on per node and behave
        // like the grid toggle, so a screenshot of the viewport keeps them.
        self.renderer.set_manipulator(None);

        let mut encoder = self
            .device
            .create_command_encoder(&wgpu::CommandEncoderDescriptor {
                label: Some("Screenshot Encoder"),
            });
        let cam_data = self.view.cameras[pane_idx].as_ref().map(|c| c.camera);
        let is_uv_map = pds.pane_mode == PaneMode::UvMap;
        let background = self.resolve_background(&pds);
        let bounds = self.scene_bounds();
        let look = self.pane_look(pane_idx);
        let grid_plane = self.view.cameras[pane_idx]
            .as_ref()
            .map(|c| grid_plane_for(&c.destination_camera()));

        let content = match cam_data {
            None => PaneContent::Empty,
            Some(_) if is_uv_map => PaneContent::Uv {
                source: if self.uv_use_preview {
                    self.uv_scene
                        .draw_object(UV_PREVIEW_ID)
                        .map_or(UvSource::None, UvSource::External)
                } else {
                    UvSource::Scene {
                        preferred: self.selected_object,
                    }
                },
            },
            Some(cam_data) => PaneContent::Scene {
                extra: None,
                selected: self.selected_object,
                cam_data,
                // A capture is one pane on its own, so it owns the shadow map
                // the way pane 0 does in the frame loop.
                shadow: true,
            },
        };

        let capture_scene_present = self.raster.scene().draw_objects().next().is_some();
        let hdr_target = self.renderer.targets.hdr_resolve_view.clone();
        let out = self.raster.encode(
            &mut FrameCtx {
                device: &self.device,
                queue: &self.queue,
                renderer: &mut self.renderer,
                encoder: &mut encoder,
                index: 0,
                rect: full,
                is_split: false,
                pds: &pds,
                display: &self.view.display,
                background,
                camera: self.view.cameras[pane_idx].as_mut(),
                env: &self.env,
                bounds: Some(&bounds),
                grid_plane,
                look,
                scene_present: capture_scene_present,
                // A capture never carries the selection rim.
                outline: false,
                // A screenshot is the whole picture in one pass, capped at four
                // megapixels. Rendering one larger than that is the still job's,
                // and windowing is how it does it.
                window: None,
                content,
            },
            &hdr_target,
        );
        // Read back at slot 0, not at `pane_idx`: the context above encoded as
        // pane 0, because a capture composites as the pane that clears. It
        // overwrites what pane 0 recorded during the last frame, which is
        // harmless only because a capture runs outside the frame loop and the
        // next frame re-encodes every pane before compositing any of them.
        let pass = self.raster.encoded(0).unwrap_or(solarxy_host::EncodedPane {
            is_uv_map: false,
            scene_present: false,
        });
        debug_assert!(matches!(
            out,
            solarxy_renderer::backend::FrameOutcome::Complete
        ));

        self.finish_capture(encoder, &target, pane_idx, pds.inspection_mode, pass);
    }

    /// Composite an encoded capture into its offscreen target and arm the
    /// readback.
    ///
    /// Deliberately not `composite_and_submit`: a capture always clears, uses
    /// a full-rect viewport rather than a pane rect, and carries no selection
    /// rim. Those three are the whole difference between this and the frame
    /// loop's tail, and everything above it is now shared.
    fn finish_capture(
        &mut self,
        mut encoder: wgpu::CommandEncoder,
        target: &CaptureTarget,
        pane_idx: usize,
        inspection: InspectionMode,
        out: solarxy_host::EncodedPane,
    ) {
        let bloom = self.renderer.post.bloom_enabled && !out.is_uv_map && out.scene_present;
        let ssao = self.renderer.post.ssao_enabled && !out.is_uv_map && out.scene_present;
        // A capture runs outside the frame loop, so the slots still hold
        // whatever the last pane drawn happened to bind. Without this, a
        // screenshot of one camera could carry another camera's tables.
        self.bind_pane_luts(pane_idx);
        self.renderer.post.composite.write_params(
            &self.queue,
            bloom,
            ssao,
            &self.pane_look(pane_idx),
            &self.renderer.post.luts,
            inspection,
            false,
        );
        let rect = target.rect;
        self.renderer.post.composite.render(
            &mut encoder,
            &self.renderer.pipelines,
            &target.view,
            ssao,
            &self.renderer.post.ssao,
            Some([rect.x, rect.y, rect.width, rect.height]),
            true,
            None,
        );
        self.queue.submit(std::iter::once(encoder.finish()));

        // The readback copy rides its own submission after the composite.
        let mut copy_encoder =
            self.device
                .create_command_encoder(&wgpu::CommandEncoderDescriptor {
                    label: Some("Screenshot Copy Encoder"),
                });
        let (buffer, padded) = solarxy_renderer::capture::encode_capture(
            &self.device,
            &mut copy_encoder,
            &target.texture,
            (0, 0, target.width, target.height),
        );
        self.queue.submit(std::iter::once(copy_encoder.finish()));
        self.pending_screenshot = Some(solarxy_renderer::capture::PendingCapture::arm(
            buffer,
            padded,
            target.width,
            target.height,
        ));
    }

    /// The camera a pane renders through: its bound camera's saved `CameraDef`
    /// if any, else its scratch camera. The base pose for a turntable sweep.
    fn render_through_camera(&self, pane: usize) -> Option<Camera> {
        let scratch = self
            .view
            .cameras
            .get(pane)
            .and_then(|c| c.as_ref())
            .map(|c| c.camera)?;
        if let Some(node) = self.look_through.get(pane).copied().flatten()
            && let Some(def) = self
                .raster
                .scene()
                .cameras()
                .and_then(|cams| cams.iter().find(|c| c.id == SceneObjectId(node.0)))
        {
            let mut cam = scratch;
            solarxy_host::cameras::apply_camera_def(&mut cam, def);
            return Some(cam);
        }
        Some(scratch)
    }

    /// Renders one turntable frame: the render-through camera rotated by
    /// `azimuth_deg`, offscreen at capture resolution, into the capture slot.
    /// The pane's live camera is swapped in and restored within this call, so a
    /// deterministic sweep never depends on or disturbs the live view / follow.
    fn render_turntable_frame(&mut self, pane: usize, azimuth_deg: f32, opts: &ScreenshotOptsDto) {
        let Some(mut cam) = self.render_through_camera(pane) else {
            return;
        };
        orbit_camera_yaw(&mut cam, azimuth_deg.to_radians());
        let saved = self.view.cameras[pane].as_ref().map(|c| c.camera);
        if let Some(cs) = self.view.cameras[pane].as_mut() {
            cs.camera = cam;
        }
        let prev_active = self.view.active_pane;
        self.view.active_pane = pane;
        self.render_screenshot(opts);
        self.view.active_pane = prev_active;
        if let (Some(saved), Some(cs)) = (saved, self.view.cameras[pane].as_mut()) {
            cs.camera = saved;
        }
    }

    /// Mirrors the graph context the node canvas currently shows (the UV
    /// pane's selected-node source resolves against it).
    pub fn set_current_context(&mut self, ctx: JsValue) -> Result<(), JsError> {
        self.current_ctx = serde_wasm_bindgen::from_value(ctx)
            .map_err(|e| JsError::new(&format!("bad ctx: {e}")))?;
        Ok(())
    }

    /// Marks the scene object produced by `node` as selected (viewport
    /// outline tint); `undefined`/null clears it.
    pub fn set_scene_selection(&mut self, node: Option<f64>) {
        self.selected_object = node.map(|n| SceneObjectId(n as u64));
    }

    /// Applies the selection-highlight preference: `style` is
    /// `"outline"`, `"tint"`, or `"none"`; color is linear RGBA; `width`
    /// is the rim width in pixels (clamped 1..16 renderer-side). The
    /// legacy tint reuses the same color at its fixed 0.35 alpha.
    pub fn set_selection_highlight(
        &mut self,
        style: String,
        r: f32,
        g: f32,
        b: f32,
        a: f32,
        width: f32,
    ) {
        use solarxy_renderer::frame::SelectionStyle;
        let style = match style.as_str() {
            "tint" => SelectionStyle::Tint,
            "none" => SelectionStyle::None,
            _ => SelectionStyle::Outline,
        };
        self.renderer
            .set_selection_highlight(&self.queue, style, [r, g, b, a], width);
    }

    /// Pushes the attribute-label theme colors (linear RGB, converted from
    /// the CSS tokens frontend-side like the selection highlight): text,
    /// background chip, anchor dot. Called at boot and on theme change.
    #[allow(clippy::too_many_arguments)]
    pub fn set_label_colors(
        &mut self,
        text_r: f32,
        text_g: f32,
        text_b: f32,
        chip_r: f32,
        chip_g: f32,
        chip_b: f32,
        dot_r: f32,
        dot_g: f32,
        dot_b: f32,
    ) {
        self.label_colors = [
            [text_r, text_g, text_b],
            [chip_r, chip_g, chip_b],
            [dot_r, dot_g, dot_b],
        ];
        self.push_label_style();
    }

    /// Rebuilds the label style from the two halves that own it: the theme
    /// colors pushed by `set_label_colors`, and the size / background /
    /// opacity the user picked in the attribute settings. Kept as one
    /// chokepoint so neither half can push a style that drops the other.
    fn push_label_style(&mut self) {
        let base = solarxy_renderer::labels::LabelStyle {
            text: self.label_colors[0],
            chip: self.label_colors[1],
            dot: self.label_colors[2],
            dpr: self.dpr,
            ..solarxy_renderer::labels::LabelStyle::new_default()
        };
        let style = self.attr_viz.apply_to_style(base);
        self.renderer.write_label_style(&self.queue, &style);
    }

    // ---- view-state boundary (host-owned; React mirrors) ----

    /// The full view state for the mirror.
    pub fn view_state(&self) -> Result<JsValue, JsError> {
        to_js(&self.view_state_dto())
    }

    /// Sets the pane layout (F1-F5). `layout` is the camelCase name
    /// (`"single"`, `"splitVertical"`, ...). Returns the new view state.
    pub fn set_view_layout(&mut self, layout: JsValue) -> Result<JsValue, JsError> {
        let layout: ViewLayout = serde_wasm_bindgen::from_value(layout)
            .map_err(|e| JsError::new(&format!("bad layout: {e}")))?;
        self.view.display.layout = layout;
        if self.view.active_pane >= layout.pane_count() {
            self.view.active_pane = 0;
        }
        self.ensure_pane_cameras();
        self.view_state()
    }

    /// Sets the two-pane divider ratio (clamped 0.05-0.95).
    pub fn set_split_ratio(&mut self, ratio: f32) -> Result<JsValue, JsError> {
        self.view.display.split_ratio = DisplaySettings::clamp_split_ratio(ratio);
        self.view_state()
    }

    pub fn set_active_pane(&mut self, pane: usize) -> Result<JsValue, JsError> {
        if pane < self.view.display.layout.pane_count() {
            self.view.active_pane = pane;
        }
        self.view_state()
    }

    /// Binds pane `pane` to look through the `camera` node id, or clears to a
    /// free view when `camera` is negative / non-finite. Returns the view state.
    pub fn set_pane_camera(&mut self, pane: usize, camera: f64) -> Result<JsValue, JsError> {
        if pane < 4 {
            self.look_through[pane] = if camera.is_finite() && camera >= 0.0 {
                Some(NodeId(camera as u64))
            } else {
                None
            };
            if self.look_through[pane].is_none() {
                self.camera_locked[pane] = false;
            }
            self.camera_editing[pane] = false;
        }
        self.view_state()
    }

    /// Toggles lock-camera-to-view for a look-through pane (Blender semantics:
    /// navigation reframes the bound camera). No effect on a free view.
    pub fn set_pane_camera_lock(&mut self, pane: usize, locked: bool) -> Result<JsValue, JsError> {
        if pane < 4 && self.look_through[pane].is_some() {
            self.camera_locked[pane] = locked;
            self.camera_editing[pane] = false;
        }
        self.view_state()
    }

    /// Jumps a pane's (free) view to a camera node's saved pose without binding
    /// or locking it (the bookmark action). Returns the view state.
    pub fn jump_to_camera(&mut self, pane: usize, camera: f64) -> Result<JsValue, JsError> {
        if pane < 4 && camera.is_finite() && camera >= 0.0 {
            let id = SceneObjectId(camera as u64);
            let def = self
                .raster
                .scene()
                .cameras()
                .and_then(|cams| cams.iter().find(|c| c.id == id).cloned());
            if let (Some(def), Some(cam)) = (def, self.view.cameras[pane].as_mut()) {
                solarxy_host::cameras::apply_camera_def(&mut cam.camera, &def);
            }
        }
        self.view_state()
    }

    /// The current pose (eye + target) of a pane's camera, so the frontend can
    /// author a new `camera` node framed on the current view (create-from-view
    /// is a frontend-orchestrated `AddNode` + `SetParam`, keeping the
    /// mirror-and-command model intact).
    pub fn pane_camera_pose(&self, pane: usize) -> Result<JsValue, JsError> {
        let (position, target) = self.view.cameras.get(pane).and_then(|c| c.as_ref()).map_or(
            ([7.0, 5.0, 7.0], [0.0, 0.0, 0.0]),
            |c| {
                (
                    [c.camera.eye.x, c.camera.eye.y, c.camera.eye.z],
                    [c.camera.target.x, c.camera.target.y, c.camera.target.z],
                )
            },
        );
        to_js(&CameraPoseDto { position, target })
    }

    /// Flies the active pane's camera to frame the mesh a validation issue
    /// lives on (report-panel row click; the desktop Properties fly-to) and
    /// enables that pane's validation overlay so the defect is visible.
    /// `object` is the owning geo node's id (= scene object id); `source`
    /// the node whose report the panel is showing (its engine-cached
    /// result is authoritative, which may differ from the object's
    /// effective overlay validation); `issue` the row index. Returns the
    /// view state.
    pub fn fly_to_issue(
        &mut self,
        object: f64,
        source: f64,
        issue: usize,
    ) -> Result<JsValue, JsError> {
        let id = SceneObjectId(object as u64);
        let source = solarxy_graph::document::NodeId(source as u64);
        let aabb = self.engine.validation(source).and_then(|v| {
            let issue = v.report.issues.get(issue)?;
            let obj = self.raster.scene().get(id)?;
            let raw_to_gpu = self.raster.scene().raw_to_gpu(id)?;
            solarxy_renderer::validation::resolve_issue_aabb(&issue.scope, &obj.model, raw_to_gpu)
        });
        if let Some(aabb) = aabb {
            let pane = self.view.active_pane;
            if let Some(settings) = self.view.pane_settings.get_mut(pane) {
                settings.show_validation = true;
            }
            if let Some(cam) = self.view.cameras.get_mut(pane).and_then(|c| c.as_mut()) {
                cam.reset_to_bounds(&aabb);
            }
        }
        self.view_state()
    }

    /// Replaces one pane's display settings with the full settings object.
    pub fn set_pane_settings(
        &mut self,
        pane: usize,
        settings: JsValue,
    ) -> Result<JsValue, JsError> {
        let settings: PaneDisplaySettings = serde_wasm_bindgen::from_value(settings)
            .map_err(|e| JsError::new(&format!("bad pane settings: {e}")))?;
        let mut engine_flip = None;
        if let Some(slot) = self.view.pane_settings.get_mut(pane) {
            // Turning the overlap display on arms a fresh statistic run
            // (the desktop `O`-toggle behavior).
            if settings.show_uv_overlap && !slot.show_uv_overlap {
                self.renderer.uv_overlap.overlap_pct = None;
                self.renderer.uv_overlap.stats_dirty = true;
            }
            // A newly enabled normals/bounds overlay may need the (lazily
            // built) visualization aggregate.
            if settings.normals_mode != slot.normals_mode
                || settings.bounds_mode != slot.bounds_mode
            {
                self.viz_dirty = true;
            }
            if settings.pane_engine != slot.pane_engine {
                engine_flip = Some(settings.pane_engine);
            }
            *slot = settings;
        }
        if let Some(engine) = engine_flip {
            // Flipping to the tracer builds it on first use and hands it
            // the scene it has never seen: the per-frame delta feed only
            // reaches it while a pane is watching, so a scene edited with
            // every pane raster has moved on without it. The snapshot
            // reconciles, so an unchanged scene is a hierarchy-cache hit.
            if engine == PaneEngine::Traced {
                if self.tracer.is_none() {
                    self.tracer = Some(PathBackend::new(&self.device, &self.queue));
                    self.traced_env_dirty = true;
                }
                let delta = self.engine.scene_snapshot();
                if let Some(t) = self.tracer.as_mut() {
                    t.apply_snapshot(&self.device, &self.queue, &delta);
                }
            }
            // Either direction resets the pane: the first traced frame is
            // sample one rather than a stale mean, and a return to raster
            // leaves nothing parked.
            if let Some(t) = self.tracer.as_mut() {
                t.invalidate_pane(pane);
            }
            if let Some(slot) = self.traced_cam_keys.get_mut(pane) {
                *slot = None;
            }
            if let Some(slot) = self.last_pane_samples.get_mut(pane) {
                *slot = None;
            }
        }
        self.view_state()
    }

    /// What each render backend can do, for the frontend's menu gating.
    ///
    /// The capability fields are constants, so the answer needs no device: a
    /// menu deciding what a backend produces should not have to build one to
    /// ask. **Availability is not a constant**, and used to be treated as one.
    /// The tracer spends core WebGPU's per-stage budget exactly, so a device at
    /// downlevel limits cannot build its layouts, and answering from a constant
    /// offered the mode on a device where it would have failed at pipeline
    /// creation. `available` asks the real device's limits.
    #[wasm_bindgen(js_name = backendCaps)]
    pub fn backend_caps(&self) -> Result<JsValue, JsError> {
        // Four independent yes-or-no facts about a backend, which is what the
        // wire shape is; grouping them to satisfy the lint would invent a
        // structure the TypeScript mirror would then have to invent too.
        #[allow(clippy::struct_excessive_bools)]
        #[derive(Serialize)]
        #[serde(rename_all = "camelCase")]
        struct CapsDto {
            progressive: bool,
            supports_instancing: bool,
            writes_aovs: bool,
            /// Whether this device can run the backend at all.
            available: bool,
        }
        #[derive(Serialize)]
        #[serde(rename_all = "camelCase")]
        struct BackendCapsDto {
            raster: CapsDto,
            traced: CapsDto,
        }
        fn dto(c: solarxy_renderer::backend::BackendCaps, available: bool) -> CapsDto {
            CapsDto {
                progressive: c.progressive,
                supports_instancing: c.supports_instancing,
                writes_aovs: c.writes_aovs,
                available,
            }
        }
        // The rasterizer is what the surface is already drawing with, so its
        // availability is not in question by the time anything can ask.
        to_js(&BackendCapsDto {
            raster: dto(solarxy_host::RasterBackend::CAPS, true),
            traced: dto(
                PathBackend::CAPS,
                solarxy_renderer::pathtrace::device_supports_tracing(&self.device.limits()),
            ),
        })
    }

    /// Replaces the global display settings (layout, split, turntable,
    /// lights lock, material scales, HDRI rotation).
    /// Replace one pane's own look: exposure, tone mapper, and the
    /// lift/gamma/gain grade.
    ///
    /// Only reaches a pane that is a free view. A pane looking through a
    /// camera composites with that camera's look, which is a document
    /// value and is edited by setting the node's parameters like any
    /// other. Carries no lookup-table slots for the same reason: a table
    /// is a staged document asset, and a pane is not a document object.
    pub fn set_pane_look(&mut self, pane: usize, look: JsValue) -> Result<JsValue, JsError> {
        let look: PaneLook = serde_wasm_bindgen::from_value(look)
            .map_err(|e| JsError::new(&format!("bad pane look: {e}")))?;
        if let Some(slot) = self.pane_looks.get_mut(pane) {
            *slot = look;
        }
        self.view_state()
    }

    pub fn set_display_settings(&mut self, settings: JsValue) -> Result<JsValue, JsError> {
        let settings: DisplaySettings = serde_wasm_bindgen::from_value(settings)
            .map_err(|e| JsError::new(&format!("bad display settings: {e}")))?;
        self.view.display = settings;
        self.ensure_pane_cameras();
        self.view_state()
    }

    /// A camera command on a pane: `{kind:"fit"}`, `{kind:"view",
    /// axis:"top"|"bottom"|"front"|"back"|"left"|"right"}`, or
    /// `{kind:"projection", mode:"perspective"|"orthographic"}`. Returns the
    /// refreshed [`ViewStateDto`] like every other view mutator -- a view
    /// preset flips the pane to orthographic, and without the mirror update
    /// the toolbar's Persp/Ortho label kept showing the stale mode.
    pub fn camera_command(&mut self, pane: usize, cmd: JsValue) -> Result<JsValue, JsError> {
        let cmd: CameraCommandDto = serde_wasm_bindgen::from_value(cmd)
            .map_err(|e| JsError::new(&format!("bad camera command: {e}")))?;
        let bounds = self.scene_bounds();
        // Resolved before the camera is borrowed mutably, and unconditionally
        // rather than inside the arm, because both reads want `&self`.
        let selection = self.selection_bounds().unwrap_or(bounds);
        let Some(cam) = self.view.cameras.get_mut(pane).and_then(|c| c.as_mut()) else {
            return self.view_state();
        };
        match cmd.kind.as_str() {
            "fit" => cam.reset_to_bounds(&bounds),
            // Falls back to the whole scene when nothing is selected or the
            // selection has no place in the world, which is the same thing
            // `fit` does and never a camera that goes nowhere.
            "fitSelection" => cam.reset_to_bounds(&selection),
            "view" => {
                let (dir, up) = match cmd.axis.as_str() {
                    "top" => (Vector3::unit_y(), -Vector3::unit_z()),
                    "bottom" => (-Vector3::unit_y(), Vector3::unit_z()),
                    "front" => (Vector3::unit_z(), Vector3::unit_y()),
                    "back" => (-Vector3::unit_z(), Vector3::unit_y()),
                    "left" => (-Vector3::unit_x(), Vector3::unit_y()),
                    "right" => (Vector3::unit_x(), Vector3::unit_y()),
                    other => return Err(JsError::new(&format!("bad view axis: {other}"))),
                };
                cam.reset_to_bounds_axis(&bounds, dir, up);
            }
            "projection" => {
                let mode = if cmd.mode == "orthographic" {
                    ProjectionMode::Orthographic
                } else {
                    ProjectionMode::Perspective
                };
                cam.set_projection(mode);
            }
            other => return Err(JsError::new(&format!("bad camera command: {other}"))),
        }
        self.view_state()
    }

    /// The current pane rectangles in CSS pixels (DOM toolbar positioning).
    pub fn pane_rects(&self) -> Result<JsValue, JsError> {
        to_js(&self.pane_rects_css())
    }

    /// Drains queued host events (pane-rect changes, async results).
    pub fn take_host_events(&mut self) -> Result<JsValue, JsError> {
        // Uncaptured GPU faults ride the same per-frame drain as every
        // other async happening.
        for fault in self.gpu_faults.drain() {
            use solarxy_renderer::faults::GpuFaultKind;
            self.host_events.push(HostEvent::GpuFault {
                kind: match fault.kind {
                    GpuFaultKind::Validation => "validation",
                    GpuFaultKind::OutOfMemory => "outOfMemory",
                    GpuFaultKind::Internal => "internal",
                },
                message: fault.message,
                count: fault.count,
            });
        }
        let events = std::mem::take(&mut self.host_events);
        to_js(&events)
    }

    // ---- mirror / persistence boundary (unchanged surfaces) ----

    /// The full document mirror (recovery after desync / structural undo).
    pub fn snapshot(&self) -> Result<JsValue, JsError> {
        to_js(&self.engine.snapshot())
    }

    /// The static registry snapshot (fetched once; drives palette + panel).
    pub fn registry_snapshot(&self) -> Result<JsValue, JsError> {
        to_js(&self.engine.registry_snapshot())
    }

    /// Captures a clipboard fragment of the given nodes (the frontend
    /// serializes it to `application/x-solarxy-nodes`). `ctx` is a
    /// `GraphContext`; `ids` a number array.
    pub fn copy_nodes(&self, ctx: JsValue, ids: Vec<f64>) -> Result<JsValue, JsError> {
        let ctx = serde_wasm_bindgen::from_value(ctx)
            .map_err(|e| JsError::new(&format!("bad ctx: {e}")))?;
        let ids: Vec<solarxy_graph::document::NodeId> = ids
            .into_iter()
            .map(|n| solarxy_graph::document::NodeId(n as u64))
            .collect();
        to_js(&self.engine.copy_nodes(ctx, &ids))
    }

    /// The ids of currently stale (dirty) nodes, for manual-mode badges and
    /// the header stale count.
    pub fn stale_nodes(&self) -> Vec<f64> {
        self.engine
            .dirty_nodes()
            .into_iter()
            .map(|n| n.0 as f64)
            .collect()
    }

    /// The number of registered node types (a boot smoke check).
    pub fn node_type_count(&self) -> usize {
        self.engine.registry().len()
    }

    /// The number of rendered objects (a smoke check that cooked geometry
    /// reached the GPU).
    pub fn object_count(&self) -> usize {
        self.raster.scene().draw_objects().count()
    }

    // ---- asset staging + the import-worker pump ----

    /// Stages asset bytes into the engine, returning the content id (its
    /// SHA-256 hex) the import node's `file` param references. The `_sha256`
    /// the caller computed for its OPFS cache is not trusted; the engine
    /// recomputes and the returned id is authoritative.
    pub fn stage_asset(
        &mut self,
        name: String,
        mime: String,
        _sha256: String,
        bytes: Vec<u8>,
    ) -> String {
        self.engine.stage_asset(name, mime, bytes).0
    }

    /// The staged bytes for an asset id, as a `Uint8Array`, or `undefined`.
    /// Lets the frontend feed the worker after a scene load, when its own
    /// JS-side byte cache is cold.
    pub fn asset_bytes(&self, hash: String) -> Option<js_sys::Uint8Array> {
        self.engine
            .asset_bytes(&solarxy_graph::params::AssetId(hash))
            .map(js_sys::Uint8Array::from)
    }

    /// Every staged asset as `[{ hash, name }]`. The sidecar preflight
    /// diffs a model's referenced companions against it, so the check is
    /// authoritative across reloads and `.slxy` restores (a JS-side cache
    /// of staged names would go cold on both).
    pub fn asset_manifest(&self) -> Result<JsValue, JsError> {
        let manifest: Vec<AssetRefDto> = self
            .engine
            .asset_manifest()
            .iter()
            .map(|(h, n)| AssetRefDto {
                hash: h.clone(),
                name: n.clone(),
            })
            .collect();
        to_js(&manifest)
    }

    /// Drains the import jobs the last cook spawned into a JS array of
    /// `{ ctx, jobId, hash, name, format, options, sidecars }`. The frontend
    /// gathers each job's bytes, posts them to the import worker, and returns
    /// the result through `submit_parsed_model` / `submit_parse_error`.
    /// `ValidateGeometry` jobs drained alongside are stashed for
    /// [`SolarxyApp::take_validate_jobs`].
    pub fn take_import_jobs(&mut self) -> Result<JsValue, JsError> {
        let manifest = self.engine.asset_manifest();
        let mut payloads: Vec<ImportJobDto> = Vec::new();
        for (ctx, job, req) in self.engine.take_jobs() {
            let (asset, format, options) = match req {
                JobRequest::ParseModel {
                    asset,
                    format,
                    options,
                } => (asset, format, options),
                JobRequest::ValidateGeometry {
                    geometry,
                    config,
                    budget,
                } => {
                    // Pack the geometry once, at drain time; the frontend
                    // moves plain bytes to the worker.
                    let config_json = serde_json::to_string(&config)
                        .map_err(|e| JsError::new(&format!("serialize config: {e}")))?;
                    self.pending_validate.push(PendingValidateJob {
                        ctx,
                        job_id: job.0,
                        blob: transfer::pack(&geometry),
                        config_json,
                        budget,
                    });
                    continue;
                }
                JobRequest::DecodeImage { asset } => {
                    let name = manifest
                        .iter()
                        .find(|(h, _)| *h == asset.0)
                        .map_or_else(String::new, |(_, n)| n.clone());
                    self.pending_image.push(PendingImageJob {
                        ctx,
                        job_id: job.0,
                        hash: asset.0,
                        name,
                    });
                    continue;
                }
                JobRequest::DecodeHdrImage { asset } => {
                    let name = manifest
                        .iter()
                        .find(|(h, _)| *h == asset.0)
                        .map_or_else(String::new, |(_, n)| n.clone());
                    self.pending_hdri.push(PendingHdriJob {
                        ctx,
                        job_id: job.0,
                        hash: asset.0,
                        name,
                    });
                    continue;
                }
            };
            let name = manifest
                .iter()
                .find(|(h, _)| *h == asset.0)
                .map_or_else(String::new, |(_, n)| n.clone());
            // OBJ/glTF resolve companions (mtl, bin, textures) by name;
            // hand the worker the other staged files as candidate
            // sidecars. Self-contained STL/PLY need none.
            let sidecars = if matches!(format.as_str(), "obj" | "gltf" | "glb") {
                manifest
                    .iter()
                    .filter(|(h, _)| *h != asset.0)
                    .map(|(h, n)| AssetRefDto {
                        hash: h.clone(),
                        name: n.clone(),
                    })
                    .collect()
            } else {
                Vec::new()
            };
            payloads.push(ImportJobDto {
                ctx,
                job_id: job.0 as f64,
                hash: asset.0,
                name,
                format,
                options,
                sidecars,
            });
        }
        to_js(&payloads)
    }

    /// Drains the stashed geometry-validation jobs into a JS array of
    /// `{ ctx, jobId, blob, config, budget }` (`blob` is a `Uint8Array`
    /// transfer blob of the geometry; `config` a JSON `ValidationConfig`).
    /// The frontend posts each to the worker's `validate_geometry_job` and
    /// returns the result through `submit_validation_result` /
    /// `submit_validation_error`. Call after `take_import_jobs` (which
    /// performs the drain from the engine).
    pub fn take_validate_jobs(&mut self) -> Result<JsValue, JsError> {
        let out = js_sys::Array::new();
        for job in self.pending_validate.drain(..) {
            let o = js_sys::Object::new();
            let set = |key: &str, value: &JsValue| {
                js_sys::Reflect::set(&o, &JsValue::from_str(key), value)
                    .map_err(|_| JsError::new("take_validate_jobs: reflect set failed"))
                    .map(|_| ())
            };
            set("ctx", &to_js(&job.ctx)?)?;
            set("jobId", &JsValue::from_f64(job.job_id as f64))?;
            set("blob", &js_sys::Uint8Array::from(job.blob.as_slice()))?;
            set("config", &JsValue::from_str(&job.config_json))?;
            set(
                "budget",
                &job.budget
                    .map_or(JsValue::UNDEFINED, |b| JsValue::from_f64(f64::from(b))),
            )?;
            out.push(&o);
        }
        Ok(out.into())
    }

    /// Drains the stashed image-decode jobs into a JS array of
    /// `{ ctx, jobId, hash, name }`. The frontend pulls the encoded bytes
    /// by hash (`asset_bytes`), posts them to the worker's decode-image
    /// path (`createImageBitmap`), and returns the RGBA result through
    /// `submit_decoded_image` / `submit_image_error`. Call after
    /// `take_import_jobs` (which performs the drain from the engine).
    pub fn take_image_jobs(&mut self) -> Result<JsValue, JsError> {
        let out = js_sys::Array::new();
        for job in self.pending_image.drain(..) {
            let o = js_sys::Object::new();
            let set = |key: &str, value: &JsValue| {
                js_sys::Reflect::set(&o, &JsValue::from_str(key), value)
                    .map_err(|_| JsError::new("take_image_jobs: reflect set failed"))
                    .map(|_| ())
            };
            set("ctx", &to_js(&job.ctx)?)?;
            set("jobId", &JsValue::from_f64(job.job_id as f64))?;
            set("hash", &JsValue::from_str(&job.hash))?;
            set("name", &JsValue::from_str(&job.name))?;
            out.push(&o);
        }
        Ok(out.into())
    }

    /// Drains the stashed HDRI-decode jobs into a JS array of
    /// `{ ctx, jobId, hash, name }`. The frontend pulls the encoded bytes
    /// by hash and posts them to the worker's HDRI path, returning the
    /// prepared result through `submit_decoded_hdri` / `submit_hdri_error`.
    /// Call after `take_import_jobs` (which performs the drain from the
    /// engine).
    pub fn take_hdri_jobs(&mut self) -> Result<JsValue, JsError> {
        let out = js_sys::Array::new();
        for job in self.pending_hdri.drain(..) {
            let o = js_sys::Object::new();
            let set = |key: &str, value: &JsValue| {
                js_sys::Reflect::set(&o, &JsValue::from_str(key), value)
                    .map_err(|_| JsError::new("take_hdri_jobs: reflect set failed"))
                    .map(|_| ())
            };
            set("ctx", &to_js(&job.ctx)?)?;
            set("jobId", &JsValue::from_f64(job.job_id as f64))?;
            set("hash", &JsValue::from_str(&job.hash))?;
            set("name", &JsValue::from_str(&job.name))?;
            out.push(&o);
        }
        Ok(out.into())
    }

    /// Commits a worker-decoded HDRI under the per-node generation guard.
    ///
    /// Takes the packed `PreparedHdri` the worker already produces, which
    /// carries the CPU lighting stages alongside the pixels. That is why
    /// the environment node reuses the existing worker entry point rather
    /// than a lean decode: the irradiance convolution stays off the main
    /// thread, and this call installs the result directly instead of
    /// making the tracker convolve it again on the next delta.
    pub fn submit_decoded_hdri(
        &mut self,
        ctx: JsValue,
        job_id: f64,
        prepared: Vec<u8>,
    ) -> Result<JsValue, JsError> {
        let ctx: GraphContext = serde_wasm_bindgen::from_value(ctx)
            .map_err(|e| JsError::new(&format!("bad ctx: {e}")))?;
        let prepared = solarxy_renderer::ibl::PreparedHdri::unpack(&prepared)
            .map_err(|e| JsError::new(&format!("bad prepared HDRI: {e}")))?;

        // Install on the GPU now, while the convolved faces are in hand.
        self.renderer.ibl_res.ibl =
            solarxy_renderer::ibl::IblState::from_prepared(&self.device, &self.queue, &prepared);

        // Hand the engine the image itself, so the scene delta can carry
        // it and a save can embed it. The hash is stamped here, Rust-side,
        // by the same constructor the native path uses.
        let image = std::sync::Arc::new(solarxy_core::RawImageHdr::new(
            prepared.pixels,
            prepared.width,
            prepared.height,
        ));
        // Tell the tracker this hash is already live, so the delta that
        // follows sees `Unchanged` rather than convolving it a second time
        // on the main thread.
        self.environment.note_installed(image.hash);
        self.rebuild_light_bind_group();

        let events = self.engine.submit_job_result(
            ctx,
            JobId(job_id as u64),
            JobResult::HdrImage(Ok(image)),
        );
        to_js(&EventBatch {
            revision: self.engine.revision(),
            events,
        })
    }

    /// Reports a worker HDRI-decode failure: the `environment` node badges
    /// the error and the viewport keeps the environment it had.
    pub fn submit_hdri_error(
        &mut self,
        ctx: JsValue,
        job_id: f64,
        message: String,
    ) -> Result<JsValue, JsError> {
        let ctx: GraphContext = serde_wasm_bindgen::from_value(ctx)
            .map_err(|e| JsError::new(&format!("bad ctx: {e}")))?;
        let events = self.engine.submit_job_result(
            ctx,
            JobId(job_id as u64),
            JobResult::HdrImage(Err(message)),
        );
        to_js(&EventBatch {
            revision: self.engine.revision(),
            events,
        })
    }

    /// Commits a worker-decoded image (raw RGBA8 plus dimensions) under
    /// the per-node generation guard, returning the cook `EventBatch`.
    /// The content hash is stamped here, Rust-side, so every producer
    /// (native decode, worker decode, transfer unpack) yields identical
    /// hashes for identical pixels.
    pub fn submit_decoded_image(
        &mut self,
        ctx: JsValue,
        job_id: f64,
        width: u32,
        height: u32,
        pixels: Vec<u8>,
    ) -> Result<JsValue, JsError> {
        let ctx: GraphContext = serde_wasm_bindgen::from_value(ctx)
            .map_err(|e| JsError::new(&format!("bad ctx: {e}")))?;
        let expected = (width as usize) * (height as usize) * 4;
        if pixels.len() != expected {
            return Err(JsError::new(&format!(
                "decoded image is {} bytes, expected {expected} ({width}x{height} RGBA)",
                pixels.len()
            )));
        }
        let image = std::sync::Arc::new(solarxy_core::RawImageData::new(pixels, width, height));
        let events =
            self.engine
                .submit_job_result(ctx, JobId(job_id as u64), JobResult::Image(Ok(image)));
        to_js(&EventBatch {
            revision: self.engine.revision(),
            events,
        })
    }

    /// Reports a worker image-decode failure: the `import_image` node badges
    /// the error while keep-last-good holds the previous image.
    pub fn submit_image_error(
        &mut self,
        ctx: JsValue,
        job_id: f64,
        message: String,
    ) -> Result<JsValue, JsError> {
        let ctx: GraphContext = serde_wasm_bindgen::from_value(ctx)
            .map_err(|e| JsError::new(&format!("bad ctx: {e}")))?;
        let events = self.engine.submit_job_result(
            ctx,
            JobId(job_id as u64),
            JobResult::Image(Err(message)),
        );
        to_js(&EventBatch {
            revision: self.engine.revision(),
            events,
        })
    }

    /// Commits a worker validation result (the JSON `ValidationResult` from
    /// `validate_geometry_job`) under the generation guard, returning the
    /// cook `EventBatch`.
    pub fn submit_validation_result(
        &mut self,
        ctx: JsValue,
        job_id: f64,
        result_json: String,
    ) -> Result<JsValue, JsError> {
        let ctx: GraphContext = serde_wasm_bindgen::from_value(ctx)
            .map_err(|e| JsError::new(&format!("bad ctx: {e}")))?;
        let result: ValidationResult = serde_json::from_str(&result_json)
            .map_err(|e| JsError::new(&format!("bad validation result: {e}")))?;
        let events =
            self.engine
                .submit_job_result(ctx, JobId(job_id as u64), JobResult::Report(Ok(result)));
        to_js(&EventBatch {
            revision: self.engine.revision(),
            events,
        })
    }

    /// Reports a worker validation failure for a job (the validate node
    /// badges the error, keep-last-good holds its previous outputs).
    pub fn submit_validation_error(
        &mut self,
        ctx: JsValue,
        job_id: f64,
        message: String,
    ) -> Result<JsValue, JsError> {
        let ctx: GraphContext = serde_wasm_bindgen::from_value(ctx)
            .map_err(|e| JsError::new(&format!("bad ctx: {e}")))?;
        let events = self.engine.submit_job_result(
            ctx,
            JobId(job_id as u64),
            JobResult::Report(Err(message)),
        );
        to_js(&EventBatch {
            revision: self.engine.revision(),
            events,
        })
    }

    /// Commits a worker-parsed model (the transfer blob from
    /// `parse_model_job`, plus its implicit load-validation JSON) under the
    /// per-node generation guard, returning the cook `EventBatch`. A
    /// superseded result is dropped inside the engine.
    pub fn submit_parsed_model(
        &mut self,
        ctx: JsValue,
        job_id: f64,
        blob: Vec<u8>,
        validation_json: Option<String>,
    ) -> Result<JsValue, JsError> {
        let ctx: GraphContext = serde_wasm_bindgen::from_value(ctx)
            .map_err(|e| JsError::new(&format!("bad ctx: {e}")))?;
        let set =
            transfer::unpack(&blob).map_err(|e| JsError::new(&format!("bad model blob: {e}")))?;
        let validation: Option<ValidationResult> = match validation_json {
            Some(json) => Some(
                serde_json::from_str(&json)
                    .map_err(|e| JsError::new(&format!("bad validation payload: {e}")))?,
            ),
            None => None,
        };
        let events = self.engine.submit_job_result(
            ctx,
            JobId(job_id as u64),
            JobResult::Model(Ok(ParsedModel { set, validation })),
        );
        to_js(&EventBatch {
            revision: self.engine.revision(),
            events,
        })
    }

    /// Reports a worker parse failure for a job: the import node badges the
    /// error while keep-last-good holds the last valid geometry.
    pub fn submit_parse_error(
        &mut self,
        ctx: JsValue,
        job_id: f64,
        message: String,
    ) -> Result<JsValue, JsError> {
        let ctx: GraphContext = serde_wasm_bindgen::from_value(ctx)
            .map_err(|e| JsError::new(&format!("bad ctx: {e}")))?;
        let events = self.engine.submit_job_result(
            ctx,
            JobId(job_id as u64),
            JobResult::Model(Err(message)),
        );
        to_js(&EventBatch {
            revision: self.engine.revision(),
            events,
        })
    }

    // ---- .slxy save / load ----

    /// Builds `.slxy` archive bytes from the current document, its referenced
    /// assets, and the host `extra` (generator, canvas viewports, meta). The
    /// full view state (layout, split, all four pane cameras + display
    /// settings) rides the sidecar.
    /// Installs a prepared HDRI environment: unpacks the worker's
    /// `prepare_hdri_job` blob, finishes the IBL on the GPU, points the
    /// skybox at the new equirect, and rebuilds the light bind group (the
    /// desktop `rebuild_light_bind_group` chokepoint). `hash`/`name`
    /// identify the staged HDRI asset for the `.slxy` environment section.
    pub fn set_environment_prepared(
        &mut self,
        hash: String,
        name: String,
        prepared: Vec<u8>,
    ) -> Result<(), JsError> {
        let prepared = solarxy_renderer::ibl::PreparedHdri::unpack(&prepared)
            .map_err(|e| JsError::new(&format!("bad prepared HDRI: {e}")))?;
        self.renderer.ibl_res.ibl =
            solarxy_renderer::ibl::IblState::from_prepared(&self.device, &self.queue, &prepared);
        self.hdri = Some(HdriMeta { hash, name });
        self.environment.invalidate();
        self.traced_env_dirty = true;
        self.rebuild_light_bind_group();
        Ok(())
    }

    /// Clears the HDRI back to the procedural sky derived from the primary
    /// pane's background (the desktop clear-HDRI behavior).
    pub fn clear_environment(&mut self) {
        let (top, bottom) = self
            .resolve_background(&self.view.pane_settings[0])
            .sky_colors();
        self.renderer.ibl_res.ibl = solarxy_renderer::ibl::IblState::from_sky_colors(
            &self.device,
            &self.queue,
            top,
            bottom,
        );
        self.hdri = None;
        self.environment.invalidate();
        self.traced_env_dirty = true;
        self.rebuild_light_bind_group();
    }

    /// Sets the IBL contribution mode (`"off"` / `"diffuse"` / `"full"`).
    pub fn set_ibl_mode(&mut self, mode: String) {
        self.renderer.ibl_res.ibl_mode = match mode.to_ascii_lowercase().as_str() {
            "off" => IblMode::Off,
            "diffuse" => IblMode::Diffuse,
            _ => IblMode::Full,
        };
        self.rebuild_light_bind_group();
    }

    /// The current environment as a DTO (`{ iblMode, hdriHash, hdriName }`)
    /// for the frontend panel.
    pub fn environment_state(&self) -> Result<JsValue, JsError> {
        to_js(&EnvironmentDto {
            ibl_mode: match self.renderer.ibl_res.ibl_mode {
                IblMode::Off => "off",
                IblMode::Diffuse => "diffuse",
                IblMode::Full => "full",
            }
            .to_string(),
            hdri_hash: self.hdri.as_ref().map(|h| h.hash.clone()),
            hdri_name: self.hdri.as_ref().map(|h| h.name.clone()),
            from_node: self.engine.has_environment_node(),
        })
    }

    pub fn save_slxy(&self, extra: JsValue) -> Result<Vec<u8>, JsError> {
        let extra: SaveExtra = serde_wasm_bindgen::from_value(extra).unwrap_or_default();
        let mut sidecar = SceneSidecar {
            generator: if extra.generator.is_empty() {
                "solarxy-web".to_string()
            } else {
                extra.generator
            },
            ..SceneSidecar::default()
        };
        sidecar.view = self.view_json();
        sidecar.environment = self.environment_json();
        sidecar.canvas_viewports = extra
            .canvas_viewports
            .into_iter()
            .map(|(k, v)| (k, v.into()))
            .collect();
        sidecar.meta = extra.meta.into();
        self.engine
            .save_slxy(&sidecar)
            .map_err(|e| JsError::new(&format!("save .slxy: {e}")))
    }

    /// Replaces the document from `.slxy` bytes: stages the embedded assets,
    /// applies the saved view state (layout, split, pane cameras + display
    /// settings), and returns `{ batch, warnings, canvasViewports, meta }`
    /// for the mirror and the frontend view state.
    pub fn load_slxy(&mut self, bytes: Vec<u8>) -> Result<JsValue, JsError> {
        let loaded = self
            .engine
            .load_slxy(&bytes)
            .map_err(|e| JsError::new(&format!("load .slxy: {e}")))?;
        self.apply_view_json(&loaded.sidecar.view);
        // The saved IBL mode applies immediately; the HDRI itself needs the
        // worker's CPU stages, so the frontend re-prepares it from the
        // restored asset bytes and calls `set_environment_prepared`.
        let env = &loaded.sidecar.environment;
        if !env.ibl_mode.is_empty() {
            self.set_ibl_mode(env.ibl_mode.clone());
        }
        if let Some(rotation) = env
            .background
            .get("hdriRotation")
            .and_then(serde_json::Value::as_f64)
        {
            self.view.display.hdri_rotation = rotation as f32;
        }
        self.hdri = None;
        let from_node = self.engine.has_environment_node();
        // A node-authored environment supersedes the sidecar, so forget
        // whatever the tracker holds and let the node's first delta
        // install afresh.
        if from_node {
            self.environment.invalidate();
        }
        let environment = EnvironmentDto {
            ibl_mode: env.ibl_mode.clone(),
            hdri_hash: env.hdri_asset.clone(),
            hdri_name: None,
            from_node,
        };
        let result = LoadResultDto {
            batch: loaded.batch,
            warnings: loaded.warnings,
            canvas_viewports: loaded
                .sidecar
                .canvas_viewports
                .into_iter()
                .map(|(k, v)| (k, v.into()))
                .collect(),
            meta: loaded.sidecar.meta.into(),
            environment,
        };
        to_js(&result)
    }
}

// The gizmo drag loop. Lives entirely in Rust: `pointer_move` runs at pointer
// rate, and a boundary crossing per move would be a waste.
impl SolarxyApp {
    /// The pane under a point, its camera, and a world ray through it. Exactly
    /// the recipe `pick` uses, so the gizmo grabs what the user sees.
    fn pane_ray(&self, p: (f32, f32)) -> Option<(usize, PaneRect, Camera, Ray)> {
        let rects = self.compute_panes();
        let idx = panes::hit_test_pane(&rects, p);
        let pane = *rects.get(idx)?;
        // A UV pane has no 3D scene to manipulate.
        if self.view.pane_settings[idx].pane_mode == PaneMode::UvMap {
            return None;
        }
        let mut cam = self.view.cameras[idx].as_ref()?.camera;
        cam.aspect = pane.width / pane.height.max(1.0);
        let ray = screen_to_world_ray(
            (p.0 - pane.x, p.1 - pane.y),
            (pane.width, pane.height),
            cam.build_view_projection_matrix(),
        );
        Some((idx, pane, cam, ray))
    }

    /// The manipulator as it stands under a given pointer position: the engine's
    /// target, scaled for that pane. `None` when no gizmo is showing there.
    fn manipulator_at(
        &self,
        p: (f32, f32),
    ) -> Option<(GizmoTarget, ManipulatorState, Camera, Ray, f32)> {
        let target = self.engine.gizmo_target(self.current_ctx)?;
        let (_, pane, cam, ray) = self.pane_ray(p)?;
        let mut state = self
            .gizmo
            .manipulator(&gizmo_pose(&target), cam.forward(), 1.0)?;
        // CSS px, not physical: `GIZMO_PX` and `HIT_PX` are the sizes the USER
        // sees, and pane rects are physical. Divide by the dpr or the gizmo comes
        // out half-size on a retina display (it did).
        let world_per_px = cam.world_per_pixel(state.origin(), pane.height / self.dpr);
        state.scale = manipulator::GIZMO_PX * world_per_px;
        Some((target, state, cam, ray, world_per_px))
    }

    fn update_gizmo_hover(&mut self, p: (f32, f32)) {
        self.gizmo.hovered = self
            .manipulator_at(p)
            .and_then(|(_, state, _, ray, wpp)| gizmo::hit_test(&ray, &state, wpp));
    }

    /// Left press with a tool armed: grab a handle, if one is under the cursor.
    ///
    /// On the APPEND path this mints a transform node before the drag can preview
    /// anything, which is why it happens inside the drag's transaction: the node
    /// and the move then undo together, in one step.
    fn begin_gizmo_drag(&mut self, p: (f32, f32)) -> Result<Option<JsValue>, JsError> {
        let Some((target, state, _, ray, wpp)) = self.manipulator_at(p) else {
            return Ok(None);
        };
        let Some(handle) = gizmo::hit_test(&ray, &state, wpp) else {
            return Ok(None); // a miss falls through to the camera, as before
        };

        let mut events = Vec::new();
        let begin = self
            .engine
            .apply(Command::BeginTransaction {
                label: self.gizmo.tool.undo_label().to_string(),
            })
            .map_err(|e| JsError::new(&format!("{e}")))?;
        events.extend(begin.events);

        // Resolve the real target. On the reuse path this is a no-op that simply
        // reports the tail transform; on the append path it creates one.
        let mut target = target;
        if target.append_pending {
            let GraphContext::Subflow(geo) = target.ctx else {
                return Ok(None);
            };
            let batch = self
                .engine
                .apply(Command::EnsureTransformTarget { geo })
                .map_err(|e| JsError::new(&format!("{e}")))?;
            // The paired event is the ONLY channel carrying the id (the reuse
            // path emits no NodeAdded).
            let node = batch.events.iter().find_map(|ev| match ev {
                EngineEvent::TransformTargetReady { node, .. } => Some(*node),
                _ => None,
            });
            let Some(node) = node else {
                return Ok(None);
            };
            events.extend(batch.events);

            // Re-resolve against the node the engine just minted: a fresh
            // transform is at identity, and reading its real params beats
            // hand-patching the struct field by field (which is how the old code
            // did it, and how it would have quietly kept a stale rotate).
            let Some(fresh) = self.engine.gizmo_target(target.ctx) else {
                return Ok(None);
            };
            debug_assert_eq!(fresh.node, node, "the engine minted a different node");
            target = fresh;
        }

        let Some(drag) =
            gizmo::begin_drag(&ray, &state, gizmo_pose(&target), handle, self.gizmo.tool)
        else {
            return Ok(None);
        };
        self.gizmo.drag = Some(drag);
        self.gizmo_addr = Some(GizmoAddr {
            ctx: target.ctx,
            node: target.node,
        });
        self.gizmo.hovered = Some(handle);

        let revision = self.engine.revision();
        Ok(Some(to_js(&EventBatch { revision, events })?))
    }

    /// End the in-flight drag, yielding both halves at once.
    ///
    /// The only way a drag ends. Taking the pose and the address together is
    /// what keeps them from drifting into a drag that has a solved value and
    /// nowhere to write it.
    fn take_gizmo_drag(&mut self) -> Option<(gizmo::Drag, GizmoAddr)> {
        let drag = self.gizmo.drag.take()?;
        let addr = self.gizmo_addr.take()?;
        Some((drag, addr))
    }

    /// The manipulator as the LIVE drag sees it: rebuilt at the drag's stored
    /// anchor, not at a freshly resolved target.
    ///
    /// That distinction is load-bearing. Re-resolving mid-drag would move the
    /// gizmo's own origin under the maths (the object is moving, after all), and
    /// the object would accelerate away from the cursor.
    fn drag_state(&self, drag: &gizmo::Drag, p: (f32, f32)) -> Option<(ManipulatorState, Ray)> {
        let (_, pane, cam, ray) = self.pane_ray(p)?;
        let tool = self.gizmo.tool.manipulator_tool()?;
        let mut state = self.gizmo.manipulator(&drag.target, cam.forward(), 1.0)?;
        state.tool = tool;
        state.active = Some(drag.handle);
        state.scale =
            manipulator::GIZMO_PX * cam.world_per_pixel(state.origin(), pane.height / self.dpr);
        Some((state, ray))
    }

    /// Pointer move during a drag: solve, and stream into the preview lane. No
    /// document write, no undo entry, no event, no JS traffic.
    fn update_gizmo_drag(&mut self, p: (f32, f32), mods: u8) {
        let Some(mut drag) = self.gizmo.drag else {
            return;
        };
        let Some((state, ray)) = self.drag_state(&drag, p) else {
            return;
        };

        let settings = self.gizmo.settings;
        let Some((value, wrap)) = gizmo::solve_drag(&ray, &state, &drag, &settings, mods) else {
            return; // degenerate view angle: hold still rather than jump
        };

        // The rotate solve accumulates across the +/- pi seam, so its wrap state
        // has to ride back onto the drag or a sweep past 180 degrees would snap
        // back the other way.
        if let Some((last_raw, turns)) = wrap
            && let gizmo::DragGrab::Rotate {
                axis, start_vec, ..
            } = drag.grab
        {
            drag.grab = gizmo::DragGrab::Rotate {
                axis,
                start_vec,
                last_raw,
                turns,
            };
        }
        self.gizmo.drag = Some(drag);
        self.gizmo_readout = value.readout(drag.start);

        if let Some(addr) = self.gizmo_addr {
            for (key, source) in drag_writes(value, &drag.target.params) {
                self.engine.preview_param(addr.ctx, addr.node, key, source);
            }
        }
    }

    /// Release: commit the dragged value as authoritative `SetParam`s inside
    /// the open transaction, then close it. That is the whole "one undo step
    /// per drag" contract -- the transaction is what makes it one step, and
    /// each `SetParam` also clears its own preview.
    ///
    /// Plural because a target sized by two edge lengths writes both when its
    /// size is dragged; everything else writes one.
    fn commit_gizmo_drag(&mut self) -> Result<JsValue, JsError> {
        let Some((drag, addr)) = self.take_gizmo_drag() else {
            return Ok(JsValue::NULL);
        };
        self.gizmo_readout = None;
        let mut events = Vec::new();

        // Whatever the preview lane last resolved to IS the final value. Asked
        // through the drag's own `DragParam`, so the commit cannot read a
        // different param than the drag wrote.
        let final_value = self
            .engine
            .gizmo_target(addr.ctx)
            .map_or(drag.start, |t| drag.param.read(&gizmo_pose(&t)));

        // A click on a handle that never moved is not an edit. Committing it
        // would push an undo step that visibly does nothing (and, on the append
        // path, would leave a transform node behind for a click). Roll it back
        // instead, which is exactly what Escape does.
        if !final_value.differs_from(drag.start) {
            return self.rollback_gizmo_drag(&drag, addr);
        }

        for (key, value) in drag_writes(final_value, &drag.target.params) {
            let set = self
                .engine
                .apply(Command::SetParam {
                    ctx: addr.ctx,
                    node: addr.node,
                    key: key.to_string(),
                    value,
                })
                .map_err(|e| JsError::new(&format!("{e}")))?;
            events.extend(set.events);
        }

        let end = self
            .engine
            .apply(Command::EndTransaction)
            .map_err(|e| JsError::new(&format!("{e}")))?;
        events.extend(end.events);

        let revision = self.engine.revision();
        to_js(&EventBatch { revision, events })
    }

    /// Unwinds a drag without committing: the document returns to where the drag
    /// started and the object snaps back.
    ///
    /// Two halves, and BOTH are needed. The transaction rollback undoes the
    /// document (an appended transform node); clearing the preview releases the
    /// transient value the drag was streaming. Skip the second and the viewport
    /// would keep asserting the dragged pose forever, disagreeing with the
    /// parameter panel. The keys come from the drag's own `DragParam` resolved
    /// against its own target, so a rotate cancel can never clear a translate
    /// and a two-edge cancel cannot leave one of them stranded.
    fn rollback_gizmo_drag(
        &mut self,
        drag: &gizmo::Drag,
        addr: GizmoAddr,
    ) -> Result<JsValue, JsError> {
        self.gizmo_readout = None;
        if let Some(keys) = drag.param.keys(&drag.target.params) {
            for key in keys.iter() {
                self.engine.clear_preview(addr.ctx, addr.node, key);
            }
        }
        let batch = self
            .engine
            .apply(Command::CancelTransaction)
            .map_err(|e| JsError::new(&format!("{e}")))?;
        to_js(&batch)
    }
}

// Internal orchestration: the web port of the desktop per-pane render loop.
impl SolarxyApp {
    /// The still the render node's settings describe, as this shell renders it.
    fn still_spec(
        &self,
        opts: &solarxy_graph::nodes::RenderSettings,
        engine: solarxy_host::still::StillEngine,
        readback: solarxy_host::still::StillReadback,
    ) -> solarxy_host::still::StillSpec {
        solarxy_host::still::StillSpec {
            width: opts.width,
            height: opts.height,
            engine,
            samples: opts.samples,
            // Bloom is the only screen-space pass a still keeps; ambient
            // occlusion is off for traced output and a raster still inherits
            // whatever the viewport had.
            screen_space_post: self.renderer.post.bloom_enabled,
            tile_budget: solarxy_host::still::TILE_BUDGET_PIXELS,
            // Chosen in the dialog before the render starts, because the
            // readback decides what the tiles are and cannot be changed once
            // they are arriving.
            readback,
            // Albedo and normal come out of one store, so either of them asks
            // for the same copy. Derived exactly the way the headless command
            // derives them, so a scene renders the same passes wherever it is
            // opened.
            aux: opts.aov_albedo || opts.aov_normal,
            depth: opts.aov_depth,
            // The dialog is watching. At the production tile budget a 1920 by
            // 1080 render is a single tile, so without this nothing reaches the
            // canvas until the whole image is finished.
            preview_interval_ms: solarxy_host::still::PREVIEW_INTERVAL_MS,
            transparent: opts.transparent_background,
        }
    }

    fn compute_panes(&self) -> Vec<PaneRect> {
        panes::compute_panes(
            self.view.display.layout,
            self.view.display.split_ratio,
            (0.0, 0.0),
            (self.config.width as f32, self.config.height as f32),
        )
    }

    fn pane_rects_css(&self) -> Vec<RectDto> {
        self.compute_panes()
            .iter()
            .map(|p| RectDto {
                x: p.x / self.dpr,
                y: p.y / self.dpr,
                width: p.width / self.dpr,
                height: p.height / self.dpr,
            })
            .collect()
    }

    fn push_pane_rects_if_changed(&mut self, _physical: &[PaneRect]) {
        let css = self.pane_rects_css();
        if css != self.last_pane_rects {
            self.last_pane_rects.clone_from(&css);
            self.host_events.push(HostEvent::PaneRects { rects: css });
        }
    }

    /// The desktop `rebuild_light_bind_group` chokepoint, ported: retargets
    /// the skybox at the active IBL's equirect, rebuilds the light bind
    /// group per the IBL mode (full / diffuse-only / fallback), and pushes
    /// the IBL-derived ambient average so clay modes update instantly.
    fn rebuild_light_bind_group(&mut self) {
        solarxy_host::rebuild_light_bind_group(
            &self.device,
            &self.queue,
            &mut self.renderer,
            &mut self.env,
            self.view.display.hdri_intensity,
        );
    }

    /// Keep a watched tracer in step with the frame: the scene delta, the
    /// environment scalars, and any host-side view mutation each reset the
    /// accumulation, which is the preview's whole reset contract (camera
    /// moves are per pane and handled at encode). Does nothing while no
    /// pane is traced, so a session that never traces pays one boolean.
    fn feed_traced_preview(&mut self, delta: &solarxy_core::scene::SceneDelta) {
        let any_traced = self
            .view
            .pane_settings
            .iter()
            .any(|p| p.pane_mode == PaneMode::Scene3D && p.pane_engine == PaneEngine::Traced);
        if !any_traced || self.tracer.is_none() {
            return;
        }
        if !delta.ops.is_empty()
            && let Some(t) = self.tracer.as_mut()
        {
            // The same feed the raster gets: the delta lands and every
            // accumulation resets, since the mean was of another scene.
            // The camera keys reset with it so each pane re-anchors its
            // pose on its next encode.
            t.apply(&self.device, &self.queue, delta);
            t.invalidate();
            self.traced_cam_keys = [None; 4];
        }
        let env_params = (
            self.view.display.hdri_intensity,
            self.view.display.hdri_rotation,
        );
        // Not while a still is running: the job owns the shared backend,
        // including its environment, and a pane install here would swap a
        // still's sky out from under it and reset the mean it has been
        // accumulating. Leaving the flag set is what records that the install
        // is owed once the job lets go.
        if self.still.is_none() && (self.traced_env_dirty || env_params != self.traced_env_params) {
            self.sync_traced_environment();
            self.traced_env_params = env_params;
            if let Some(t) = self.tracer.as_mut() {
                t.invalidate();
                self.traced_cam_keys = [None; 4];
            }
        }
        if self
            .host_events
            .iter()
            .any(|e| matches!(e, HostEvent::ViewChanged))
            && let Some(t) = self.tracer.as_mut()
        {
            t.invalidate();
            self.traced_cam_keys = [None; 4];
        }
    }

    /// One traced pane's pre-encode housekeeping: assert the preview's
    /// settings, reset the accumulation when the pane's camera moved, and
    /// re-apply the viewer rig.
    fn prepare_traced_pane(&mut self, i: usize) {
        // Asserted per encode rather than held, because the still job
        // authors its own settings on the same backend and whichever ran
        // last would otherwise win.
        if let Some(t) = self.tracer.as_mut() {
            t.set_settings(preview_trace_settings(self.preview_denoise));
            // The filter's steering, for the same reason and it is newly load
            // bearing: a still authored from a render node now writes these
            // four, so without this a preview would inherit whatever the last
            // still asked for. The preview keeps the measured defaults, which
            // is what it ran at when nothing called this setter at all. The
            // two denoise settings are deliberately separate: one is a
            // delivered frame's, the other a preview's, and they want
            // different answers.
            t.set_denoise_settings(DenoiseSettings::default());
        }
        // A pane bound to a camera previews through that camera's lens; a
        // free view is a pinhole. Asserted per encode like the settings above
        // and for the same reason: the still job authors its own on the same
        // backend, so whichever ran last would otherwise win. `set_lens` is a
        // no-op when nothing moved, which is what lets a pane keep converging.
        let pane_lens = self
            .pane_camera_def(i)
            .map(solarxy_host::cameras::lens_for)
            .unwrap_or_default();
        if let Some(t) = self.tracer.as_mut() {
            t.set_lens(pane_lens);
        }
        let Some(cam) = self.view.cameras.get(i).and_then(Option::as_ref) else {
            return;
        };
        let key = camera_key(&cam.camera);
        if self.traced_cam_keys.get(i).copied().flatten() != Some(key) {
            if let Some(t) = self.tracer.as_mut() {
                t.invalidate_pane(i);
            }
            if let Some(slot) = self.traced_cam_keys.get_mut(i) {
                *slot = Some(key);
            }
        }
        // The viewer rig is re-applied every traced frame, not only on
        // reset: it is scene data shared by every pane, and with two
        // traced panes the last writer would otherwise win across frames.
        // A no-op under authored lights, and a constant write while the
        // camera rests, so it never disturbs a converging mean.
        let camera = cam.camera;
        if let Some(t) = self.tracer.as_mut() {
            solarxy_host::apply_viewer_rig(
                &self.device,
                &self.queue,
                t,
                self.raster.scene(),
                &camera,
            );
        }
    }

    /// Push a traced pane's sample counter, on change rather than per
    /// frame. A `Complete` outcome is a converged pane: the count parks
    /// at the target instead of vanishing.
    fn push_pane_samples(&mut self, i: usize, outcome: FrameOutcome) {
        let counts = match outcome {
            FrameOutcome::Converging {
                samples,
                target_samples,
            } => Some((samples, target_samples)),
            FrameOutcome::Complete => self
                .last_pane_samples
                .get(i)
                .copied()
                .flatten()
                .map(|(_, target)| (target, target)),
        };
        if counts.is_some()
            && let Some(slot) = self.last_pane_samples.get_mut(i)
            && *slot != counts
        {
            *slot = counts;
            if let Some((samples, target)) = counts {
                self.host_events.push(HostEvent::PaneSamples {
                    pane: i,
                    samples,
                    target,
                });
            }
        }
    }

    /// Brings a traced pane's environment up to date with the scene's, which
    /// is what makes a traced pane light the way the raster pane beside it
    /// does.
    ///
    /// The traced scene cache deliberately drops the environment op, on the
    /// reasoning that a host already holds the decoded and convolved image and
    /// should build the traced environment from that rather than keep a second
    /// copy of the largest asset in a scene. This is the host half of that
    /// decision. Without it the kernel integrates against its own constant sky
    /// and an image lit by a sunset renders as though lit by a dim room.
    ///
    /// A still does not come through here. See `install_still_environment`
    /// for what it installs instead, and why a pane and a still are allowed
    /// to disagree about this one thing.
    fn sync_traced_environment(&mut self) {
        if self.tracer.is_none() {
            return;
        }
        if !std::mem::take(&mut self.traced_env_dirty) {
            let intensity = self.view.display.hdri_intensity;
            let rotation = self.view.display.hdri_rotation;
            if let Some(tracer) = self.tracer.as_mut() {
                tracer.set_environment_params(intensity, rotation);
            }
            return;
        }
        // Resolved before the tracer is borrowed, because resolving reads the
        // whole host and the tracer is a field of it.
        //
        // Where the scene authors no image, a pane falls back to the same
        // background the raster path resolves, so a traced pane and the raster
        // pane beside it agree by construction rather than by coincidence.
        let sky = self
            .resolve_background(&self.view.pane_settings[0])
            .sky_colors();
        self.install_traced_environment(sky);
    }

    /// The environment a still integrates against, installed at the moment the
    /// render starts.
    ///
    /// Where the scene authors an image this is the pane path's answer. Where
    /// it authors none, a still gets no environment at all rather than the
    /// background a pane happens to be showing: a render is a property of the
    /// scene and a viewport background is a viewing preference, so a document
    /// declaring itself lit by nothing but its own lights renders that way. It
    /// is also the only way this shell and the terminal can agree, the
    /// terminal having no panes to borrow a background from.
    ///
    /// Black rather than merely dim: the kernel excludes an all-zero sky from
    /// the direct-lighting estimator's choice entirely, so the draws that were
    /// going to a sky occluded from nearly every point inside a closed room go
    /// to the lights that are really there instead.
    ///
    /// Installed unconditionally, because the dirty flag is the pane path's
    /// cache over an image rebuild and a still has to overwrite whatever sky
    /// the panes last left on the shared backend even when nothing is dirty.
    fn install_still_environment(&mut self) {
        self.install_traced_environment(([0.0; 3], [0.0; 3]));
    }

    /// Builds the traced environment from the scene's image and hands it to
    /// the tracer, falling back to the given constant sky where the scene
    /// authors no image.
    ///
    /// Nothing here uploads the image. The equirect the sky pass retains and
    /// the equirect the kernel walks are the same texture in the same format,
    /// so the view is shared and only the two distribution tables are built,
    /// from the distribution both HDRI routes already compute.
    fn install_traced_environment(&mut self, sky: ([f32; 3], [f32; 3])) {
        let intensity = self.view.display.hdri_intensity;
        let rotation = self.view.display.hdri_rotation;
        let ibl = &self.renderer.ibl_res.ibl;
        let built = match (ibl.equirect.as_ref(), ibl.distribution.as_ref()) {
            (Some(equirect), Some(distribution)) => Some(
                solarxy_renderer::pathtrace::environment::TraceEnvironment::from_shared_equirect(
                    &self.device,
                    &self.queue,
                    &equirect.view,
                    distribution,
                ),
            ),
            _ => None,
        };
        let Some(tracer) = self.tracer.as_mut() else {
            return;
        };
        match built {
            Some(environment) => {
                tracer.set_environment(&self.device, environment, intensity, rotation);
            }
            None => tracer.set_sky(sky.0, sky.1),
        }
    }

    /// Apply any `SceneOp::SetEnvironment` in the frame's delta.
    ///
    /// Separate from `SceneObjects::apply` because the environment is the
    /// IBL and the skybox, which that type cannot reach. The desktop shell
    /// runs the same tracker over the same op.
    fn apply_scene_environment(&mut self, delta: &solarxy_core::scene::SceneDelta) {
        use solarxy_core::scene::{BackgroundKind, SceneOp};
        use solarxy_renderer::environment::EnvironmentOutcome;

        for op in &delta.ops {
            let SceneOp::SetEnvironment {
                hdri,
                rotation,
                intensity,
                background,
            } = op
            else {
                continue;
            };

            // Rotation and intensity write through to the display settings
            // the Environment modal's sliders read, so the node and the
            // sliders show one value rather than fighting over two.
            self.view.display.hdri_rotation = *rotation;
            self.view.display.hdri_intensity = *intensity;

            let outcome = self.environment.apply(
                &self.device,
                &self.queue,
                &mut self.renderer.ibl_res,
                hdri.as_ref(),
            );
            match outcome {
                // Still rebuild: rotation or intensity may have moved even
                // when the HDRI did not.
                EnvironmentOutcome::Unchanged => {}
                EnvironmentOutcome::HdriInstalled => {
                    self.traced_env_dirty = true;
                    if *background == BackgroundKind::HdriSky {
                        self.view.pane_settings[0].background_mode =
                            solarxy_core::preferences::BackgroundMode::HDRI_SKY;
                    }
                }
                // "No environment" is not "a black environment": fall back
                // to the procedural sky, exactly as `clear_environment`
                // does for the host-driven route.
                EnvironmentOutcome::Cleared => {
                    let (top, bottom) = self
                        .resolve_background(&self.view.pane_settings[0])
                        .sky_colors();
                    self.renderer.ibl_res.ibl = solarxy_renderer::ibl::IblState::from_sky_colors(
                        &self.device,
                        &self.queue,
                        top,
                        bottom,
                    );
                    self.traced_env_dirty = true;
                }
            }
            self.rebuild_light_bind_group();
            self.host_events.push(HostEvent::ViewChanged);
        }
    }

    /// The `.slxy` environment section from the host state. The scene-wide
    /// HDRI rotation rides the free-form `background` object (the global
    /// `DisplaySettings` is otherwise host-session state).
    fn environment_json(&self) -> solarxy_scenefile::EnvironmentJson {
        let mut background = std::collections::BTreeMap::new();
        background.insert(
            "hdriRotation".to_string(),
            serde_json::json!(self.view.display.hdri_rotation),
        );
        solarxy_scenefile::EnvironmentJson {
            ibl_mode: match self.renderer.ibl_res.ibl_mode {
                IblMode::Off => "off",
                IblMode::Diffuse => "diffuse",
                IblMode::Full => "full",
            }
            .to_string(),
            hdri_asset: self.hdri.as_ref().map(|h| h.hash.clone()),
            background,
        }
    }

    /// The scene's visible bounds, or the placeholder before anything cooks.
    fn scene_bounds(&self) -> AABB {
        self.raster
            .scene()
            .visible_bounds()
            .unwrap_or(self.env_bounds)
    }

    /// What "frame the selection" should put the camera around, or `None` when
    /// the selection has no place in the world.
    ///
    /// Two kinds of answer, because there are two kinds of thing to frame. An
    /// object has real bounds. A light has a position and no size at all, so
    /// it gets a box scaled to the scene: framing a point would put the camera
    /// arbitrarily close to it, and a fraction of the scene is the only
    /// measure available that means anything.
    fn selection_bounds(&self) -> Option<AABB> {
        let id = self.selected_object?;
        if let Some(b) = self.raster.scene().object_world_bounds(id) {
            return Some(b);
        }
        // Not an object, so it may be a light. Its marker anchor rather than
        // its raw position, so framing an ambient or hemisphere light goes
        // where its marker is drawn rather than where it is not.
        let light = self
            .raster
            .scene()
            .lights()?
            .iter()
            .find(|l| l.id == id && l.visible)?;
        let at = solarxy_renderer::helpers::marker_anchor(light);
        let half = (self.scene_bounds().diagonal() * 0.05).max(0.25);
        Some(AABB {
            min: cgmath::Point3::new(at.x - half, at.y - half, at.z - half),
            max: cgmath::Point3::new(at.x + half, at.y + half, at.z + half),
        })
    }

    /// Keeps the UV pane's source current: the selected node's committed
    /// geometry (uploaded into the one-object preview scene, deduped by
    /// `Arc` identity), else the selected / first scene object. A source
    /// change invalidates the overlap statistic.
    fn sync_uv_preview(&mut self) {
        if !self
            .view
            .pane_settings
            .iter()
            .any(|p| p.pane_mode == PaneMode::UvMap)
        {
            return;
        }
        let source = self
            .engine
            .selected_geometry(self.current_ctx)
            .map(|(node, set)| {
                (
                    node.0,
                    std::sync::Arc::as_ptr(set).cast::<()>() as usize,
                    std::sync::Arc::clone(set),
                )
            });
        self.uv_use_preview = source.is_some();
        let identity = match &source {
            Some((node, addr, _)) => Some((*node, *addr)),
            None => self
                .selected_object
                .or_else(|| self.raster.scene().iter().next().map(|(id, _)| *id))
                .map(|id| (id.0, 0)),
        };
        if identity != self.last_uv_source {
            self.last_uv_source = identity;
            if self.view.pane_settings.iter().any(|p| p.show_uv_overlap) {
                self.renderer.uv_overlap.overlap_pct = None;
                self.renderer.uv_overlap.stats_dirty = true;
            }
        }
        if let Some((_, _, set)) = source {
            let mut delta = SceneDelta::default();
            delta.push(SceneOp::UpsertGeometry {
                id: UV_PREVIEW_ID,
                geometry: std::sync::Arc::new(set.to_cooked()),
            });
            if let Err(e) =
                self.uv_scene
                    .apply(&self.device, &self.queue, &self.renderer.layouts, &delta)
            {
                error(&format!("uv preview upload failed: {e}"));
            }
        }
    }

    fn resolve_background(&self, pds: &PaneDisplaySettings) -> ResolvedBackground {
        // The web has no user custom-background registry yet.
        pds.background_mode.resolve(&[])
    }

    /// Rebuilds the bounds-derived environment (grid/floor scale, shadow
    /// frustum, light-rig fit) when the scene bounds move materially.
    /// Whether any active-layout 3D pane wants the per-mesh visualization
    /// overlays (normal arrows, per-mesh bounds boxes).
    fn viz_overlays_wanted(&self) -> bool {
        use solarxy_core::preferences::{NormalsMode, PaneMode};
        use solarxy_core::view_config::BoundsMode;
        let count = self.view.display.layout.pane_count();
        self.view.pane_settings[..count].iter().any(|pds| {
            pds.pane_mode != PaneMode::UvMap
                && (pds.normals_mode != NormalsMode::Off || pds.bounds_mode == BoundsMode::PerMesh)
        })
    }

    /// Rebuilds `env.vis` from every displayed geometry when the aggregate
    /// is stale and a pane actually shows it: world-baked normal lines
    /// (positions via the object matrix, directions via its
    /// inverse-transpose) and per-mesh world AABBs, flattened in draw order
    /// (the renderer zips segments against the flattened scene meshes).
    /// Lights/shadow are untouched -- only the visualization member swaps.
    fn sync_visualization(&mut self) {
        if !self.viz_dirty || !self.viz_overlays_wanted() {
            return;
        }
        let Some(bounds) = self.raster.scene().visible_bounds() else {
            return;
        };
        self.viz_dirty = false;
        let (mesh_bounds, normals) = self.build_viz_aggregate();
        let grid_color = self
            .resolve_background(&self.view.pane_settings[0])
            .grid_color();
        self.env.vis = VisualizationState::new_from_parts(
            &self.device,
            &self.renderer.layouts,
            &bounds,
            &mesh_bounds,
            Some(&normals),
            grid_color,
        );
        // The rebuilt state's attr channel is empty; refill it.
        self.attr_dirty = true;
    }

    /// Rebuilds (or clears) BOTH attribute channels (vector lines and GPU
    /// labels) when they are stale, then reports the sampling facts. One
    /// consumer of `attr_dirty` by construction: splitting the channels
    /// over two consumers would starve whichever ran second. Independent of
    /// `sync_visualization`: the overlays draw whenever the strip enables
    /// them, with or without the normals/bounds overlays.
    fn sync_attr_channels(&mut self) {
        if !self.attr_dirty {
            return;
        }
        self.attr_dirty = false;

        if self.attr_viz.vectors && self.attr_viz.name.is_some() {
            let lines = self.build_attr_vector_lines();
            self.env.vis.set_attr_lines(&self.device, &lines);
        } else if self.env.vis.attr_lines_count > 0 {
            self.env.vis.set_attr_lines(&self.device, &[]);
        }

        let (capacity, total) = self.rebuild_attr_labels();
        self.host_events.push(HostEvent::AttrPinStats {
            capacity,
            total: total as f64,
        });
    }

    /// Rebuilds the GPU label set from a deterministic stride sample of
    /// every displayed geometry's points (all of them up to the budget):
    /// world-space anchors plus per-label glyph words, uploaded once here
    /// and projected in the vertex shader thereafter. Returns
    /// `(capacity, total displayed points)` for the sampling notice.
    fn rebuild_attr_labels(&mut self) -> (u32, usize) {
        use cgmath::{Matrix4, Transform};
        if !self.attr_viz.pins_wanted() {
            self.renderer
                .set_attr_labels(&self.device, &self.queue, &[], &[]);
            return (0, 0);
        }
        let lane = self
            .attr_viz
            .name
            .as_deref()
            .filter(|_| self.attr_viz.labels);
        let geos = self.engine.display_geometries();
        let total: usize = geos
            .iter()
            .flat_map(|(_, set, _)| set.meshes.iter())
            .map(solarxy_kernel::KernelMesh::vertex_count)
            .sum();
        if total == 0 {
            self.renderer
                .set_attr_labels(&self.device, &self.queue, &[], &[]);
            return (0, 0);
        }
        let cap = self.attr_viz.effective_cap(total);
        let stride = total.div_ceil(cap).max(1);

        let mut candidates: Vec<solarxy_host::attr_labels::LabelCandidate> =
            Vec::with_capacity(cap);
        let mut global = 0usize;
        for (_node, set, m) in &geos {
            let matrix = Matrix4::from(*m);
            let mut ptnum: u64 = 0;
            for mesh in &set.meshes {
                let len = mesh.vertex_count();
                let values =
                    lane.and_then(|n| solarxy_graph::engine::attr_table::resolve_lane(mesh, n));
                let first = global.next_multiple_of(stride);
                let mut g = first;
                while g < global + len {
                    let i = g - global;
                    let tp = matrix.transform_point(Point3::from(mesh.positions[i]));
                    candidates.push(solarxy_host::attr_labels::LabelCandidate {
                        world: [tp.x, tp.y, tp.z],
                        ptnum: ptnum + i as u64,
                        value: values.map(|l| l.components(i).unwrap_or_default()),
                    });
                    g += stride;
                }
                ptnum += len as u64;
                global += len;
            }
        }
        let (instances, words) = solarxy_host::attr_labels::build_labels(
            &candidates,
            self.attr_viz.labels,
            self.attr_viz.points,
            self.attr_viz.label_decimals,
        );
        self.renderer
            .set_attr_labels(&self.device, &self.queue, &instances, &words);
        (cap as u32, total)
    }

    /// World-space arrow segments for the picked point lane (vec3, or the
    /// xyz of vec4; map lane or the fixed `N` buffer), over
    /// every displayed geometry: positions through the object matrix,
    /// directions through the normal matrix for the reserved `N` lane
    /// (bivector semantics under nonuniform scale) and the plain linear
    /// part for everything else. Length is the bounds-derived factor
    /// times the strip's scale multiplier, over the value (or its unit
    /// direction under normalize); color is the uniform pick, or the
    /// cold-to-warm ramp over this frame's magnitude range.
    fn build_attr_vector_lines(&self) -> Vec<GizmoVertex> {
        use cgmath::{InnerSpace, Matrix3, Matrix4, SquareMatrix, Transform};
        let Some(name) = self.attr_viz.name.as_deref() else {
            return Vec::new();
        };
        let is_normal_lane = name == solarxy_kernel::reserved::NORMAL;
        let multiplier = self.attr_viz.scale_multiplier();
        let normalize = self.attr_viz.normalize;

        // First pass: world-space segments plus each arrow's magnitude
        // (pre-normalization), so the ramp can span the real range.
        let mut segments: Vec<([f32; 3], [f32; 3], f32)> = Vec::new();
        for (_node, set, m) in self.engine.display_geometries() {
            let matrix = Matrix4::from(m);
            let linear = Matrix3::from_cols(
                matrix.x.truncate(),
                matrix.y.truncate(),
                matrix.z.truncate(),
            );
            let dir_matrix = if is_normal_lane {
                linear
                    .invert()
                    .map_or(linear, |inv| cgmath::Matrix::transpose(&inv))
            } else {
                linear
            };
            let scale = {
                let d = set.bounds.diagonal();
                if d > 1e-10 { d * 0.05 } else { 0.1 }
            } * multiplier;
            for mesh in &set.meshes {
                // Vec3 and vec4 (xyz) lanes draw, map or fixed-buffer N;
                // float/vec2 lanes have no spatial reading and skip.
                let Some(lane) = solarxy_graph::engine::attr_table::resolve_lane(mesh, name) else {
                    continue;
                };
                for (i, p) in mesh.positions.iter().enumerate() {
                    let Some(v) = lane.direction(i) else { continue };
                    let tp = matrix.transform_point(Point3::from(*p));
                    let mut dir = dir_matrix * Vector3::from(v);
                    let magnitude = dir.magnitude();
                    if normalize {
                        if magnitude <= 1e-10 {
                            continue;
                        }
                        dir /= magnitude;
                    }
                    segments.push((
                        [tp.x, tp.y, tp.z],
                        [
                            tp.x + dir.x * scale,
                            tp.y + dir.y * scale,
                            tp.z + dir.z * scale,
                        ],
                        magnitude,
                    ));
                }
            }
        }

        // Second pass: colors. Flat per arrow (both vertices alike) so
        // direction stays readable under the ramp.
        let color_for: Box<dyn Fn(f32) -> [f32; 3]> = match self.attr_viz.color_mode {
            AttrColorMode::Uniform => {
                let c = self.attr_viz.color;
                Box::new(move |_| c)
            }
            AttrColorMode::Ramp => {
                let (min, max) = segments
                    .iter()
                    .fold((f32::INFINITY, f32::NEG_INFINITY), |(lo, hi), (_, _, m)| {
                        (lo.min(*m), hi.max(*m))
                    });
                if max - min <= 1e-10 {
                    // A degenerate range has nothing to rank; fall back
                    // to the uniform color.
                    let c = self.attr_viz.color;
                    Box::new(move |_| c)
                } else {
                    let preset = self.attr_viz.ramp_preset;
                    Box::new(move |m: f32| {
                        let t = ((m - min) / (max - min)).clamp(0.0, 1.0);
                        ramp_color(preset, t)
                    })
                }
            }
        };
        segments
            .into_iter()
            .flat_map(|(a, b, magnitude)| {
                let color = color_for(magnitude);
                [
                    GizmoVertex { position: a, color },
                    GizmoVertex { position: b, color },
                ]
            })
            .collect()
    }

    /// The world-space visualization aggregate over
    /// `Engine::display_geometries` (ascending geo id = the renderer's
    /// draw order).
    fn build_viz_aggregate(&self) -> (Vec<AABB>, NormalsGeometry) {
        use cgmath::{Matrix3, Matrix4, SquareMatrix, Transform};
        let mut mesh_bounds: Vec<AABB> = Vec::new();
        let mut agg = NormalsGeometry {
            vertex_lines: Vec::new(),
            face_lines: Vec::new(),
            vertex_segments: Vec::new(),
            face_segments: Vec::new(),
        };
        for (_node, set, m) in self.engine.display_geometries() {
            let matrix = Matrix4::from(m);
            // Normal matrix: inverse-transpose of the upper 3x3 (the geo
            // transform allows nonuniform scale).
            let normal_matrix = Matrix3::from_cols(
                matrix.x.truncate(),
                matrix.y.truncate(),
                matrix.z.truncate(),
            )
            .invert()
            .map(|inv| cgmath::Matrix::transpose(&inv));
            for mesh in &set.meshes {
                let world: Vec<[f32; 3]> = mesh
                    .positions
                    .iter()
                    .map(|p| {
                        let tp = matrix.transform_point(Point3::from(*p));
                        [tp.x, tp.y, tp.z]
                    })
                    .collect();
                let bounds = compute_bounds(&world);
                let world_normals: Vec<[f32; 3]> = match (&mesh.normals, normal_matrix) {
                    (Some(ns), Some(nm)) => ns
                        .iter()
                        .map(|n| {
                            let v = nm * Vector3::from(*n);
                            let v = if v.magnitude2() > 1e-12 {
                                v.normalize()
                            } else {
                                v
                            };
                            [v.x, v.y, v.z]
                        })
                        .collect(),
                    // A singular matrix (zero scale) has no usable normal
                    // transform; fall back to object-space directions.
                    (Some(ns), None) => ns.to_vec(),
                    // No stored normals: vertex arrows are empty, face
                    // arrows still derive from the world positions.
                    (None, _) => Vec::new(),
                };
                let (v_lines, f_lines) =
                    build_normals_geometry(&world, &world_normals, &mesh.indices, &bounds);
                let v_start = agg.vertex_lines.len() as u32;
                agg.vertex_lines.extend(v_lines);
                agg.vertex_segments
                    .push(v_start..agg.vertex_lines.len() as u32);
                let f_start = agg.face_lines.len() as u32;
                agg.face_lines.extend(f_lines);
                agg.face_segments.push(f_start..agg.face_lines.len() as u32);
                mesh_bounds.push(bounds);
            }
        }
        (mesh_bounds, agg)
    }

    fn sync_env_bounds(&mut self) {
        // Keep the ground environment (grid, floor, shadow frustum) world-fixed
        // during interactive edits. A subflow gizmo drag writes a `transform`
        // node that BAKES into the cooked points, so the visible bounds churn
        // every frame; refitting here would rescale/slide the grid and floor
        // under the gizmo. Any interaction streams through the preview lane, so
        // we skip the refit while a preview is in flight and let it settle once
        // when the edit commits (the preview clears on the authoritative write).
        if self.engine.has_active_previews() {
            return;
        }
        // The same reasoning one guard up, for the scene clock. An animated
        // scene bakes new point positions every frame, so the visible bounds
        // churn continuously and refitting here would make the grid, floor
        // and shadow frustum breathe in time with the animation. The world is
        // not something playback is allowed to rescale. Playback stopping
        // needs no bookkeeping: `frame()` calls this unconditionally, so the
        // first non-playing tick settles the environment once.
        if self.engine.clock().playing {
            return;
        }
        let Some(bounds) = self.raster.scene().visible_bounds() else {
            return;
        };
        let eps = (self.env_bounds.diagonal() * 1e-3).max(1e-6);
        let close = |a: Point3<f32>, b: Point3<f32>| {
            (a.x - b.x).abs() < eps && (a.y - b.y).abs() < eps && (a.z - b.z).abs() < eps
        };
        if close(bounds.min, self.env_bounds.min) && close(bounds.max, self.env_bounds.max) {
            return;
        }
        let grid_color = self
            .resolve_background(&self.view.pane_settings[0])
            .grid_color();
        let vis = VisualizationState::new_from_parts(
            &self.device,
            &self.renderer.layouts,
            &bounds,
            &[],
            None,
            grid_color,
        );
        let aspect = self.renderer.target_width as f32 / self.renderer.target_height.max(1) as f32;
        let mut env = SceneEnvironment::new(
            &self.device,
            &self.queue,
            &self.renderer.layouts,
            &bounds,
            aspect,
            &self.renderer.ibl_res.brdf_lut,
            &self.renderer.ibl_res.ltc,
            SHADOW_MAP_SIZE,
            vis,
        );
        env.light_bind_group = create_light_bind_group(
            &self.device,
            &self.renderer.layouts,
            &env.light_buffer,
            solarxy_host::active_ibl(&self.renderer),
            &self.renderer.ibl_res.brdf_lut,
            &self.renderer.ibl_res.ltc,
        );
        self.env = env;
        self.env_bounds = bounds;
        // The rebuilt environment starts with empty per-mesh viz data; the
        // aggregate refills it when a pane wants overlays (and the attr
        // channel refills on its own dirty pass).
        self.viz_dirty = true;
        self.attr_dirty = true;
    }

    /// Drives each look-through pane's camera from its bound `camera` node, so
    /// param-panel edits (and non-navigating panes) always show the node's
    /// saved pose. Suppressed for a pane mid-navigation (`camera_editing`) so
    /// the follow never fights live orbit/pan on a locked pane.
    fn follow_look_through_cameras(&mut self) {
        // Snapshot the cloned defs first, ending the scene_objects borrow before
        // the pane cameras are mutated.
        let updates: Vec<(usize, solarxy_core::scene::CameraDef)> = {
            let Some(cams) = self.raster.scene().cameras() else {
                return;
            };
            (0..4)
                .filter_map(|i| {
                    let node = self.look_through[i]?;
                    // Suppressed while navigating, or while a turntable spins
                    // this pane's scratch camera.
                    if self.camera_editing[i] || self.view.pane_settings[i].turntable_active {
                        return None;
                    }
                    cams.iter()
                        .find(|c| c.id == SceneObjectId(node.0))
                        .map(|def| (i, def.clone()))
                })
                .collect()
        };
        for (i, def) in updates {
            if let Some(cam) = self.view.cameras[i].as_mut() {
                solarxy_host::cameras::apply_camera_def(&mut cam.camera, &def);
            }
        }
    }

    /// Whether pane `pane` is a locked look-through pane (navigation reframes
    /// its bound camera node).
    fn is_locked_look_through(&self, pane: usize) -> bool {
        pane < 4 && self.look_through[pane].is_some() && self.camera_locked[pane]
    }

    /// Writes a locked look-through pane's current camera pose back to its bound
    /// `camera` node as one undo step, returning the merged event batch so the
    /// frontend mirror reflects the new params (position + target).
    fn commit_pane_camera_to_node(&mut self, pane: usize) -> Option<EventBatch> {
        let node = self.look_through.get(pane).copied().flatten()?;
        let (eye, target) = {
            let cam = self.view.cameras[pane].as_ref()?;
            (cam.camera.eye, cam.camera.target)
        };
        // A press and release with no movement commits nothing. The frontend
        // treats a returned batch as proof the press belonged to a camera
        // gesture and skips the click ladder, so an unconditional commit made
        // every click on a locked look-through pane unpickable and pushed an
        // undo step that changed nothing. Compared against what is on the
        // node now, not a pose cached at press time, so a follow that ran
        // mid-gesture cannot make an unchanged pose look changed; the
        // comparison space is the guard's to explain.
        if let Ok(graph) = self.engine.document().graph(GraphContext::Root)
            && let Some(data) = graph.node(node)
            && crate::camera_commit::pose_unchanged(
                &data.params,
                [eye.x, eye.y, eye.z],
                [target.x, target.y, target.z],
            )
        {
            return None;
        }
        let cmds = [
            Command::BeginTransaction {
                label: "Frame Camera".to_string(),
            },
            Command::SetParam {
                ctx: GraphContext::Root,
                node,
                key: "position".to_string(),
                value: ParamSource::Literal(ParamValue::Vec3([
                    f64::from(eye.x),
                    f64::from(eye.y),
                    f64::from(eye.z),
                ])),
            },
            Command::SetParam {
                ctx: GraphContext::Root,
                node,
                key: "target".to_string(),
                value: ParamSource::Literal(ParamValue::Vec3([
                    f64::from(target.x),
                    f64::from(target.y),
                    f64::from(target.z),
                ])),
            },
            Command::EndTransaction,
        ];
        let mut events = Vec::new();
        let mut revision = self.engine.revision();
        for cmd in cmds {
            if let Ok(batch) = self.engine.apply(cmd) {
                revision = batch.revision;
                events.extend(batch.events);
            }
        }
        Some(EventBatch { revision, events })
    }

    /// Uploads the camera gizmos for pane `i`, hiding the camera the pane is
    /// looking through. Cloned first so the `scene_objects` borrow ends before
    /// the mutable renderer write.
    fn write_pane_camera_helpers(&mut self, i: usize) {
        let skip = self.look_through[i].map(|n| SceneObjectId(n.0));
        let cams: Vec<solarxy_core::scene::CameraDef> = self
            .raster
            .scene()
            .cameras()
            .map(<[_]>::to_vec)
            .unwrap_or_default();
        self.renderer.write_camera_helpers(&self.queue, &cams, skip);
    }

    /// Lazily creates a `CameraState` for every pane slot the layout uses
    /// (the desktop recipe: slot 0 primary perspective; slots 1-3 cloned
    /// then reset to Top / Front / Left).
    fn ensure_pane_cameras(&mut self) {
        let bounds = self.scene_bounds();
        let aspect = self.renderer.target_width as f32 / self.renderer.target_height.max(1) as f32;
        solarxy_host::ensure_pane_cameras(
            &self.device,
            &self.renderer.layouts.camera,
            &mut self.view.cameras,
            &bounds,
            aspect,
            self.view.display.layout.pane_count(),
            // This shell has no startup projection preference; slot 0 keeps the
            // camera's own default.
            None,
        );
    }

    /// Per-frame lighting: engine light nodes (root additive lights) drive
    /// the 8-light array when present; otherwise the synthesized viewer rig
    /// follows the primary camera (desktop parity).
    fn update_lights(&mut self) {
        let bounds = self.scene_bounds();
        let ibl_avg = solarxy_host::active_ibl(&self.renderer).irradiance_average;

        // The helpers ride the same light list the shading does, so a helper can
        // never describe a light the renderer is not actually using. Sized in
        // world units, so unlike the manipulator this is once per frame, not
        // once per pane.
        match self.raster.scene().lights() {
            Some(defs) => self.renderer.write_light_helpers(&self.queue, defs),
            None => self.renderer.write_light_helpers(&self.queue, &[]),
        }
        // Immediately after the write that repopulates them, because that is
        // the only thing that could undo it. The lighting below still runs: a
        // still needs the lights, it just must not photograph the furniture.
        self.suppress_furniture_during_still();

        if let Some(defs) = self.raster.scene().authored_lights() {
            self.env.lights_uniform =
                LightsUniform::from_defs(defs, bounds.diagonal() * 0.04, ibl_avg);
        } else if !self.view.display.lights_locked {
            let Some(cam0) = self.view.cameras[0].as_ref().map(|c| c.camera) else {
                return;
            };
            self.env.lights_uniform = lights_from_camera(&cam0, &bounds, ibl_avg);
        } else {
            return;
        }
        self.queue.write_buffer(
            &self.env.light_buffer,
            0,
            bytemuck::cast_slice(&[self.env.lights_uniform]),
        );
        // The shadow map follows THE flagged caster (the engine's
        // exclusive-caster rule guarantees at most one), not blindly the
        // first entry; the synthesized viewer rig keeps its key at entry 0
        // flagged, so its behavior is unchanged.
        let count =
            (self.env.lights_uniform.count as usize).min(self.env.lights_uniform.lights.len());
        let caster = self.env.lights_uniform.lights[..count]
            .iter()
            .position(|l| l.shadowed > 0.5)
            .unwrap_or(0);
        let key = self.env.lights_uniform.lights[caster].position;
        let key_pos = if key.iter().all(|c| c.abs() < f32::EPSILON) {
            // A positionless (directional) key: synthesize a shadow eye
            // along its direction outside the bounds.
            let d = self.env.lights_uniform.lights[caster].direction;
            bounds.center() - Vector3::new(d[0], d[1], d[2]) * bounds.diagonal()
        } else {
            Point3::new(key[0], key[1], key[2])
        };
        self.env.shadow.update_light_vp(
            &self.queue,
            key_pos,
            bounds.center(),
            bounds.diagonal() / 2.0,
        );
    }

    /// Resizes the shared HDR target (and derived buffers) to the largest
    /// pane of the current layout. Port of the desktop
    /// `resize_render_targets` + `sync_render_target_dims`.
    fn sync_render_target_dims(&mut self) {
        let (width, height) = panes::compute_target_dimensions(
            self.view.display.layout,
            self.config.width,
            self.config.height,
        );
        if width == 0 || height == 0 {
            return;
        }
        self.set_target_dims(width, height);
    }

    /// Resizes the shared render targets to exact dimensions (the layout
    /// sync above, the screenshot path's capture-resolution render, and the
    /// still job's per-tile size; restoration after a capture is the next
    /// frame's sync call).
    fn set_target_dims(&mut self, width: u32, height: u32) {
        self.renderer.resize_targets(&self.device, width, height);
    }

    /// Recomputes the manipulator and, when it changed, tells the frontend
    /// what the selection can be manipulated with.
    ///
    /// The manipulator is pull-based: recomputed every frame from the engine's
    /// own view of the world, so a selection change or an undo moves or
    /// removes it with no extra plumbing. `view_dir` and `scale` are per-pane,
    /// so they are placeholders here; `Renderer::write_manipulator` overwrites
    /// both before each pane's pass.
    fn sync_gizmo(&mut self) {
        // A published scene has nothing to manipulate.
        let target = if self.player_mode {
            None
        } else {
            self.engine.gizmo_target(self.current_ctx)
        };
        let manip = target.and_then(|t| {
            self.gizmo
                .manipulator(&gizmo_pose(&t), cgmath::Vector3::unit_z(), 1.0)
        });
        self.renderer.set_manipulator(manip);

        // With nothing selected there is no target and therefore no answer.
        // The frontend reads that as "do not narrow anything", which is what
        // keeps an empty scene's tool column looking the way it always has.
        let capability = target.map(|t| {
            (
                gizmo::tools_for(&t.params)
                    .into_iter()
                    .map(gizmo::ToolMode::id)
                    .collect::<Vec<_>>(),
                t.params.names(),
            )
        });
        if capability != self.last_capability {
            self.last_capability.clone_from(&capability);
            let (tools, transform_params) = capability.unwrap_or_default();
            self.host_events.push(HostEvent::SelectionCapability {
                tools,
                transform_params,
            });
        }
    }

    /// Drops the viewport's furniture while a still render owns the frame.
    ///
    /// A still is a photograph of the scene rather than a screenshot of the
    /// viewport. `PaneDisplaySettings::for_still` states that for everything a
    /// pane flag reaches; the manipulator, the two helper channels and the
    /// light markers are host-fed and reach none of them, so they held
    /// whatever the last ordinary frame left in them and a rasterized still
    /// photographed the gizmo. Cleared rather than gated, and repopulated by
    /// the next ordinary frame, so there is nothing to restore.
    fn suppress_furniture_during_still(&mut self) {
        if self.still.is_some() {
            self.renderer.clear_viewport_furniture();
        }
    }

    /// Assemble this pane's parameters and hand them to the shared body.
    ///
    /// What is left here is policy and assembly: the grading tables, the
    /// manipulator and the camera helpers, all of which this shell has and the
    /// desktop does not; the light-rig guard, which writes through `&mut self`;
    /// and the draw list and the UV source, which this shell resolves against
    /// the document rather than a loaded file.
    /// One pane's per-frame host writes (LUTs, manipulator, camera
    /// helpers, split lighting), and the derived [`PaneInputs`] its encode
    /// and composite read.
    fn prepare_pane(&mut self, i: usize, pane: PaneRect, is_split: bool) -> PaneInputs {
        let pds = self.view.pane_settings[i];
        let cam_data = self.view.cameras[i].as_ref().map(|c| c.camera);
        let is_uv_map = pds.pane_mode == PaneMode::UvMap;

        // Before the pane renders, whichever of the three arms it takes: all
        // of them composite, and the composite is what reads the tables.
        self.bind_pane_luts(i);

        if let Some(cam_data) = cam_data
            && !is_uv_map
        {
            // The gizmo's world size is per-pane (a pane's camera and height
            // decide how many world units a pixel is), so it is re-written
            // before each pane's pass rather than once per frame.
            self.renderer
                .write_manipulator(&self.queue, &cam_data, pane.height / self.dpr);
            self.write_pane_camera_helpers(i);
            // Markers are per pane for the same reason the manipulator is:
            // screen-constant means a pane's own camera and height decide the
            // world size. CSS pixels, so a retina display does not halve them.
            if pds.show_light_markers {
                let selected = self.selected_object;
                let lights = self.raster.scene().lights().map(<[_]>::to_vec);
                self.renderer.write_light_markers(
                    &self.queue,
                    lights.as_deref().unwrap_or(&[]),
                    &cam_data,
                    pane.height / self.dpr,
                    selected,
                );
            }
            if is_split && i >= 1 {
                self.setup_pane_lighting(&cam_data);
            }
        }

        // A traced 3D pane goes to the tracer instead of the rasterizer;
        // everything around the encode (the pane context, the composite,
        // the look) is shared, which is the backend contract's point.
        let traced = pds.pane_engine == PaneEngine::Traced
            && !is_uv_map
            && cam_data.is_some()
            && self.tracer.is_some();
        if traced {
            self.prepare_traced_pane(i);
        }

        PaneInputs {
            traced,
            background: self.resolve_background(&pds),
            bounds: self.scene_bounds(),
            look: self.pane_look(i),
            // The composite folds bloom and ambient occlusion in only when
            // there is something to fold them around. This shell used to pass
            // a constant here, which put a glow on an empty viewport.
            scene_present: self.raster.scene().draw_objects().next().is_some(),
            outline: self.renderer.selection_style
                == solarxy_renderer::frame::SelectionStyle::Outline
                && self
                    .selected_object
                    .is_some_and(|id| self.raster.scene().draw_object(id).is_some()),
            // The grid plane follows the pane camera: perspective keeps the
            // XZ ground; an orthographic axis elevation (front/side) gets a
            // view-plane grid so it is not seen edge-on. Keyed off the
            // transition destination so a view-preset animation switches
            // plane once, at click time, not partway through the lerp.
            grid_plane: self.view.cameras[i]
                .as_ref()
                .map(|c| grid_plane_for(&c.destination_camera())),
        }
    }

    // One pane's frame, start to finish: the context, the backend that draws
    // it, the composite. Most of the body is a single struct literal, so the
    // only extraction available is one taking twenty parameters.
    #[allow(clippy::too_many_lines)]
    fn render_pane(
        &mut self,
        i: usize,
        pane: PaneRect,
        surface_view: &wgpu::TextureView,
        is_split: bool,
    ) {
        let pds = self.view.pane_settings[i];
        let cam_data = self.view.cameras[i].as_ref().map(|c| c.camera);
        let is_uv_map = pds.pane_mode == PaneMode::UvMap;
        let PaneInputs {
            background,
            bounds,
            look,
            scene_present,
            outline,
            grid_plane,
            traced,
        } = self.prepare_pane(i, pane, is_split);

        // Field-level borrows from here on, so the shared body can take the
        // renderer mutably while the draw list borrows the scene.
        // Everything below borrows fields other than `raster`, so the backend
        // can be driven mutably. The preview scene is this host's own; the
        // fallback is an object the backend owns, so it resolves that itself.
        let content = match cam_data {
            None => PaneContent::Empty,
            Some(_) if is_uv_map => PaneContent::Uv {
                source: if self.uv_use_preview {
                    self.uv_scene
                        .draw_object(UV_PREVIEW_ID)
                        .map_or(UvSource::None, UvSource::External)
                } else {
                    UvSource::Scene {
                        preferred: self.selected_object,
                    }
                },
            },
            Some(cam_data) => PaneContent::Scene {
                // This host draws nothing that did not come down the delta
                // stream, so there is no extra object.
                extra: None,
                selected: self.selected_object,
                cam_data,
                shadow: i == 0 || !self.view.display.lights_locked,
            },
        };

        let mut encoder = self
            .device
            .create_command_encoder(&wgpu::CommandEncoderDescriptor {
                label: Some("Pane Encoder"),
            });
        let hdr_target = self.renderer.targets.hdr_resolve_view.clone();
        let outcome = {
            let mut ctx = FrameCtx {
                device: &self.device,
                queue: &self.queue,
                renderer: &mut self.renderer,
                encoder: &mut encoder,
                index: i,
                rect: pane,
                is_split,
                pds: &pds,
                display: &self.view.display,
                background,
                camera: self.view.cameras[i].as_mut(),
                env: &self.env,
                bounds: Some(&bounds),
                grid_plane,
                look,
                scene_present,
                outline,
                // An ordinary frame is a view in its own right, not a window on
                // a larger picture. Only the still render sets this.
                window: None,
                content,
            };
            if traced {
                self.tracer
                    .as_mut()
                    .map_or(FrameOutcome::Complete, |t| t.encode(&mut ctx, &hdr_target))
            } else {
                self.raster.encode(&mut ctx, &hdr_target)
            }
        };
        if traced {
            self.push_pane_samples(i, outcome);
        }
        let caps = if traced {
            PathBackend::CAPS
        } else {
            RasterBackend::CAPS
        };
        let pass = if traced {
            solarxy_host::EncodedPane {
                is_uv_map: false,
                scene_present,
            }
        } else {
            self.raster.encoded(i).unwrap_or(solarxy_host::EncodedPane {
                is_uv_map: false,
                scene_present: false,
            })
        };

        solarxy_host::composite_and_submit(
            &self.queue,
            &self.renderer,
            encoder,
            surface_view,
            &solarxy_host::PaneComposite {
                index: i,
                rect: pane,
                look,
                inspection: pds.inspection_mode,
                is_uv_map: pass.is_uv_map,
                scene_present: pass.scene_present,
                outline,
                writes_occlusion: caps.writes_occlusion,
            },
        );
    }

    /// The look of the `camera` node a pane is looking through, if any.
    ///
    /// Reads the lowered `CameraDef` rather than the document, so it sees
    /// exactly what the last delta carried, including the tables the
    /// camera's cook decoded.
    fn pane_camera_look(&self, pane: usize) -> Option<&solarxy_core::scene::CameraLook> {
        self.pane_camera_def(pane).map(|c| &c.look)
    }

    /// The camera definition a pane is bound to, if it is looking through one.
    fn pane_camera_def(&self, pane: usize) -> Option<&solarxy_core::scene::CameraDef> {
        let node = (*self.look_through.get(pane)?)?;
        self.raster
            .scene()
            .cameras()?
            .iter()
            .find(|c| c.id == solarxy_core::scene::SceneObjectId(node.0))
    }

    /// The lens a shot takes: the named camera's, or the active pane's
    /// camera's, or a pinhole. The same precedence the look resolves by,
    /// because both describe the shot rather than the viewport.
    fn still_lens(&self, camera: Option<NodeId>) -> solarxy_core::scene::CameraLens {
        camera
            .and_then(|node| {
                let id = SceneObjectId(node.0);
                self.raster
                    .scene()
                    .cameras()
                    .and_then(|cams| cams.iter().find(|c| c.id == id))
            })
            .or_else(|| self.pane_camera_def(self.view.active_pane))
            .map(solarxy_host::cameras::lens_for)
            .unwrap_or_default()
    }

    /// The resolved look a pane composites with.
    fn pane_look(&self, pane: usize) -> CompositeLook {
        let fallback = self.pane_looks.get(pane).copied().unwrap_or_default();
        solarxy_renderer::composite::resolve_look(self.pane_camera_look(pane), &fallback)
    }

    /// Bind the grading tables a pane's camera carries, before that pane
    /// composites.
    ///
    /// There is one pair of table textures for the whole renderer while a
    /// look is per pane, so the pair has to follow whichever pane is about
    /// to composite. `set_lut` dedupes on content hash, so the common case
    /// (no tables, or every pane through the same camera) costs two
    /// comparisons and rebuilds nothing. The case that does cost something
    /// is several panes through several cameras with *different* tables,
    /// which rebuilds the composite bind group once per pane per frame;
    /// that is a known cost of one shared pair, and caching a bind group
    /// per distinct pair is the fix if it ever shows up in a profile.
    /// Resolve the look a still composites with, and bind the tables it asks
    /// for.
    ///
    /// The look belongs to the camera being shot through. Falling back to the
    /// active pane's camera is right only when the render node names none, and
    /// that is exactly when the shot *is* the active pane's view, grade and
    /// all.
    ///
    /// Binding here is what [`Self::bind_pane_luts`] cannot do for a still.
    /// There is one table pair for the whole renderer, the pane path is its
    /// only other binder, and a running job replaces that path wholesale: with
    /// nothing binding for the job's duration the composite reads whatever the
    /// last drawn pane left behind. Once at the start is enough, because the
    /// tables cannot change while a job runs, and it is self-healing, because
    /// the pane path rebinds its own on the first ordinary frame afterwards.
    /// The bind dedupes on content hash, so an ungraded shot costs two
    /// comparisons.
    fn prepare_still_look(&mut self, camera: Option<NodeId>) {
        let camera_look = camera
            .and_then(|node| {
                let id = SceneObjectId(node.0);
                self.raster
                    .scene()
                    .cameras()
                    .and_then(|cams| cams.iter().find(|c| c.id == id).map(|c| c.look.clone()))
            })
            .or_else(|| self.pane_camera_look(self.view.active_pane).cloned());
        let pane_fallback = self
            .pane_looks
            .get(self.view.active_pane)
            .copied()
            .unwrap_or_default();
        self.still_look =
            solarxy_renderer::composite::resolve_look(camera_look.as_ref(), &pane_fallback);

        let (lut_a, lut_b) = camera_look
            .as_ref()
            .map_or((None, None), |l| (l.lut_a.clone(), l.lut_b.clone()));
        self.renderer
            .set_lut(&self.device, &self.queue, LutSlot::A, lut_a.as_deref());
        self.renderer
            .set_lut(&self.device, &self.queue, LutSlot::B, lut_b.as_deref());
    }

    fn bind_pane_luts(&mut self, pane: usize) {
        let (a, b) = self
            .pane_camera_look(pane)
            .map_or((None, None), |l| (l.lut_a.clone(), l.lut_b.clone()));
        self.renderer
            .set_lut(&self.device, &self.queue, LutSlot::A, a.as_deref());
        self.renderer
            .set_lut(&self.device, &self.queue, LutSlot::B, b.as_deref());
    }

    /// The tracer's half of the viewer rig, before a still starts.
    ///
    /// A scene with no light nodes is lit in the viewport by the rig the panes
    /// write into the lights uniform. The tracer binds no such uniform, so it
    /// takes the same three definitions as scene data, from the camera this
    /// shot is taken through rather than from whichever pane happens to be
    /// active.
    fn light_traced_still(&mut self, camera: &Camera) {
        if let Some(t) = self.tracer.as_mut() {
            solarxy_host::apply_viewer_rig(
                &self.device,
                &self.queue,
                t,
                self.raster.scene(),
                camera,
            );
        }
    }

    /// Recomputes the camera-relative light rig for a non-primary pane
    /// (only meaningful for the synthesized viewer rig; engine light nodes
    /// are world-fixed).
    fn setup_pane_lighting(&mut self, cam_data: &Camera) {
        // Engine light nodes are world-fixed and owe nothing to a camera, so
        // the synthesized viewer rig is the only thing this applies to.
        if self.view.display.lights_locked || self.raster.scene().authored_lights().is_some() {
            return;
        }
        let bounds = self.scene_bounds();
        let ibl_avg = solarxy_host::active_ibl(&self.renderer).irradiance_average;
        solarxy_host::setup_pane_lighting(&self.queue, &mut self.env, cam_data, &bounds, ibl_avg);
    }

    fn view_state_dto(&self) -> ViewStateDto {
        let default_projection = ProjectionMode::Perspective;
        let projections = std::array::from_fn(|i| {
            projection_name(
                self.view.cameras[i]
                    .as_ref()
                    .map_or(default_projection, |c| c.camera.projection),
            )
            .to_string()
        });
        let cams = self.raster.scene().cameras();
        let pane_look_through = std::array::from_fn(|i| self.look_through[i].map(|n| n.0 as f64));
        let pane_gate_aspect = std::array::from_fn(|i| {
            let node = self.look_through[i]?;
            cams?
                .iter()
                .find(|c| c.id == SceneObjectId(node.0))
                .map(|c| c.aspect)
        });
        ViewStateDto {
            layout: self.view.display.layout,
            split_ratio: self.view.display.split_ratio,
            active_pane: self.view.active_pane,
            cameras_linked: self.view.cameras_linked,
            pane_settings: self.view.pane_settings,
            display: self.view.display,
            pane_projections: projections,
            pane_rects: self.pane_rects_css(),
            pane_looks: self.pane_looks,
            pane_look_through,
            pane_camera_locked: self.camera_locked,
            pane_gate_aspect,
            attr_viz: self.attr_viz.clone(),
        }
    }

    // ---- .slxy view sidecar bridge ----

    fn view_json(&self) -> solarxy_scenefile::ViewJson {
        let layout = serde_json::to_value(self.view.display.layout)
            .ok()
            .and_then(|v| v.as_str().map(String::from))
            .unwrap_or_else(|| "single".to_string());
        let panes_json = (0..4)
            .map(|i| {
                let camera = self.view.cameras[i]
                    .as_ref()
                    .map_or_else(solarxy_scenefile::CameraJson::default, |c| {
                        camera_to_json(&c.camera)
                    });
                // The pane's look rides inside the display blob rather than
                // taking a schema field of its own. `PaneJson::display` is
                // declared opaque and round-tripped uninterpreted, and
                // `PaneDisplaySettings` ignores keys it does not know, so
                // this persists a free pane's exposure and grade with no
                // scene-schema change and no reader-version gate.
                let display = serde_json::to_value(self.view.pane_settings[i])
                    .ok()
                    .and_then(|v| {
                        if let serde_json::Value::Object(mut map) = v {
                            if let Ok(look) = serde_json::to_value(self.pane_looks[i]) {
                                map.insert(PANE_LOOK_KEY.to_string(), look);
                            }
                            Some(map.into_iter().collect())
                        } else {
                            None
                        }
                    })
                    .unwrap_or_default();
                solarxy_scenefile::PaneJson {
                    camera,
                    display,
                    look_through: self.look_through[i].map(|n| n.0),
                    camera_locked: self.camera_locked[i],
                    ..solarxy_scenefile::PaneJson::default()
                }
            })
            .collect();
        solarxy_scenefile::ViewJson {
            layout,
            active_pane: self.view.active_pane as u32,
            split_ratio: self.view.display.split_ratio,
            panes: panes_json,
        }
    }

    fn apply_view_json(&mut self, view: &solarxy_scenefile::ViewJson) {
        if let Ok(layout) =
            serde_json::from_value::<ViewLayout>(serde_json::Value::String(view.layout.clone()))
        {
            self.view.display.layout = layout;
        }
        self.view.display.split_ratio = DisplaySettings::clamp_split_ratio(view.split_ratio);
        self.view.active_pane =
            (view.active_pane as usize).min(self.view.display.layout.pane_count() - 1);

        for (i, pane) in view.panes.iter().take(4).enumerate() {
            if !pane.display.is_empty() {
                let value = serde_json::Value::Object(pane.display.clone().into_iter().collect());
                // Absent on any scene saved before the look existed, which
                // is the whole reason it defaults rather than failing.
                self.pane_looks[i] = pane
                    .display
                    .get(PANE_LOOK_KEY)
                    .and_then(|v| serde_json::from_value::<PaneLook>(v.clone()).ok())
                    .unwrap_or_default();
                if let Ok(mut settings) = serde_json::from_value::<PaneDisplaySettings>(value) {
                    // Viewport shading overrides and the turntable spin are
                    // session-temporary (items 7, 9): never restored from a
                    // saved scene, so a reopened scene starts Textured and still.
                    settings.material_override = solarxy_core::preferences::MaterialOverride::None;
                    settings.turntable_active = false;
                    self.view.pane_settings[i] = settings;
                }
            }
            if pane.camera.distance > 0.0 {
                let bounds = self.scene_bounds();
                let aspect =
                    self.renderer.target_width as f32 / self.renderer.target_height.max(1) as f32;
                let cam_state = self.view.cameras[i].get_or_insert_with(|| {
                    CameraState::new(&self.device, &self.renderer.layouts.camera, &bounds, aspect)
                });
                apply_camera_json(&mut cam_state.camera, &pane.camera);
            }
            // Restore the look-through binding + lock. The follow will
            // drive the pane from the node once it cooks.
            self.look_through[i] = pane.look_through.map(NodeId);
            self.camera_locked[i] = pane.camera_locked;
            self.camera_editing[i] = false;
        }
        self.ensure_pane_cameras();
    }
}

/// The asset-preview pane's isolated render state: its own surface
/// (a second canvas from the SAME instance/device), a throwaway `SceneObjects`
/// holding one parsed model, and an orbit camera. Never touches the document.
///
/// **The one place in this host that still drives the renderer's passes
/// directly rather than through a backend, and deliberately so.** It is not a
/// document pane: it holds a staged asset nobody has imported, and it runs a
/// reduced chain on purpose, shadow and main only, with bloom and ambient
/// occlusion off, because a preview is a shaded look rather than a beauty
/// frame. Routing it through the shared pane body would encode the gbuffer,
/// ambient-occlusion and bloom passes it exists to skip, which is a behaviour
/// change dressed as a cleanup. Left as it is, on purpose.
struct PreviewState {
    surface: wgpu::Surface<'static>,
    config: wgpu::SurfaceConfiguration,
    objects: SceneObjects,
    camera: CameraState,
}

/// The asset-preview pane: a live 3D orbit view of one staged model,
/// rendered ON DEMAND (open / orbit / zoom / resize), never in the frame loop,
/// so an idle preview costs nothing. Each render borrows the shared HDR chain
/// at preview size (the screenshot pattern); the next main frame's target sync
/// restores it.
#[wasm_bindgen]
impl SolarxyApp {
    /// Opens (or replaces) the model preview on the given canvas: parses the
    /// staged asset through the same `parse_model` path the import cooks use,
    /// frames a camera on its bounds, and renders the first frame.
    pub fn preview_open(
        &mut self,
        canvas: web_sys::HtmlCanvasElement,
        hash: String,
        name: String,
    ) -> Result<(), JsError> {
        let format = name
            .rsplit('.')
            .next()
            .map(str::to_lowercase)
            .unwrap_or_default();
        let id = solarxy_graph::params::AssetId(hash);
        let Some(bytes) = self.engine.asset_bytes(&id).map(<[_]>::to_vec) else {
            return Err(JsError::new("asset is not staged"));
        };
        let options = ImportOptions {
            scale: 1.0,
            center_to_origin: false,
            recompute_normals: None,
            preserve_materials: None,
            vertex_colors: None,
        };
        let set = solarxy_graph::nodes::parse_model(
            &format,
            &bytes,
            &name,
            self.engine.asset_table(),
            &options,
        )
        .map_err(|e| JsError::new(&format!("preview parse failed: {e}")))?;
        self.preview_render_set(canvas, set)
    }

    /// Opens the model preview from a geometry blob the import worker parsed
    /// off the main thread (the same `transfer` blob a normal import commits
    /// through `submit_parsed_model`). This is the hitch-free path: the
    /// blocking `parse_model` runs in the worker, not on the main thread.
    pub fn preview_open_parsed(
        &mut self,
        canvas: web_sys::HtmlCanvasElement,
        blob: Vec<u8>,
    ) -> Result<(), JsError> {
        let set =
            transfer::unpack(&blob).map_err(|e| JsError::new(&format!("preview blob: {e}")))?;
        self.preview_render_set(canvas, set)
    }

    /// Orbits the preview camera (canvas-px deltas) and re-renders.
    pub fn preview_orbit(&mut self, dx: f32, dy: f32) {
        if let Some(p) = self.preview.as_mut() {
            let cam = &mut p.camera.camera;
            orbit_camera_yaw(cam, dx * -0.008);
            // Pitch: rotate eye about the target's horizontal axis, clamped so
            // the orbit never flips over the pole.
            let offset = cam.eye - cam.target;
            let dist = offset.magnitude().max(1e-4);
            let pitch = (offset.y / dist).clamp(-1.0, 1.0).asin();
            let new_pitch = (pitch + dy * 0.008).clamp(-1.45, 1.45);
            let horiz = (offset.x * offset.x + offset.z * offset.z).sqrt().max(1e-4);
            let scale = (dist * new_pitch.cos()) / horiz;
            cam.eye = cam.target
                + Vector3::new(offset.x * scale, dist * new_pitch.sin(), offset.z * scale);
        }
        self.render_preview();
    }

    /// Dollies the preview camera and re-renders; positive zooms in.
    pub fn preview_zoom(&mut self, delta: f32) {
        if let Some(p) = self.preview.as_mut() {
            let cam = &mut p.camera.camera;
            let offset = cam.eye - cam.target;
            cam.eye = cam.target + offset * (-delta * 0.1).exp();
        }
        self.render_preview();
    }

    /// Resizes the preview surface to the canvas's current physical size.
    pub fn preview_resize(&mut self, width: u32, height: u32) {
        if let Some(p) = self.preview.as_mut() {
            p.config.width = width.max(16);
            p.config.height = height.max(16);
            p.surface.configure(&self.device, &p.config);
        }
        self.render_preview();
    }

    /// Drops the preview (its surface, geometry, and camera).
    pub fn preview_close(&mut self) {
        self.preview = None;
    }
}

impl SolarxyApp {
    /// Uploads a parsed set to a throwaway preview surface on `canvas`,
    /// frames a camera on its bounds, and renders the first frame. Shared by
    /// `preview_open` (host parse) and `preview_open_parsed` (worker parse).
    fn preview_render_set(
        &mut self,
        canvas: web_sys::HtmlCanvasElement,
        set: solarxy_kernel::GeometrySet,
    ) -> Result<(), JsError> {
        let cooked = std::sync::Arc::new(set.to_cooked());

        let width = canvas.width().max(16);
        let height = canvas.height().max(16);
        let surface = self
            .instance
            .create_surface(wgpu::SurfaceTarget::Canvas(canvas))
            .map_err(|e| JsError::new(&format!("preview surface: {e}")))?;
        let mut config = self.config.clone();
        config.width = width;
        config.height = height;
        surface.configure(&self.device, &config);

        let mut objects = SceneObjects::new();
        let delta = SceneDelta {
            ops: vec![SceneOp::UpsertGeometry {
                id: SceneObjectId(0),
                geometry: cooked,
            }],
        };
        objects
            .apply(&self.device, &self.queue, &self.renderer.layouts, &delta)
            .map_err(|e| JsError::new(&format!("preview upload: {e}")))?;
        let bounds = objects.visible_bounds().unwrap_or_else(default_bounds);
        let aspect = width as f32 / height.max(1) as f32;
        let camera = CameraState::new(&self.device, &self.renderer.layouts.camera, &bounds, aspect);

        self.preview = Some(PreviewState {
            surface,
            config,
            objects,
            camera,
        });
        self.render_preview();
        Ok(())
    }

    /// Renders one preview frame into the preview surface, reusing the shared
    /// render chain at preview size (the screenshot pattern; the next main
    /// frame's `sync_render_target_dims` restores the layout dimensions).
    fn render_preview(&mut self) {
        let Some((w, h)) = self
            .preview
            .as_ref()
            .map(|p| (p.config.width, p.config.height))
        else {
            return;
        };
        // Everything that needs whole-&self access happens BEFORE the preview
        // borrow; inside it only disjoint field borrows are used.
        self.set_target_dims(w, h);
        let mut pds = default_pane_settings();
        pds.show_grid = false;
        pds.show_axis_gizmo = false;
        let background = self.resolve_background(&pds);

        let Some(p) = self.preview.as_mut() else {
            return;
        };
        let aspect = w as f32 / h.max(1) as f32;
        p.camera.write_with_aspect(&self.queue, aspect);

        let output = match p.surface.get_current_texture() {
            Ok(frame) => frame,
            Err(wgpu::SurfaceError::Outdated | wgpu::SurfaceError::Lost) => {
                p.surface.configure(&self.device, &p.config);
                return;
            }
            Err(_) => return,
        };
        let view = output.texture.create_view(&wgpu::TextureViewDescriptor {
            format: Some(self.render_format),
            ..Default::default()
        });

        let objects: Vec<solarxy_renderer::frame::DrawObject<'_>> =
            p.objects.draw_objects().collect();
        let mut encoder = self
            .device
            .create_command_encoder(&wgpu::CommandEncoderDescriptor {
                label: Some("Preview Encoder"),
            });
        // Shadow the preview content itself, so the map matches what is drawn.
        self.renderer
            .render_shadow_pass(&mut encoder, &self.env, &objects);
        self.renderer.render_main_pass(
            &mut encoder,
            &self.env,
            &objects,
            &p.camera.bind_group,
            &p.camera.camera,
            &pds,
            background,
        );
        // Composite without bloom/SSAO: a preview is a shaded look, not a
        // post-processed beauty frame.
        self.renderer.post.composite.write_params(
            &self.queue,
            false,
            false,
            &CompositeLook::from_tone(self.renderer.post.tone_mode, self.renderer.post.exposure),
            &self.renderer.post.luts,
            pds.inspection_mode,
            false,
        );
        self.renderer.post.composite.render(
            &mut encoder,
            &self.renderer.pipelines,
            &view,
            false,
            &self.renderer.post.ssao,
            Some([0.0, 0.0, w as f32, h as f32]),
            true,
            None,
        );
        self.queue.submit(std::iter::once(encoder.finish()));
        output.present();
    }
}

fn map_button(button: u32) -> Option<PointerButton> {
    match button {
        0 => Some(PointerButton::Left),
        1 => Some(PointerButton::Middle),
        2 => Some(PointerButton::Right),
        _ => None,
    }
}

/// Orbits a camera's eye around its target about the world-up (Y) axis by
/// `yaw` radians: the turntable rotation for a deterministic export sweep.
fn orbit_camera_yaw(cam: &mut Camera, yaw: f32) {
    let offset = cam.eye - cam.target;
    let (s, c) = yaw.sin_cos();
    let x = offset.x * c + offset.z * s;
    let z = -offset.x * s + offset.z * c;
    cam.eye = cam.target + Vector3::new(x, offset.y, z);
}

fn projection_name(mode: ProjectionMode) -> &'static str {
    match mode {
        ProjectionMode::Perspective => "perspective",
        ProjectionMode::Orthographic => "orthographic",
    }
}

/// Bridges the renderer camera to the `.slxy` orbit shape (target + yaw /
/// pitch / distance): `dir = eye - target`, `pitch = asin(dir.y)`,
/// `yaw = atan2(dir.x, dir.z)`.
fn camera_to_json(cam: &Camera) -> solarxy_scenefile::CameraJson {
    let offset = cam.eye - cam.target;
    let distance = offset.magnitude().max(1e-4);
    let dir = offset / distance;
    solarxy_scenefile::CameraJson {
        target: [cam.target.x, cam.target.y, cam.target.z],
        yaw: dir.x.atan2(dir.z),
        pitch: dir.y.clamp(-1.0, 1.0).asin(),
        distance,
        fov_y: cam.fovy.to_radians(),
        projection: projection_name(cam.projection).to_string(),
        ortho_scale: cam.ortho_scale,
    }
}

/// Copies a resolved `CameraDef` (from a `camera` node) into a viewport
/// camera, so a pane looking through the node shows exactly what it frames.
/// The pane's aspect is not touched here (it tracks the pane rect); the
/// framing gate uses the def's own aspect.
fn apply_camera_json(cam: &mut Camera, json: &solarxy_scenefile::CameraJson) {
    let target = Point3::new(json.target[0], json.target[1], json.target[2]);
    let cp = json.pitch.cos();
    let dir = Vector3::new(cp * json.yaw.sin(), json.pitch.sin(), cp * json.yaw.cos());
    cam.target = target;
    cam.eye = target + dir * json.distance.max(1e-4);
    // A hardcoded +Y up is degenerate for a scene saved in a top/bottom view
    // (look_at with forward parallel to up); the turntable up at the stored
    // angles is what the orbit maintains live.
    cam.up = turntable_up(json.yaw, json.pitch);
    if json.fov_y > 0.0 {
        cam.fovy = json.fov_y.to_degrees();
    }
    cam.projection = if json.projection == "orthographic" {
        ProjectionMode::Orthographic
    } else {
        ProjectionMode::Perspective
    };
    if json.ortho_scale > 0.0 {
        cam.ortho_scale = json.ortho_scale;
    }
}

/// Serializes a value to a `JsValue` via serde-wasm-bindgen, using the
/// json-compatible serializer so Rust maps (e.g. a node's `params`) become
/// plain JS objects rather than `Map`s, matching what the frontend expects.
fn to_js<T: serde::Serialize>(value: &T) -> Result<JsValue, JsError> {
    value
        .serialize(&serde_wasm_bindgen::Serializer::json_compatible())
        .map_err(|e| JsError::new(&format!("serialize: {e}")))
}

/// The import-worker parse entry: a GPU-free wasm export the worker calls in
/// a second, headless instantiation of this same module. It parses `files`
/// (a JS array of `{ name, bytes }`, the primary model first, then any
/// sidecars) into a finished [`solarxy_kernel::GeometrySet`] and returns
/// `{ blob, validation }`: the geometry transfer blob (`Uint8Array`) plus
/// the implicit load validation as JSON (the same `validate_raw_model` the
/// desktop viewer runs at load). Never touches wgpu, so instantiating it in
/// a worker creates no device.
#[wasm_bindgen]
pub fn parse_model_job(
    format: String,
    options_json: String,
    files: JsValue,
) -> Result<JsValue, JsError> {
    let files = read_files(&files)?;
    let (name, bytes) = files
        .first()
        .ok_or_else(|| JsError::new("parse_model_job: no files provided"))?;
    let options: ImportOptions = serde_json::from_str(&options_json)
        .map_err(|e| JsError::new(&format!("bad import options: {e}")))?;

    // Rebuild a temporary asset table so the resolver can find sidecars by
    // name (content-addressed staging; ids are irrelevant here).
    let mut table = AssetTable::new();
    for (n, b) in &files {
        table.stage(n.clone(), String::new(), b.clone());
    }

    let (set, validation) =
        solarxy_graph::nodes::parse_model_validated(&format, bytes, name, &table, &options)
            .map_err(|e| JsError::new(&e))?;
    let validation_json = serde_json::to_string(&validation)
        .map_err(|e| JsError::new(&format!("serialize validation: {e}")))?;
    let out = js_sys::Object::new();
    js_sys::Reflect::set(
        &out,
        &JsValue::from_str("blob"),
        &js_sys::Uint8Array::from(transfer::pack(&set).as_slice()),
    )
    .map_err(|_| JsError::new("parse_model_job: reflect set failed"))?;
    js_sys::Reflect::set(
        &out,
        &JsValue::from_str("validation"),
        &JsValue::from_str(&validation_json),
    )
    .map_err(|_| JsError::new("parse_model_job: reflect set failed"))?;
    Ok(out.into())
}

/// The worker validation entry (the validate node above its inline
/// threshold): unpacks the geometry transfer blob, runs the configured
/// validation pipeline, and returns the full `ValidationResult` as JSON.
/// GPU-free, like `parse_model_job`.
#[wasm_bindgen]
pub fn validate_geometry_job(
    blob: Vec<u8>,
    config_json: String,
    budget: Option<u32>,
) -> Result<String, JsError> {
    let set =
        transfer::unpack(&blob).map_err(|e| JsError::new(&format!("bad geometry blob: {e}")))?;
    let config: ValidationConfig = serde_json::from_str(&config_json)
        .map_err(|e| JsError::new(&format!("bad validation config: {e}")))?;
    let raw = set.to_raw();
    let result =
        validate_raw_model_with_config(&raw, "", &config, &ValidationThresholds::default(), budget);
    serde_json::to_string(&result).map_err(|e| JsError::new(&format!("serialize result: {e}")))
}

/// The worker HDRI-preparation entry: runs the CPU stages of the IBL
/// build (decode, sanitize, irradiance convolution) off-thread and returns
/// the packed [`solarxy_renderer::ibl::PreparedHdri`] blob for
/// `set_environment_prepared`. GPU-free, like the other worker exports.
#[wasm_bindgen]
pub fn prepare_hdri_job(bytes: Vec<u8>, format: String) -> Result<js_sys::Uint8Array, JsError> {
    let prepared = solarxy_renderer::ibl::PreparedHdri::prepare(&bytes, &format)
        .map_err(|e| JsError::new(&format!("prepare HDRI: {e}")))?;
    Ok(js_sys::Uint8Array::from(prepared.pack().as_slice()))
}

/// The import-worker hierarchy-build entry: builds one acceleration structure
/// over a mesh and returns the packed transfer blob.
///
/// The fourth GPU-free worker export, and the reason this one exists is the
/// same as the first: wasm has no threads, and a build over a million
/// triangles is seconds rather than milliseconds, so running it on the main
/// thread would stall the frame loop for the length of the build. Native hosts
/// call `build_hierarchy_job` directly on their own thread; it is the same
/// function, so there is one build path rather than two.
///
/// `positions` is flat `xyz`. Both arrive as typed arrays and are copied into
/// this instance's heap by `wasm-bindgen`, which is unavoidable: the worker is
/// a second wasm instance with its own memory and nothing can be shared into
/// it.
#[wasm_bindgen]
pub fn build_bvh_job(positions: Vec<f32>, indices: Vec<u32>) -> js_sys::Uint8Array {
    js_sys::Uint8Array::from(
        solarxy_renderer::pathtrace::scene::build_hierarchy_job(&positions, &indices).as_slice(),
    )
}

/// Reads a JS array of `{ name: string, bytes: Uint8Array }` into owned
/// `(name, bytes)` pairs.
fn read_files(files: &JsValue) -> Result<Vec<(String, Vec<u8>)>, JsError> {
    let array: js_sys::Array = files
        .clone()
        .dyn_into()
        .map_err(|_| JsError::new("parse_model_job: files must be an array"))?;
    let mut out = Vec::with_capacity(array.length() as usize);
    for item in array.iter() {
        let name = js_sys::Reflect::get(&item, &JsValue::from_str("name"))
            .ok()
            .and_then(|v| v.as_string())
            .unwrap_or_default();
        let bytes = js_sys::Reflect::get(&item, &JsValue::from_str("bytes"))
            .ok()
            .and_then(|v| v.dyn_into::<js_sys::Uint8Array>().ok())
            .map(|u| u.to_vec())
            .unwrap_or_default();
        out.push((name, bytes));
    }
    Ok(out)
}

// ---- boundary DTOs (camelCase; the engine/scene-file types stay
// snake_case on disk, so these bridge to the JS convention) ----

/// Screen-edge slack shared by the review-marker DOM projection: a little
/// beyond the frustum so pins fade at the edge instead of popping exactly
/// on it.
const NDC_XY_SLACK: f32 = 1.05;
/// The wgpu clip-space depth range with the same slack; the z cull is
/// what rejects behind-camera points under orthographic projection,
/// where `clip.w` is a constant 1.
const NDC_Z_MIN: f32 = -0.05;
const NDC_Z_MAX: f32 = 1.05;

#[derive(Serialize)]
#[serde(rename_all = "camelCase")]
struct ViewStateDto {
    layout: ViewLayout,
    split_ratio: f32,
    active_pane: usize,
    cameras_linked: bool,
    pane_settings: [PaneDisplaySettings; 4],
    /// Each pane's own look, which the Look dialog edits. A pane looking
    /// through a camera shows that camera's look instead and edits it on
    /// the node.
    pane_looks: [PaneLook; 4],
    display: DisplaySettings,
    pane_projections: [String; 4],
    pane_rects: Vec<RectDto>,
    /// The `camera` node each pane looks through (id as a number), or `null`
    /// for a free view.
    pane_look_through: [Option<f64>; 4],
    /// Whether each look-through pane is locked (reframes the camera).
    pane_camera_locked: [bool; 4],
    /// The framing aspect of each pane's look-through camera (for the gate
    /// overlay); `null` when the pane is a free view.
    pane_gate_aspect: [Option<f32>; 4],
    /// The host-owned attribute-visualization state (the right strip
    /// mirrors this, like the tool mode).
    attr_viz: AttrVizState,
}

#[derive(Deserialize, Default)]
#[serde(rename_all = "camelCase", default)]
struct CameraCommandDto {
    kind: String,
    axis: String,
    mode: String,
}

#[derive(Serialize)]
#[serde(rename_all = "camelCase")]
struct CameraPoseDto {
    position: [f32; 3],
    target: [f32; 3],
}

#[derive(Serialize)]
#[serde(rename_all = "camelCase")]
struct ImportJobDto {
    ctx: GraphContext,
    job_id: f64,
    hash: String,
    name: String,
    format: String,
    options: ImportOptions,
    sidecars: Vec<AssetRefDto>,
}

#[derive(Serialize)]
#[serde(rename_all = "camelCase")]
struct AssetRefDto {
    hash: String,
    name: String,
}

/// The parameter panel's per-row readout: a value, or why there is none.
#[derive(Serialize)]
#[serde(rename_all = "camelCase")]
struct ResolvedParamDto {
    ok: bool,
    #[serde(skip_serializing_if = "Option::is_none")]
    value: Option<solarxy_graph::params::ParamValue>,
    #[serde(skip_serializing_if = "Option::is_none")]
    error: Option<String>,
}

#[derive(Deserialize, Default)]
#[serde(rename_all = "camelCase", default)]
struct SaveExtra {
    generator: String,
    canvas_viewports: BTreeMap<String, ViewportDto>,
    meta: MetaDto,
}

#[derive(Serialize)]
#[serde(rename_all = "camelCase")]
struct LoadResultDto {
    batch: EventBatch,
    warnings: Vec<String>,
    canvas_viewports: BTreeMap<String, ViewportDto>,
    meta: MetaDto,
    environment: EnvironmentDto,
}

#[derive(Serialize)]
#[serde(rename_all = "camelCase")]
struct EnvironmentDto {
    ibl_mode: String,
    hdri_hash: Option<String>,
    hdri_name: Option<String>,
    /// Whether the loaded document holds an `environment` node.
    ///
    /// When it does, the node wins and the frontend must not restore the
    /// scene file's own environment section: the node's cook emits
    /// `SceneOp::SetEnvironment` and installing the sidecar's HDRI too
    /// would race it, with whichever finished last taking the viewport.
    /// The section stays the fallback for documents authored before the
    /// node existed, which is the whole point of keeping it.
    from_node: bool,
}

#[derive(Serialize, Deserialize, Default)]
struct ViewportDto {
    x: f32,
    y: f32,
    zoom: f32,
}

impl From<ViewportDto> for solarxy_scenefile::CanvasViewportJson {
    fn from(v: ViewportDto) -> Self {
        Self {
            x: v.x,
            y: v.y,
            zoom: v.zoom,
        }
    }
}
impl From<solarxy_scenefile::CanvasViewportJson> for ViewportDto {
    fn from(v: solarxy_scenefile::CanvasViewportJson) -> Self {
        Self {
            x: v.x,
            y: v.y,
            zoom: v.zoom,
        }
    }
}

#[derive(Serialize, Deserialize, Default)]
#[serde(rename_all = "camelCase", default)]
struct MetaDto {
    name: String,
    description: String,
    project_id: String,
    created: String,
    modified: String,
}

impl From<MetaDto> for solarxy_scenefile::MetaJson {
    fn from(m: MetaDto) -> Self {
        Self {
            name: m.name,
            description: m.description,
            project_id: m.project_id,
            created: m.created,
            modified: m.modified,
        }
    }
}
impl From<solarxy_scenefile::MetaJson> for MetaDto {
    fn from(m: solarxy_scenefile::MetaJson) -> Self {
        Self {
            name: m.name,
            description: m.description,
            project_id: m.project_id,
            created: m.created,
            modified: m.modified,
        }
    }
}
