/* SPDX-FileCopyrightText: 2023 Blender Authors
 *
 * SPDX-License-Identifier: Apache-2.0 */

#include "testing/testing.h"
#include <cstring>

#include "MEM_guardedalloc.h"

#include "BLI_compiler_attrs.hh"
#include "BLI_heap_simple.hh"
#include "BLI_rand_c.hh"
#include "BLI_sys_types.hh"
#include "BLI_utildefines.hh"

namespace blender {

#define SIZE 1024

static void range_fl(float *array_tar, const int size)
{
  float *array_pt = array_tar + (size - 1);
  int i = size;
  while (i--) {
    *(array_pt--) = float(i);
  }
}

TEST(heap, SimpleEmpty)
{
  HeapSimple *heap;

  heap = BLI_heapsimple_new();
  EXPECT_TRUE(BLI_heapsimple_is_empty(heap));
  EXPECT_EQ(BLI_heapsimple_len(heap), 0);
  BLI_heapsimple_free(heap, nullptr);
}

TEST(heap, SimpleOne)
{
  HeapSimple *heap;
  const char *in = "test";

  heap = BLI_heapsimple_new();

  BLI_heapsimple_insert(heap, 0.0f, const_cast<char *>(in));
  EXPECT_FALSE(BLI_heapsimple_is_empty(heap));
  EXPECT_EQ(BLI_heapsimple_len(heap), 1);
  EXPECT_EQ(in, BLI_heapsimple_pop_min(heap));
  EXPECT_TRUE(BLI_heapsimple_is_empty(heap));
  EXPECT_EQ(BLI_heapsimple_len(heap), 0);
  BLI_heapsimple_free(heap, nullptr);
}

TEST(heap, SimpleRange)
{
  const int items_total = SIZE;
  HeapSimple *heap = BLI_heapsimple_new();
  for (int in = 0; in < items_total; in++) {
    BLI_heapsimple_insert(heap, float(in), POINTER_FROM_INT(in));
  }
  for (int out_test = 0; out_test < items_total; out_test++) {
    EXPECT_EQ(out_test, POINTER_AS_INT(BLI_heapsimple_pop_min(heap)));
  }
  EXPECT_TRUE(BLI_heapsimple_is_empty(heap));
  BLI_heapsimple_free(heap, nullptr);
}

TEST(heap, SimpleRangeReverse)
{
  const int items_total = SIZE;
  HeapSimple *heap = BLI_heapsimple_new();
  for (int in = 0; in < items_total; in++) {
    BLI_heapsimple_insert(heap, float(-in), POINTER_FROM_INT(-in));
  }
  for (int out_test = items_total - 1; out_test >= 0; out_test--) {
    EXPECT_EQ(-out_test, POINTER_AS_INT(BLI_heapsimple_pop_min(heap)));
  }
  EXPECT_TRUE(BLI_heapsimple_is_empty(heap));
  BLI_heapsimple_free(heap, nullptr);
}

TEST(heap, SimpleDuplicates)
{
  const int items_total = SIZE;
  HeapSimple *heap = BLI_heapsimple_new();
  for (int in = 0; in < items_total; in++) {
    BLI_heapsimple_insert(heap, 1.0f, nullptr);
  }
  for (int out_test = 0; out_test < items_total; out_test++) {
    EXPECT_EQ(0, POINTER_AS_INT(BLI_heapsimple_pop_min(heap)));
  }
  EXPECT_TRUE(BLI_heapsimple_is_empty(heap));
  BLI_heapsimple_free(heap, nullptr);
}

static void random_heapsimple_helper(const int items_total, const int random_seed)
{
  HeapSimple *heap = BLI_heapsimple_new();
  float *values = MEM_new_array_uninitialized<float>(size_t(items_total), __func__);
  range_fl(values, items_total);
  BLI_array_randomize(values, sizeof(float), items_total, random_seed);
  for (int i = 0; i < items_total; i++) {
    BLI_heapsimple_insert(heap, values[i], POINTER_FROM_INT(int(values[i])));
  }
  for (int out_test = 0; out_test < items_total; out_test++) {
    EXPECT_EQ(out_test, POINTER_AS_INT(BLI_heapsimple_pop_min(heap)));
  }
  EXPECT_TRUE(BLI_heapsimple_is_empty(heap));
  BLI_heapsimple_free(heap, nullptr);
  MEM_delete(values);
}

TEST(heap, SimpleRand1)
{
  random_heapsimple_helper(1, 1234);
}
TEST(heap, SimpleRand2)
{
  random_heapsimple_helper(2, 1234);
}
TEST(heap, SimpleRand100)
{
  random_heapsimple_helper(100, 4321);
}

}  // namespace blender
